-- NUKEVIET 3.0
-- Module: Database
-- http://www.nukeviet.vn
--
-- Host: localhost
-- Generation Time: January 21, 2011, 04:25 PM GMT
-- Server version: 5.1.49
-- PHP Version: 5.3.3-1ubuntu9.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET SESSION `character_set_client`='utf8';
SET SESSION `character_set_results`='utf8';
SET SESSION `character_set_connection`='utf8';
SET SESSION `collation_connection`='utf8_general_ci';
SET NAMES 'utf8';
ALTER DATABASE DEFAULT CHARACTER SET `utf8` COLLATE `utf8_general_ci`;

--
-- Database: `nukeviet`
--


-- ---------------------------------------


--
-- Table structure for table `nv_authors`
--

DROP TABLE IF EXISTS `nv_authors`;
CREATE TABLE `nv_authors` (
  `admin_id` int(11) unsigned NOT NULL,
  `editor` varchar(100) NOT NULL,
  `lev` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `files_level` varchar(255) NOT NULL,
  `position` varchar(255) NOT NULL,
  `addtime` int(11) NOT NULL DEFAULT '0',
  `edittime` int(11) NOT NULL DEFAULT '0',
  `is_suspend` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `susp_reason` mediumtext NOT NULL,
  `check_num` varchar(40) NOT NULL,
  `last_login` int(11) unsigned NOT NULL DEFAULT '0',
  `last_ip` varchar(45) NOT NULL,
  `last_agent` varchar(255) NOT NULL,
  PRIMARY KEY (`admin_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv_authors`
--

INSERT INTO `nv_authors` VALUES
(1, 'ckeditor', 1, 'images,flash,documents,archives|1|1|1', 'Administrator', 0, 0, 0, '', '', 0, '', '');


-- ---------------------------------------


--
-- Table structure for table `nv_authors_config`
--

DROP TABLE IF EXISTS `nv_authors_config`;
CREATE TABLE `nv_authors_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `keyname` varchar(32) DEFAULT NULL,
  `mask` tinyint(4) NOT NULL DEFAULT '0',
  `begintime` int(11) DEFAULT NULL,
  `endtime` int(11) DEFAULT NULL,
  `notice` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `keyname` (`keyname`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv_banip`
--

DROP TABLE IF EXISTS `nv_banip`;
CREATE TABLE `nv_banip` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(32) DEFAULT NULL,
  `mask` tinyint(4) NOT NULL DEFAULT '0',
  `area` tinyint(3) NOT NULL,
  `begintime` int(11) DEFAULT NULL,
  `endtime` int(11) DEFAULT NULL,
  `notice` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ip` (`ip`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv_banners_click`
--

DROP TABLE IF EXISTS `nv_banners_click`;
CREATE TABLE `nv_banners_click` (
  `bid` mediumint(8) NOT NULL DEFAULT '0',
  `click_time` int(11) unsigned NOT NULL DEFAULT '0',
  `click_day` int(2) NOT NULL,
  `click_ip` varchar(15) NOT NULL,
  `click_country` varchar(10) NOT NULL,
  `click_browse_key` varchar(100) NOT NULL,
  `click_browse_name` varchar(100) NOT NULL,
  `click_os_key` varchar(100) NOT NULL,
  `click_os_name` varchar(100) NOT NULL,
  `click_ref` varchar(255) NOT NULL,
  KEY `bid` (`bid`),
  KEY `click_day` (`click_day`),
  KEY `click_ip` (`click_ip`),
  KEY `click_country` (`click_country`),
  KEY `click_browse_key` (`click_browse_key`),
  KEY `click_os_key` (`click_os_key`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv_banners_clients`
--

DROP TABLE IF EXISTS `nv_banners_clients`;
CREATE TABLE `nv_banners_clients` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `login` varchar(60) NOT NULL,
  `pass` varchar(50) NOT NULL,
  `reg_time` int(11) unsigned NOT NULL DEFAULT '0',
  `full_name` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `website` varchar(255) NOT NULL,
  `location` varchar(255) NOT NULL,
  `yim` varchar(100) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `fax` varchar(100) NOT NULL,
  `mobile` varchar(100) NOT NULL,
  `act` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `check_num` varchar(40) NOT NULL,
  `last_login` int(11) unsigned NOT NULL DEFAULT '0',
  `last_ip` varchar(15) NOT NULL,
  `last_agent` varchar(255) NOT NULL,
  `uploadtype` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `login` (`login`),
  UNIQUE KEY `email` (`email`),
  KEY `full_name` (`full_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv_banners_plans`
--

DROP TABLE IF EXISTS `nv_banners_plans`;
CREATE TABLE `nv_banners_plans` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `blang` char(2) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `form` varchar(100) NOT NULL,
  `width` smallint(4) unsigned NOT NULL DEFAULT '0',
  `height` smallint(4) unsigned NOT NULL DEFAULT '0',
  `act` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `title` (`title`)
) ENGINE=MyISAM  AUTO_INCREMENT=3  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv_banners_plans`
--

INSERT INTO `nv_banners_plans` VALUES
(1, '', 'Quang cao giua trang', '', 'sequential', 510, 100, 1), 
(2, '', 'Quang cao trai', '', 'sequential', 190, 500, 1);


-- ---------------------------------------


--
-- Table structure for table `nv_banners_rows`
--

DROP TABLE IF EXISTS `nv_banners_rows`;
CREATE TABLE `nv_banners_rows` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `pid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `clid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `file_name` varchar(255) NOT NULL,
  `file_ext` varchar(100) NOT NULL,
  `file_mime` varchar(100) NOT NULL,
  `width` int(4) unsigned NOT NULL DEFAULT '0',
  `height` int(4) unsigned NOT NULL DEFAULT '0',
  `file_alt` varchar(255) NOT NULL,
  `click_url` varchar(255) NOT NULL,
  `file_name_tmp` varchar(255) NOT NULL,
  `file_alt_tmp` varchar(255) NOT NULL,
  `click_url_tmp` varchar(255) NOT NULL,
  `add_time` int(11) unsigned NOT NULL DEFAULT '0',
  `publ_time` int(11) unsigned NOT NULL DEFAULT '0',
  `exp_time` int(11) unsigned NOT NULL DEFAULT '0',
  `hits_total` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `act` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `pid` (`pid`),
  KEY `clid` (`clid`)
) ENGINE=MyISAM  AUTO_INCREMENT=4  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv_banners_rows`
--

INSERT INTO `nv_banners_rows` VALUES
(1, 'Bo ngoai giao', 2, 0, 'uploads/banners/bongoaigiao.jpg', 'jpg', 'image/jpeg', 160, 54, '', 'http://www.mofa.gov.vn', '', '', '', 1275296773, 1275296773, 0, 1, 1), 
(2, 'vinades', 2, 0, 'uploads/banners/vinades.jpg', 'jpg', 'image/jpeg', 190, 454, '', 'http://vinades.vn', '', '', '', 1275321220, 1275321220, 0, 0, 1), 
(3, 'Quang cao giua trang', 1, 0, 'uploads/banners/vndads___05.jpg', 'jpg', 'image/jpeg', 470, 60, '', 'http://vinades.vn', '', '', '', 1275321716, 1275321716, 0, 0, 1);


-- ---------------------------------------


--
-- Table structure for table `nv_config`
--

DROP TABLE IF EXISTS `nv_config`;
CREATE TABLE `nv_config` (
  `lang` varchar(3) NOT NULL DEFAULT 'sys',
  `module` varchar(25) NOT NULL DEFAULT 'global',
  `config_name` varchar(30) NOT NULL DEFAULT '',
  `config_value` varchar(255) NOT NULL DEFAULT '',
  UNIQUE KEY `lang` (`lang`,`module`,`config_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv_config`
--

INSERT INTO `nv_config` VALUES
('sys', 'global', 'site_keywords', 'Nukeviet, portal, mysql, php'), 
('sys', 'global', 'site_phone', ''), 
('sys', 'global', 'site_lang', 'vi'), 
('sys', 'global', 'admin_theme', 'admin_default'), 
('sys', 'global', 'date_pattern', 'l, d-m-Y'), 
('sys', 'global', 'time_pattern', 'H:i'), 
('sys', 'global', 'block_admin_ip', '0'), 
('sys', 'global', 'admfirewall', '0'), 
('sys', 'global', 'online_upd', '1'), 
('sys', 'global', 'statistic', '1'), 
('sys', 'global', 'dump_autobackup', '1'), 
('sys', 'global', 'dump_backup_ext', 'gz'), 
('sys', 'global', 'dump_backup_day', '30'), 
('sys', 'global', 'gfx_chk', '3'), 
('sys', 'global', 'file_allowed_ext', 'images,flash,documents,archives'), 
('sys', 'global', 'forbid_extensions', 'php'), 
('sys', 'global', 'forbid_mimes', ''), 
('sys', 'global', 'nv_max_size', '2097152'), 
('sys', 'global', 'str_referer_blocker', '0'), 
('sys', 'global', 'mailer_mode', ''), 
('sys', 'global', 'smtp_host', 'smtp.gmail.com'), 
('sys', 'global', 'smtp_ssl', '1'), 
('sys', 'global', 'smtp_port', '465'), 
('sys', 'global', 'smtp_username', 'user@gmail.com'), 
('sys', 'global', 'smtp_password', 'userpass'), 
('sys', 'global', 'allowuserreg', '1'), 
('sys', 'global', 'allowuserlogin', '1'), 
('sys', 'global', 'allowloginchange', '0'), 
('sys', 'global', 'useactivate', '2'), 
('sys', 'global', 'allowmailchange', '1'), 
('sys', 'global', 'allow_sitelangs', 'vi'), 
('sys', 'global', 'allow_adminlangs', 'cs,en,fr,vi'), 
('sys', 'global', 'read_type', '0'), 
('sys', 'global', 'is_url_rewrite', '0'), 
('sys', 'global', 'rewrite_optional', '0'), 
('sys', 'global', 'gzip_method', '1'), 
('sys', 'global', 'is_user_forum', '0'), 
('sys', 'global', 'openid_mode', '1'), 
('sys', 'global', 'authors_detail_main', '0'), 
('sys', 'global', 'spadmin_add_admin', '1'), 
('sys', 'global', 'openid_servers', 'yahoo,google,myopenid'), 
('sys', 'global', 'version', '3.0.12'), 
('vi', 'global', 'site_name', 'quachtuanlenh'), 
('vi', 'global', 'site_logo', 'logo.png'), 
('vi', 'global', 'site_description', 'NUKEVIET CMS 3.0 Developed by Vinades.,Jsc'), 
('vi', 'global', 'site_theme', 'modern'), 
('vi', 'global', 'site_home_module', 'news'), 
('vi', 'global', 'disable_site', '0'), 
('vi', 'global', 'disable_site_content', 'Vì lý do kỹ thuật website tạm ngưng hoạt động. Thành thật xin lỗi các bạn vì sự bất tiện này!'), 
('vi', 'news', 'indexfile', 'viewcat_main_right'), 
('vi', 'news', 'per_page', '20'), 
('vi', 'news', 'st_links', '10'), 
('vi', 'news', 'auto_postcomm', '1'), 
('vi', 'news', 'homewidth', '100'), 
('vi', 'news', 'homeheight', '80'), 
('vi', 'news', 'blockwidth', '52'), 
('vi', 'news', 'blockheight', '60'), 
('vi', 'news', 'imagefull', '460'), 
('vi', 'news', 'setcomm', '2'), 
('vi', 'news', 'copyright', 'Chú ý: Việc đăng lại bài viết trên ở website hoặc các phương tiện truyền thông khác mà không ghi rõ nguồn http://nukeviet.vn là vi phạm bản quyền'), 
('vi', 'news', 'showhometext', '1'), 
('vi', 'news', 'activecomm', '1'), 
('vi', 'news', 'emailcomm', '1'), 
('sys', 'global', 'site_email', 'nhan_tai_dat_viet100@yahoo.com'), 
('sys', 'global', 'error_send_email', 'nhan_tai_dat_viet100@yahoo.com'), 
('sys', 'global', 'my_domains', 'localhost'), 
('sys', 'global', 'cookie_prefix', 'nv3c_K19ky'), 
('sys', 'global', 'session_prefix', 'nv3s_Svmxxf'), 
('sys', 'global', 'site_timezone', 'Asia/Bangkok'), 
('sys', 'global', 'proxy_blocker', '0'), 
('sys', 'global', 'lang_multi', '1'), 
('sys', 'global', 'ftp_server', 'localhost'), 
('sys', 'global', 'ftp_port', '21'), 
('sys', 'global', 'ftp_user_name', ''), 
('sys', 'global', 'ftp_user_pass', ''), 
('sys', 'global', 'ftp_path', '/'), 
('sys', 'global', 'ftp_check_login', '0');


-- ---------------------------------------


--
-- Table structure for table `nv_cronjobs`
--

DROP TABLE IF EXISTS `nv_cronjobs`;
CREATE TABLE `nv_cronjobs` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `start_time` int(11) unsigned NOT NULL DEFAULT '0',
  `interval` int(11) unsigned NOT NULL DEFAULT '0',
  `run_file` varchar(255) NOT NULL,
  `run_func` varchar(255) NOT NULL,
  `params` varchar(255) NOT NULL,
  `del` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `is_sys` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `act` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `last_time` int(11) unsigned NOT NULL DEFAULT '0',
  `last_result` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `vi_cron_name` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `is_sys` (`is_sys`)
) ENGINE=MyISAM  AUTO_INCREMENT=8  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv_cronjobs`
--

INSERT INTO `nv_cronjobs` VALUES
(1, 1262293200, 5, 'online_expired_del.php', 'cron_online_expired_del', '', 0, 1, 1, 1295627120, 1, 'Xóa các dòng ghi trạng thái online đã cũ trong CSDL'), 
(2, 1262293200, 1440, 'dump_autobackup.php', 'cron_dump_autobackup', '', 0, 1, 1, 1276826911, 1, 'Tự động lưu CSDL'), 
(3, 1262296800, 60, 'temp_download_destroy.php', 'cron_auto_del_temp_download', '', 0, 1, 1, 1276839725, 1, 'Xóa các file tạm trong thư mục tmp'), 
(4, 1269657620, 30, 'ip_logs_destroy.php', 'cron_del_ip_logs', '', 0, 1, 1, 1276839725, 1, 'Xóa IP log files Xóa các file logo truy cập'), 
(5, 1271004840, 1440, 'error_log_destroy.php', 'cron_auto_del_error_log', '', 0, 1, 1, 1276793791, 1, 'Xóa các file error_log quá hạn'), 
(6, 1271004840, 360, 'error_log_sendmail.php', 'cron_auto_sendmail_error_log', '', 0, 1, 0, 1276177733, 0, 'Gửi email các thông báo lỗi cho admin'), 
(7, 1276281900, 60, 'ref_expired_del.php', 'cron_ref_expired_del', '', 0, 1, 1, 1276839725, 1, 'Xóa các referer quá hạn');


-- ---------------------------------------


--
-- Table structure for table `nv_groups`
--

DROP TABLE IF EXISTS `nv_groups`;
CREATE TABLE `nv_groups` (
  `group_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `content` mediumtext NOT NULL,
  `add_time` int(11) NOT NULL,
  `exp_time` int(11) NOT NULL,
  `users` mediumtext NOT NULL,
  `public` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `act` tinyint(1) unsigned NOT NULL,
  PRIMARY KEY (`group_id`),
  UNIQUE KEY `title` (`title`),
  KEY `exp_time` (`exp_time`)
) ENGINE=MyISAM  AUTO_INCREMENT=10  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv_language`
--

DROP TABLE IF EXISTS `nv_language`;
CREATE TABLE `nv_language` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `idfile` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `lang_key` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `filelang` (`idfile`,`lang_key`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv_language_file`
--

DROP TABLE IF EXISTS `nv_language_file`;
CREATE TABLE `nv_language_file` (
  `idfile` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `module` varchar(50) NOT NULL,
  `admin_file` tinyint(1) NOT NULL DEFAULT '0',
  `langtype` varchar(50) NOT NULL,
  PRIMARY KEY (`idfile`),
  UNIQUE KEY `module` (`module`,`admin_file`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv_logs`
--

DROP TABLE IF EXISTS `nv_logs`;
CREATE TABLE `nv_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lang` varchar(10) NOT NULL,
  `module_name` varchar(150) NOT NULL,
  `name_key` varchar(255) NOT NULL,
  `note_action` text NOT NULL,
  `link_acess` varchar(255) NOT NULL,
  `userid` int(11) NOT NULL,
  `log_time` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv_sessions`
--

DROP TABLE IF EXISTS `nv_sessions`;
CREATE TABLE `nv_sessions` (
  `session_id` varchar(50) DEFAULT NULL,
  `uid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `full_name` varchar(100) NOT NULL,
  `onl_time` int(11) unsigned NOT NULL DEFAULT '0',
  UNIQUE KEY `session_id` (`session_id`),
  KEY `onl_time` (`onl_time`)
) ENGINE=MEMORY  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv_sessions`
--

INSERT INTO `nv_sessions` VALUES
('211e1a553cf9bac245b2ac1bf7610e792130706433', 0, 'guest', 1295627120);


-- ---------------------------------------


--
-- Table structure for table `nv_setup`
--

DROP TABLE IF EXISTS `nv_setup`;
CREATE TABLE `nv_setup` (
  `lang` char(2) NOT NULL,
  `module` varchar(50) NOT NULL,
  `tables` varchar(255) NOT NULL,
  `version` varchar(100) NOT NULL,
  `setup_time` int(11) unsigned NOT NULL DEFAULT '0',
  UNIQUE KEY `lang` (`lang`,`module`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv_setup_language`
--

DROP TABLE IF EXISTS `nv_setup_language`;
CREATE TABLE `nv_setup_language` (
  `lang` char(2) NOT NULL,
  `setup` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`lang`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv_setup_language`
--

INSERT INTO `nv_setup_language` VALUES
('vi', 1);


-- ---------------------------------------


--
-- Table structure for table `nv_setup_modules`
--

DROP TABLE IF EXISTS `nv_setup_modules`;
CREATE TABLE `nv_setup_modules` (
  `title` varchar(55) NOT NULL,
  `is_sysmod` tinyint(1) NOT NULL DEFAULT '0',
  `virtual` tinyint(1) NOT NULL DEFAULT '0',
  `module_file` varchar(50) NOT NULL DEFAULT '',
  `module_data` varchar(55) NOT NULL DEFAULT '',
  `mod_version` varchar(50) NOT NULL,
  `addtime` int(11) NOT NULL DEFAULT '0',
  `author` text NOT NULL,
  `note` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`title`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv_setup_modules`
--

INSERT INTO `nv_setup_modules` VALUES
('about', 0, 1, 'about', 'about', '3.0.01 1270400000', 1270997593, 'VINADES (contact@vinades.vn)', ''), 
('banners', 1, 0, 'banners', 'banners', '3.0.01 1270400000', 1270997593, 'VINADES (contact@vinades.vn)', ''), 
('contact', 0, 1, 'contact', 'contact', '3.0.01 1270400000', 1270997593, 'VINADES (contact@vinades.vn)', ''), 
('news', 1, 1, 'news', 'news', '3.0.01 1270400000', 1270990593, 'VINADES (contact@vinades.vn)', ''), 
('voting', 0, 0, 'voting', 'voting', '3.0.01 1270400000', 1270997593, 'VINADES (contact@vinades.vn)', ''), 
('forum', 0, 0, 'forum', 'forum', '3.0.01 1273225635', 1275351278, 'VINADES (contact@vinades.vn)', ''), 
('search', 1, 0, 'search', 'search', '3.0.01 1273225635', 1273474165, 'VINADES (contact@vinades.vn)', ''), 
('users', 1, 0, 'users', 'users', '3.0.01 1273225635', 1274080275, 'VINADES (contact@vinades.vn)', ''), 
('download', 0, 1, 'download', 'download', '3.0.01 1273225635', 1275965656, 'VINADES (contact@vinades.vn)', ''), 
('weblinks', 0, 1, 'weblinks', 'weblinks', '3.0.01 1273225635', 1276228274, 'VINADES (contact@vinades.vn)', ''), 
('statistics', 1, 0, 'statistics', 'statistics', '3.0.01 1273225635', 1276785143, 'VINADES (contact@vinades.vn)', '');


-- ---------------------------------------


--
-- Table structure for table `nv_users`
--

DROP TABLE IF EXISTS `nv_users`;
CREATE TABLE `nv_users` (
  `userid` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL DEFAULT '',
  `md5username` char(32) NOT NULL DEFAULT '',
  `password` varchar(50) NOT NULL DEFAULT '',
  `email` varchar(100) NOT NULL DEFAULT '',
  `full_name` varchar(255) NOT NULL DEFAULT '',
  `gender` varchar(1) NOT NULL,
  `photo` varchar(255) NOT NULL DEFAULT '',
  `birthday` int(11) unsigned NOT NULL,
  `sig` text,
  `regdate` int(11) NOT NULL DEFAULT '0',
  `website` varchar(255) NOT NULL DEFAULT '',
  `location` varchar(255) NOT NULL,
  `yim` varchar(100) NOT NULL DEFAULT '',
  `telephone` varchar(100) NOT NULL DEFAULT '',
  `fax` varchar(100) NOT NULL DEFAULT '',
  `mobile` varchar(100) NOT NULL DEFAULT '',
  `question` varchar(255) NOT NULL,
  `answer` varchar(255) NOT NULL DEFAULT '',
  `passlostkey` varchar(40) NOT NULL DEFAULT '',
  `view_mail` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `remember` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `in_groups` varchar(255) NOT NULL DEFAULT '',
  `active` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `checknum` varchar(40) NOT NULL DEFAULT '',
  `last_login` int(11) unsigned NOT NULL DEFAULT '0',
  `last_ip` varchar(45) NOT NULL DEFAULT '',
  `last_agent` varchar(255) NOT NULL DEFAULT '',
  `last_openid` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`userid`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `md5username` (`md5username`),
  UNIQUE KEY `email` (`email`)
) ENGINE=MyISAM  AUTO_INCREMENT=2  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv_users`
--

INSERT INTO `nv_users` VALUES
(1, 'kt200707g11', '37b45c49c69c77f25c682dd3744dab8c', '35012ca03b630a9768c7e332abbeef438247f53e', 'nhan_tai_dat_viet100@yahoo.com', 'kt200707g11', '', '', 0, NULL, 1295627109, '', '', '', '', '', '', 'toi ten gi ?', 'linh', '', 0, 1, '', 1, '', 1295627109, '', '', '');


-- ---------------------------------------


--
-- Table structure for table `nv_users_config`
--

DROP TABLE IF EXISTS `nv_users_config`;
CREATE TABLE `nv_users_config` (
  `config` varchar(50) NOT NULL,
  `content` mediumtext NOT NULL,
  `edit_time` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`config`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv_users_config`
--

INSERT INTO `nv_users_config` VALUES
('registertype', '1', 1274757036), 
('deny_email', 'yoursite.com|mysite.com|localhost|xxx', 1274757036), 
('deny_name', 'anonimo|anonymous|god|linux|nobody|operator|root', 1274757036), 
('siteterms_vi', '<p> Để trở thành thành viên, bạn phải cam kết đồng ý với các điều khoản dưới đây. Chúng tôi có thể thay đổi lại những điều khoản này vào bất cứ lúc nào và chúng tôi sẽ cố gắng thông báo đến bạn kịp thời.<br  /> <br  /> Bạn cam kết không gửi bất cứ bài viết có nội dung lừa đảo, thô tục, thiếu văn hoá; vu khống, khiêu khích, đe doạ người khác; liên quan đến các vấn đề tình dục hay bất cứ nội dung nào vi phạm luật pháp của quốc gia mà bạn đang sống, luật pháp của quốc gia nơi đặt máy chủ của website này hay luật pháp quốc tế. Nếu vẫn cố tình vi phạm, ngay lập tức bạn sẽ bị cấm tham gia vào website. Địa chỉ IP của tất cả các bài viết đều được ghi nhận lại để bảo vệ các điều khoản cam kết này trong trường hợp bạn không tuân thủ.<br  /> <br  /> Bạn đồng ý rằng website có quyền gỡ bỏ, sửa, di chuyển hoặc khoá bất kỳ bài viết nào trong website vào bất cứ lúc nào tuỳ theo nhu cầu công việc.<br  /> <br  /> Đăng ký làm thành viên của chúng tôi, bạn cũng phải đồng ý rằng, bất kỳ thông tin cá nhân nào mà bạn cung cấp đều được lưu trữ trong cơ sở dữ liệu của hệ thống. Mặc dù những thông tin này sẽ không được cung cấp cho bất kỳ người thứ ba nào khác mà không được sự đồng ý của bạn, chúng tôi không chịu trách nhiệm về việc những thông tin cá nhân này của bạn bị lộ ra bên ngoài từ những kẻ phá hoại có ý đồ xấu tấn công vào cơ sở dữ liệu của hệ thống.</p>', 1274757129);


-- ---------------------------------------


--
-- Table structure for table `nv_users_openid`
--

DROP TABLE IF EXISTS `nv_users_openid`;
CREATE TABLE `nv_users_openid` (
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `openid` varchar(255) NOT NULL DEFAULT '',
  `opid` varchar(50) NOT NULL DEFAULT '',
  `email` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`opid`),
  KEY `userid` (`userid`),
  KEY `email` (`email`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv_users_question`
--

DROP TABLE IF EXISTS `nv_users_question`;
CREATE TABLE `nv_users_question` (
  `qid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL DEFAULT '',
  `lang` varchar(2) NOT NULL DEFAULT '',
  `weight` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `add_time` int(11) unsigned NOT NULL,
  `edit_time` int(11) unsigned NOT NULL,
  PRIMARY KEY (`qid`),
  UNIQUE KEY `title` (`title`,`lang`)
) ENGINE=MyISAM  AUTO_INCREMENT=8  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv_users_question`
--

INSERT INTO `nv_users_question` VALUES
(1, 'Bạn thích môn thể thao nào nhất', 'vi', 1, 1274840238, 1274840238), 
(2, 'Món ăn mà bạn yêu thích', 'vi', 2, 1274840250, 1274840250), 
(3, 'Thần tượng điện ảnh của bạn', 'vi', 3, 1274840257, 1274840257), 
(4, 'Bạn thích nhạc sỹ nào nhất', 'vi', 4, 1274840264, 1274840264), 
(5, 'Quê ngoại của bạn ở đâu', 'vi', 5, 1274840270, 1274840270), 
(6, 'Tên cuốn sách &quot;gối đầu giường&quot;', 'vi', 6, 1274840278, 1274840278), 
(7, 'Ngày lễ mà bạn luôn mong đợi', 'vi', 7, 1274840285, 1274840285);


-- ---------------------------------------


--
-- Table structure for table `nv_users_reg`
--

DROP TABLE IF EXISTS `nv_users_reg`;
CREATE TABLE `nv_users_reg` (
  `userid` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL DEFAULT '',
  `md5username` char(32) NOT NULL DEFAULT '',
  `password` varchar(50) NOT NULL DEFAULT '',
  `email` varchar(100) NOT NULL DEFAULT '',
  `full_name` varchar(255) NOT NULL DEFAULT '',
  `regdate` int(11) unsigned NOT NULL DEFAULT '0',
  `question` varchar(255) NOT NULL,
  `answer` varchar(255) NOT NULL DEFAULT '',
  `checknum` varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`userid`),
  UNIQUE KEY `login` (`username`),
  UNIQUE KEY `md5username` (`md5username`),
  UNIQUE KEY `email` (`email`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv_vi_about`
--

DROP TABLE IF EXISTS `nv_vi_about`;
CREATE TABLE `nv_vi_about` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL,
  `bodytext` mediumtext NOT NULL,
  `keywords` mediumtext NOT NULL,
  `weight` smallint(4) NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `add_time` int(11) NOT NULL DEFAULT '0',
  `edit_time` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `title` (`title`)
) ENGINE=MyISAM  AUTO_INCREMENT=3  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv_vi_about`
--

INSERT INTO `nv_vi_about` VALUES
(1, 'Giới thiệu về NukeViet 3.0', 'Gioi-thieu-ve-NukeViet-3-0', '<p> NukeViet 3.0 là thế hệ CMS hoàn toàn mới do người Việt phát triển. Lần đầu tiên ở Việt Nam, một bộ nhân mã nguồn mở được đầu tư bài bản và chuyên nghiệp cả về tài chính, nhân lực và thời gian. Kết quả là 100% dòng code của NukeViet được viết mới hoàn toàn, NukeViet 3 sử dụng xHTML, CSS với Xtemplate và jquery cho phép vận dụng Ajax uyển chuyển cả trong công nghệ nhân.</p><p> Tận dụng các thành tựu mã nguồn mở có sẵn nhưng NukeViet 3 vẫn đảm bảo rằng từng dòng code là được code tay (NukeViet 3 không sử dụng bất cứ một nền tảng (framework) nào). Điều này có nghĩa là NukeViet 3 hoàn toàn không phụ thuộc vào bất cứ framework nào trong quá trình phát triển của mình; Bạn hoàn toàn có thể đọc hiểu để tự lập trình trên NukeViet 3 nếu bạn biết PHP và MySQL (đồng nghĩa với việc NukeViet 3 hoàn toàn mở và dễ nghiên cứu cho bất cứ ai muốn tìm hiểu về code của NukeViet).</p><p style=\"text-align: justify;\"> Bộ nhân NukeViet 3 ngoài việc thừa hưởng sự đơn giản vốn có của NukeViet nhưng không vì thế mà quên nâng cấp mình. Hệ thống NukeViet 3 hỗ trợ công nghệ đa nhân module. Chúng tôi gọi đó là công nghệ ảo hóa module. Công nghệ này cho phép người sử dụng có thể khởi tạo hàng ngàn module một cách tự động mà không cần động đến một dòng code. Các module được sinh ra từ công nghệ này gọi là module ảo. Module ảo là module được nhân bản từ một module bất kỳ của hệ thống nukeviet nếu module đó cho phép tạo module ảo.</p><p style=\"text-align: justify;\"> NukeViet 3 cũng hỗ trợ việc cài đặt từ động 100% các module, block, theme từ Admin Control Panel, người sử dụng có thể cài module mà không cần làm bất cứ thao tác phức tạp nào. NukeViet 3 còn cho phép bạn đóng gói module để chia sẻ cho người khác.</p><p style=\"text-align: justify;\"> NukeViet 3 đa ngôn ngữ 100% với 2 loại: đa ngôn ngữ giao diện và đa ngôn ngữ database. NukeViet 3 có tính năng&nbsp; cho phép người quản trị tự xây dựng ngôn ngữ mới cho site. Cho&nbsp; phép đóng gói file ngôn ngữ để chia sẻ cho cộng đồng... câu chuyện về nukeviet 3 sẽ còn dài vì một loạt các tính năng cao cấp vẫn đang được phát triển. Hãy sử dụng và phổ biến NukeViet 3 để tự mình tận hưởng những thành quả mới nhất từ công nghệ web mã nguồn mở. Cuối cùng NukeViet 3 là món của của VINADES.,JSC gửi tới cộng đồng để cảm ơn cộng đồng đã ủng hộ thời gian qua, bây giờ NukeViet 3 được đưa trở lại cộng đồng để hy vọng NukeViet 3 tiếp tục lớn mạnh hơn.</p><p style=\"text-align: justify;\"> Mọi ý kiến về NukeViet 3 các bạn vui lòng gửi về email: admin@nukeviet.vn Tất cả các góp ý của các bạn đều có ý nghĩa cho NukeViet nhằm cải thiện và nâng cao tính năng. Mọi góp ý đều được hoanh nghênh.</p>', '', 1, 1, 1275320174, 1275320174, 1), 
(2, 'Giới thiệu về công ty chuyên quản NukeViet', 'Gioi-thieu-ve-cong-ty-chuyen-quan-NukeViet', '<p style=\"text-align: justify;\"> Để chuyên nghiệp hóa việc phát hành mã nguồn mở NukeViet, Ban Quản Trị NukeViet quyết định thành lập doanh nghiệp chuyên quản NukeViet mang tên CÔNG TY CỔ PHẦN PHÁT TRIỂN NGUỒN MỞ VIỆT NAM - Tên giao dịch tiếng Anh: VIET NAM OPEN SOURCE DEVELOPMENT JOINT STOCK COMPANY (viết tắt: VINADES.,JSC). Nhiệm vụ công ty ngoài việc phát hành, phát triển hệ thống NukeViet sẽ có thêm nhiệm vụ triển khai các dự án để tạo kinh phí duy trì hoạt động lâu dài cho NukeViet. Trên tinh thần đó công ty sẽ phát triển bộ mã nguồn NukeViet nhất quán theo con đường mã nguồn mở đã chọn - tự do và miễn phí nhưng chuyên nghiệp và quy mô hơn bao giờ hết.</p><p style=\"text-align: justify;\"> Thông tin ra mắt công ty VINADES có thể tìm thấy trên trang 7 báo Hà Nội Mới ra ngày 25/02/2010 (<a href=\"http://hanoimoi.com.vn/newsdetail/Cong_nghe/309750/ra-mat-cong-ty-ma-nguon-mo-dau-tien-tai-viet-nam.htm\" target=\"_blank\">xem chi tiết</a>), Bản tin tiếng Anh của đài tiếng nói Việt Nam ngày 26/02/2010 (<a href=\"http://english.vovnews.vn/Home/First-opensource-company-starts-operation/20102/112960.vov\" target=\"_blank\">xem chi tiết</a>) và các trang tin tức, báo điện tử khác (<a href=\"http://www.google.com.vn/search?q=%22Ra+m%E1%BA%AFt+c%C3%B4ng+ty+m%C3%A3+ngu%E1%BB%93n+m%E1%BB%9F+%C4%91%E1%BA%A7u+ti%C3%AAn+t%E1%BA%A1i+Vi%E1%BB%87t+Nam%22&amp;ie=utf-8&amp;oe=utf-8&amp;aq=t&amp;rls=org.mozilla:vi:official&amp;client=firefox-a\" target=\"_blank\">xem chi tiết</a>)</p><div id=\"content\"> <strong><span style=\"font-family: tahoma; color: rgb(255, 69, 0); font-size: 14px;\">Mã nguồn mở - xu hướng của thế giới – lựa chọn cho Việt Nam</span></strong><br  /> <p style=\"text-align: justify;\"> Sử dụng và mở hóa mã nguồn dường như đã thành xu hướng tất yếu của thế giới. Không tách khỏi dòng chảy công nghệ, Việt Nam đã và đang từng bước hòa nhập vào dòng chảy ấy. Bắt đầu cho xu hướng phát triển mã nguồn mở (open source) phải nói đến nỗ lực cổ vũ cho việc sử dụng mã nguồn mở của cộng đồng mạng Việt Nam.</p> <p style=\"text-align: justify;\"> Sau một thời gian dài nỗ lực, các sản phẩm mã nguồn mở đã đến với cộng đồng người Việt và bây giờ là ăn sâu trong tiềm thức người dùng như một phần tất yếu của thế giới công nghệ. Vậy nên, dù là công dân mạng hay người dùng máy tính thông thường, dù là dân công nghệ thông tin (IT) hay là nhân viên văn phòng, dù có tham gia lập trình hay không thì một điều chắc chắn rằng bất cứ ai trong chúng ta cũng đã và đang sử dụng các phần mềm mã nguồn mở.</p> <p style=\"text-align: justify;\"> Sản phẩm mã nguồn mở tạo web NukeViet cũng là một trong những sản phẩm quen thuộc của cộng đồng IT Việt Nam. NukeViet đã được phát triển trong hơn 5 năm qua, được sử dụng ở nhiều website lớn nhỏ thuộc nhiều lĩnh vực khác nhau.</p></div>', '', 2, 1, 1275320224, 1275320224, 1);


-- ---------------------------------------


--
-- Table structure for table `nv_vi_blocks`
--

DROP TABLE IF EXISTS `nv_vi_blocks`;
CREATE TABLE `nv_vi_blocks` (
  `bid` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `groupbl` int(11) NOT NULL DEFAULT '0',
  `title` varchar(255) DEFAULT NULL,
  `link` varchar(255) DEFAULT NULL,
  `type` varchar(20) NOT NULL DEFAULT 'file',
  `file_path` text,
  `theme` varchar(255) NOT NULL,
  `template` varchar(255) DEFAULT NULL,
  `position` varchar(20) DEFAULT NULL,
  `exp_time` int(11) DEFAULT '0',
  `active` varchar(1) DEFAULT NULL,
  `groups_view` varchar(255) DEFAULT '',
  `module` varchar(255) NOT NULL,
  `all_func` tinyint(4) NOT NULL DEFAULT '0',
  `func_id` int(11) NOT NULL,
  `weight` int(11) NOT NULL,
  PRIMARY KEY (`bid`),
  KEY `groupbl` (`groupbl`),
  KEY `module` (`module`),
  KEY `func_id` (`func_id`),
  KEY `exp_time` (`exp_time`),
  KEY `theme` (`theme`)
) ENGINE=MyISAM  AUTO_INCREMENT=435  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv_vi_blocks`
--

INSERT INTO `nv_vi_blocks` VALUES
(1, 1, 'Menu', '', 'file', 'module.block_category.php', 'default', '', '[LEFT]', 0, '1', '0', 'news', 0, 4, 1), 
(2, 1, 'Menu', '', 'file', 'module.block_category.php', 'default', '', '[LEFT]', 0, '1', '0', 'news', 0, 12, 1), 
(3, 1, 'Menu', '', 'file', 'module.block_category.php', 'default', '', '[LEFT]', 0, '1', '0', 'news', 0, 11, 1), 
(4, 1, 'Menu', '', 'file', 'module.block_category.php', 'default', '', '[LEFT]', 0, '1', '0', 'news', 0, 3, 1), 
(5, 1, 'Menu', '', 'file', 'module.block_category.php', 'default', '', '[LEFT]', 0, '1', '0', 'news', 0, 9, 1), 
(6, 2, 'Thống kê truy cập', '', 'file', 'global.counter.php', 'default', '', '[LEFT]', 0, '1', '0', 'global', 1, 1, 1), 
(7, 2, 'Thống kê truy cập', '', 'file', 'global.counter.php', 'default', '', '[LEFT]', 0, '1', '0', 'global', 1, 46, 1), 
(8, 2, 'Thống kê truy cập', '', 'file', 'global.counter.php', 'default', '', '[LEFT]', 0, '1', '0', 'global', 1, 35, 1), 
(9, 2, 'Thống kê truy cập', '', 'file', 'global.counter.php', 'default', '', '[LEFT]', 0, '1', '0', 'global', 1, 15, 1), 
(12, 2, 'Thống kê truy cập', '', 'file', 'global.counter.php', 'default', '', '[LEFT]', 0, '1', '0', 'global', 1, 13, 1), 
(13, 2, 'Thống kê truy cập', '', 'file', 'global.counter.php', 'default', '', '[LEFT]', 0, '1', '0', 'global', 1, 17, 1), 
(14, 2, 'Thống kê truy cập', '', 'file', 'global.counter.php', 'default', '', '[LEFT]', 0, '1', '0', 'global', 1, 16, 1), 
(15, 2, 'Thống kê truy cập', '', 'file', 'global.counter.php', 'default', '', '[LEFT]', 0, '1', '0', 'global', 1, 4, 2), 
(16, 2, 'Thống kê truy cập', '', 'file', 'global.counter.php', 'default', '', '[LEFT]', 0, '1', '0', 'global', 1, 12, 2), 
(17, 2, 'Thống kê truy cập', '', 'file', 'global.counter.php', 'default', '', '[LEFT]', 0, '1', '0', 'global', 1, 11, 2), 
(18, 2, 'Thống kê truy cập', '', 'file', 'global.counter.php', 'default', '', '[LEFT]', 0, '1', '0', 'global', 1, 3, 2), 
(19, 2, 'Thống kê truy cập', '', 'file', 'global.counter.php', 'default', '', '[LEFT]', 0, '1', '0', 'global', 1, 9, 2), 
(20, 2, 'Thống kê truy cập', '', 'file', 'global.counter.php', 'default', '', '[LEFT]', 0, '1', '0', 'global', 1, 48, 1), 
(21, 2, 'Thống kê truy cập', '', 'file', 'global.counter.php', 'default', '', '[LEFT]', 0, '1', '0', 'global', 1, 41, 1), 
(22, 2, 'Thống kê truy cập', '', 'file', 'global.counter.php', 'default', '', '[LEFT]', 0, '1', '0', 'global', 1, 40, 1), 
(23, 2, 'Thống kê truy cập', '', 'file', 'global.counter.php', 'default', '', '[LEFT]', 0, '1', '0', 'global', 1, 38, 1), 
(24, 2, 'Thống kê truy cập', '', 'file', 'global.counter.php', 'default', '', '[LEFT]', 0, '1', '0', 'global', 1, 37, 1), 
(25, 2, 'Thống kê truy cập', '', 'file', 'global.counter.php', 'default', '', '[LEFT]', 0, '1', '0', 'global', 1, 39, 1), 
(26, 2, 'Thống kê truy cập', '', 'file', 'global.counter.php', 'default', '', '[LEFT]', 0, '1', '0', 'global', 1, 36, 1), 
(27, 2, 'Thống kê truy cập', '', 'file', 'global.counter.php', 'default', '', '[LEFT]', 0, '1', '0', 'global', 1, 42, 1), 
(28, 2, 'Thống kê truy cập', '', 'file', 'global.counter.php', 'default', '', '[LEFT]', 0, '1', '0', 'global', 1, 33, 1), 
(29, 2, 'Thống kê truy cập', '', 'file', 'global.counter.php', 'default', '', '[LEFT]', 0, '1', '0', 'global', 1, 29, 1), 
(30, 2, 'Thống kê truy cập', '', 'file', 'global.counter.php', 'default', '', '[LEFT]', 0, '1', '0', 'global', 1, 30, 1), 
(31, 2, 'Thống kê truy cập', '', 'file', 'global.counter.php', 'default', '', '[LEFT]', 0, '1', '0', 'global', 1, 34, 1), 
(32, 2, 'Thống kê truy cập', '', 'file', 'global.counter.php', 'default', '', '[LEFT]', 0, '1', '0', 'global', 1, 32, 1), 
(33, 2, 'Thống kê truy cập', '', 'file', 'global.counter.php', 'default', '', '[LEFT]', 0, '1', '0', 'global', 1, 27, 1), 
(34, 2, 'Thống kê truy cập', '', 'file', 'global.counter.php', 'default', '', '[LEFT]', 0, '1', '0', 'global', 1, 26, 1), 
(35, 2, 'Thống kê truy cập', '', 'file', 'global.counter.php', 'default', '', '[LEFT]', 0, '1', '0', 'global', 1, 28, 1), 
(36, 2, 'Thống kê truy cập', '', 'file', 'global.counter.php', 'default', '', '[LEFT]', 0, '1', '0', 'global', 1, 31, 1), 
(37, 2, 'Thống kê truy cập', '', 'file', 'global.counter.php', 'default', '', '[LEFT]', 0, '1', '0', 'global', 1, 22, 1), 
(38, 2, 'Thống kê truy cập', '', 'file', 'global.counter.php', 'default', '', '[LEFT]', 0, '1', '0', 'global', 1, 24, 1), 
(39, 2, 'Thống kê truy cập', '', 'file', 'global.counter.php', 'default', '', '[LEFT]', 0, '1', '0', 'global', 1, 20, 1), 
(40, 3, 'Quảng cáo trái', '', 'banner', '2', 'default', '', '[LEFT]', 0, '1', '0', 'global', 1, 1, 2), 
(41, 3, 'Quảng cáo trái', '', 'banner', '2', 'default', '', '[LEFT]', 0, '1', '0', 'global', 1, 46, 2), 
(42, 3, 'Quảng cáo trái', '', 'banner', '2', 'default', '', '[LEFT]', 0, '1', '0', 'global', 1, 35, 2), 
(43, 3, 'Quảng cáo trái', '', 'banner', '2', 'default', '', '[LEFT]', 0, '1', '0', 'global', 1, 15, 2), 
(46, 3, 'Quảng cáo trái', '', 'banner', '2', 'default', '', '[LEFT]', 0, '1', '0', 'global', 1, 13, 2), 
(47, 3, 'Quảng cáo trái', '', 'banner', '2', 'default', '', '[LEFT]', 0, '1', '0', 'global', 1, 17, 2), 
(48, 3, 'Quảng cáo trái', '', 'banner', '2', 'default', '', '[LEFT]', 0, '1', '0', 'global', 1, 16, 2), 
(49, 3, 'Quảng cáo trái', '', 'banner', '2', 'default', '', '[LEFT]', 0, '1', '0', 'global', 1, 4, 3), 
(50, 3, 'Quảng cáo trái', '', 'banner', '2', 'default', '', '[LEFT]', 0, '1', '0', 'global', 1, 12, 3), 
(51, 3, 'Quảng cáo trái', '', 'banner', '2', 'default', '', '[LEFT]', 0, '1', '0', 'global', 1, 11, 3), 
(52, 3, 'Quảng cáo trái', '', 'banner', '2', 'default', '', '[LEFT]', 0, '1', '0', 'global', 1, 3, 3), 
(53, 3, 'Quảng cáo trái', '', 'banner', '2', 'default', '', '[LEFT]', 0, '1', '0', 'global', 1, 9, 3), 
(54, 3, 'Quảng cáo trái', '', 'banner', '2', 'default', '', '[LEFT]', 0, '1', '0', 'global', 1, 48, 2), 
(55, 3, 'Quảng cáo trái', '', 'banner', '2', 'default', '', '[LEFT]', 0, '1', '0', 'global', 1, 41, 2), 
(56, 3, 'Quảng cáo trái', '', 'banner', '2', 'default', '', '[LEFT]', 0, '1', '0', 'global', 1, 40, 2), 
(57, 3, 'Quảng cáo trái', '', 'banner', '2', 'default', '', '[LEFT]', 0, '1', '0', 'global', 1, 38, 2), 
(58, 3, 'Quảng cáo trái', '', 'banner', '2', 'default', '', '[LEFT]', 0, '1', '0', 'global', 1, 37, 2), 
(59, 3, 'Quảng cáo trái', '', 'banner', '2', 'default', '', '[LEFT]', 0, '1', '0', 'global', 1, 39, 2), 
(60, 3, 'Quảng cáo trái', '', 'banner', '2', 'default', '', '[LEFT]', 0, '1', '0', 'global', 1, 36, 2), 
(61, 3, 'Quảng cáo trái', '', 'banner', '2', 'default', '', '[LEFT]', 0, '1', '0', 'global', 1, 42, 2), 
(62, 3, 'Quảng cáo trái', '', 'banner', '2', 'default', '', '[LEFT]', 0, '1', '0', 'global', 1, 33, 2), 
(63, 3, 'Quảng cáo trái', '', 'banner', '2', 'default', '', '[LEFT]', 0, '1', '0', 'global', 1, 29, 2), 
(64, 3, 'Quảng cáo trái', '', 'banner', '2', 'default', '', '[LEFT]', 0, '1', '0', 'global', 1, 30, 2), 
(65, 3, 'Quảng cáo trái', '', 'banner', '2', 'default', '', '[LEFT]', 0, '1', '0', 'global', 1, 34, 2), 
(66, 3, 'Quảng cáo trái', '', 'banner', '2', 'default', '', '[LEFT]', 0, '1', '0', 'global', 1, 32, 2), 
(67, 3, 'Quảng cáo trái', '', 'banner', '2', 'default', '', '[LEFT]', 0, '1', '0', 'global', 1, 27, 2), 
(68, 3, 'Quảng cáo trái', '', 'banner', '2', 'default', '', '[LEFT]', 0, '1', '0', 'global', 1, 26, 2), 
(69, 3, 'Quảng cáo trái', '', 'banner', '2', 'default', '', '[LEFT]', 0, '1', '0', 'global', 1, 28, 2), 
(70, 3, 'Quảng cáo trái', '', 'banner', '2', 'default', '', '[LEFT]', 0, '1', '0', 'global', 1, 31, 2), 
(71, 3, 'Quảng cáo trái', '', 'banner', '2', 'default', '', '[LEFT]', 0, '1', '0', 'global', 1, 22, 2), 
(72, 3, 'Quảng cáo trái', '', 'banner', '2', 'default', '', '[LEFT]', 0, '1', '0', 'global', 1, 24, 2), 
(73, 3, 'Quảng cáo trái', '', 'banner', '2', 'default', '', '[LEFT]', 0, '1', '0', 'global', 1, 20, 2), 
(74, 4, 'Giới thiệu', '', 'file', 'global.about.php', 'default', 'orange', '[RIGHT]', 0, '1', '0', 'global', 1, 1, 1), 
(75, 4, 'Giới thiệu', '', 'file', 'global.about.php', 'default', 'orange', '[RIGHT]', 0, '1', '0', 'global', 1, 46, 1), 
(76, 4, 'Giới thiệu', '', 'file', 'global.about.php', 'default', 'orange', '[RIGHT]', 0, '1', '0', 'global', 1, 35, 1), 
(77, 4, 'Giới thiệu', '', 'file', 'global.about.php', 'default', 'orange', '[RIGHT]', 0, '1', '0', 'global', 1, 15, 1), 
(80, 4, 'Giới thiệu', '', 'file', 'global.about.php', 'default', 'orange', '[RIGHT]', 0, '1', '0', 'global', 1, 13, 1), 
(81, 4, 'Giới thiệu', '', 'file', 'global.about.php', 'default', 'orange', '[RIGHT]', 0, '1', '0', 'global', 1, 17, 1), 
(82, 4, 'Giới thiệu', '', 'file', 'global.about.php', 'default', 'orange', '[RIGHT]', 0, '1', '0', 'global', 1, 16, 1), 
(83, 4, 'Giới thiệu', '', 'file', 'global.about.php', 'default', 'orange', '[RIGHT]', 0, '1', '0', 'global', 1, 4, 1), 
(84, 4, 'Giới thiệu', '', 'file', 'global.about.php', 'default', 'orange', '[RIGHT]', 0, '1', '0', 'global', 1, 12, 1), 
(85, 4, 'Giới thiệu', '', 'file', 'global.about.php', 'default', 'orange', '[RIGHT]', 0, '1', '0', 'global', 1, 11, 1), 
(86, 4, 'Giới thiệu', '', 'file', 'global.about.php', 'default', 'orange', '[RIGHT]', 0, '1', '0', 'global', 1, 3, 1), 
(87, 4, 'Giới thiệu', '', 'file', 'global.about.php', 'default', 'orange', '[RIGHT]', 0, '1', '0', 'global', 1, 9, 1), 
(88, 4, 'Giới thiệu', '', 'file', 'global.about.php', 'default', 'orange', '[RIGHT]', 0, '1', '0', 'global', 1, 48, 1), 
(89, 4, 'Giới thiệu', '', 'file', 'global.about.php', 'default', 'orange', '[RIGHT]', 0, '1', '0', 'global', 1, 41, 1), 
(90, 4, 'Giới thiệu', '', 'file', 'global.about.php', 'default', 'orange', '[RIGHT]', 0, '1', '0', 'global', 1, 40, 1), 
(91, 4, 'Giới thiệu', '', 'file', 'global.about.php', 'default', 'orange', '[RIGHT]', 0, '1', '0', 'global', 1, 38, 1), 
(92, 4, 'Giới thiệu', '', 'file', 'global.about.php', 'default', 'orange', '[RIGHT]', 0, '1', '0', 'global', 1, 37, 1), 
(93, 4, 'Giới thiệu', '', 'file', 'global.about.php', 'default', 'orange', '[RIGHT]', 0, '1', '0', 'global', 1, 39, 1), 
(94, 4, 'Giới thiệu', '', 'file', 'global.about.php', 'default', 'orange', '[RIGHT]', 0, '1', '0', 'global', 1, 36, 1), 
(95, 4, 'Giới thiệu', '', 'file', 'global.about.php', 'default', 'orange', '[RIGHT]', 0, '1', '0', 'global', 1, 42, 1), 
(96, 4, 'Giới thiệu', '', 'file', 'global.about.php', 'default', 'orange', '[RIGHT]', 0, '1', '0', 'global', 1, 33, 1), 
(97, 4, 'Giới thiệu', '', 'file', 'global.about.php', 'default', 'orange', '[RIGHT]', 0, '1', '0', 'global', 1, 29, 1), 
(98, 4, 'Giới thiệu', '', 'file', 'global.about.php', 'default', 'orange', '[RIGHT]', 0, '1', '0', 'global', 1, 30, 1), 
(99, 4, 'Giới thiệu', '', 'file', 'global.about.php', 'default', 'orange', '[RIGHT]', 0, '1', '0', 'global', 1, 34, 1), 
(100, 4, 'Giới thiệu', '', 'file', 'global.about.php', 'default', 'orange', '[RIGHT]', 0, '1', '0', 'global', 1, 32, 1), 
(101, 4, 'Giới thiệu', '', 'file', 'global.about.php', 'default', 'orange', '[RIGHT]', 0, '1', '0', 'global', 1, 27, 1), 
(102, 4, 'Giới thiệu', '', 'file', 'global.about.php', 'default', 'orange', '[RIGHT]', 0, '1', '0', 'global', 1, 26, 1), 
(103, 4, 'Giới thiệu', '', 'file', 'global.about.php', 'default', 'orange', '[RIGHT]', 0, '1', '0', 'global', 1, 28, 1), 
(104, 4, 'Giới thiệu', '', 'file', 'global.about.php', 'default', 'orange', '[RIGHT]', 0, '1', '0', 'global', 1, 31, 1), 
(105, 4, 'Giới thiệu', '', 'file', 'global.about.php', 'default', 'orange', '[RIGHT]', 0, '1', '0', 'global', 1, 22, 1), 
(106, 4, 'Giới thiệu', '', 'file', 'global.about.php', 'default', 'orange', '[RIGHT]', 0, '1', '0', 'global', 1, 24, 1), 
(107, 4, 'Giới thiệu', '', 'file', 'global.about.php', 'default', 'orange', '[RIGHT]', 0, '1', '0', 'global', 1, 20, 1), 
(108, 5, 'Thăm dò ý kiến', '', 'file', 'global.voting.php', 'default', '', '[RIGHT]', 0, '1', '0', 'global', 1, 1, 3), 
(109, 5, 'Thăm dò ý kiến', '', 'file', 'global.voting.php', 'default', '', '[RIGHT]', 0, '1', '0', 'global', 1, 46, 3), 
(110, 5, 'Thăm dò ý kiến', '', 'file', 'global.voting.php', 'default', '', '[RIGHT]', 0, '1', '0', 'global', 1, 35, 3), 
(111, 5, 'Thăm dò ý kiến', '', 'file', 'global.voting.php', 'default', '', '[RIGHT]', 0, '1', '0', 'global', 1, 15, 3), 
(114, 5, 'Thăm dò ý kiến', '', 'file', 'global.voting.php', 'default', '', '[RIGHT]', 0, '1', '0', 'global', 1, 13, 3), 
(115, 5, 'Thăm dò ý kiến', '', 'file', 'global.voting.php', 'default', '', '[RIGHT]', 0, '1', '0', 'global', 1, 17, 3), 
(116, 5, 'Thăm dò ý kiến', '', 'file', 'global.voting.php', 'default', '', '[RIGHT]', 0, '1', '0', 'global', 1, 16, 3), 
(117, 5, 'Thăm dò ý kiến', '', 'file', 'global.voting.php', 'default', '', '[RIGHT]', 0, '1', '0', 'global', 1, 4, 3), 
(118, 5, 'Thăm dò ý kiến', '', 'file', 'global.voting.php', 'default', '', '[RIGHT]', 0, '1', '0', 'global', 1, 12, 3), 
(119, 5, 'Thăm dò ý kiến', '', 'file', 'global.voting.php', 'default', '', '[RIGHT]', 0, '1', '0', 'global', 1, 11, 3), 
(120, 5, 'Thăm dò ý kiến', '', 'file', 'global.voting.php', 'default', '', '[RIGHT]', 0, '1', '0', 'global', 1, 3, 3), 
(121, 5, 'Thăm dò ý kiến', '', 'file', 'global.voting.php', 'default', '', '[RIGHT]', 0, '1', '0', 'global', 1, 9, 3), 
(122, 5, 'Thăm dò ý kiến', '', 'file', 'global.voting.php', 'default', '', '[RIGHT]', 0, '1', '0', 'global', 1, 48, 3), 
(123, 5, 'Thăm dò ý kiến', '', 'file', 'global.voting.php', 'default', '', '[RIGHT]', 0, '1', '0', 'global', 1, 41, 3), 
(124, 5, 'Thăm dò ý kiến', '', 'file', 'global.voting.php', 'default', '', '[RIGHT]', 0, '1', '0', 'global', 1, 40, 3), 
(125, 5, 'Thăm dò ý kiến', '', 'file', 'global.voting.php', 'default', '', '[RIGHT]', 0, '1', '0', 'global', 1, 38, 3), 
(126, 5, 'Thăm dò ý kiến', '', 'file', 'global.voting.php', 'default', '', '[RIGHT]', 0, '1', '0', 'global', 1, 37, 3), 
(127, 5, 'Thăm dò ý kiến', '', 'file', 'global.voting.php', 'default', '', '[RIGHT]', 0, '1', '0', 'global', 1, 39, 3), 
(128, 5, 'Thăm dò ý kiến', '', 'file', 'global.voting.php', 'default', '', '[RIGHT]', 0, '1', '0', 'global', 1, 36, 3), 
(129, 5, 'Thăm dò ý kiến', '', 'file', 'global.voting.php', 'default', '', '[RIGHT]', 0, '1', '0', 'global', 1, 42, 3), 
(130, 5, 'Thăm dò ý kiến', '', 'file', 'global.voting.php', 'default', '', '[RIGHT]', 0, '1', '0', 'global', 1, 33, 3), 
(131, 5, 'Thăm dò ý kiến', '', 'file', 'global.voting.php', 'default', '', '[RIGHT]', 0, '1', '0', 'global', 1, 29, 3), 
(132, 5, 'Thăm dò ý kiến', '', 'file', 'global.voting.php', 'default', '', '[RIGHT]', 0, '1', '0', 'global', 1, 30, 3), 
(133, 5, 'Thăm dò ý kiến', '', 'file', 'global.voting.php', 'default', '', '[RIGHT]', 0, '1', '0', 'global', 1, 34, 3), 
(134, 5, 'Thăm dò ý kiến', '', 'file', 'global.voting.php', 'default', '', '[RIGHT]', 0, '1', '0', 'global', 1, 32, 3), 
(135, 5, 'Thăm dò ý kiến', '', 'file', 'global.voting.php', 'default', '', '[RIGHT]', 0, '1', '0', 'global', 1, 27, 3), 
(136, 5, 'Thăm dò ý kiến', '', 'file', 'global.voting.php', 'default', '', '[RIGHT]', 0, '1', '0', 'global', 1, 26, 3), 
(137, 5, 'Thăm dò ý kiến', '', 'file', 'global.voting.php', 'default', '', '[RIGHT]', 0, '1', '0', 'global', 1, 28, 3), 
(138, 5, 'Thăm dò ý kiến', '', 'file', 'global.voting.php', 'default', '', '[RIGHT]', 0, '1', '0', 'global', 1, 31, 3), 
(139, 5, 'Thăm dò ý kiến', '', 'file', 'global.voting.php', 'default', '', '[RIGHT]', 0, '1', '0', 'global', 1, 22, 3), 
(140, 5, 'Thăm dò ý kiến', '', 'file', 'global.voting.php', 'default', '', '[RIGHT]', 0, '1', '0', 'global', 1, 24, 3), 
(141, 5, 'Thăm dò ý kiến', '', 'file', 'global.voting.php', 'default', '', '[RIGHT]', 0, '1', '0', 'global', 1, 20, 3), 
(142, 6, 'Tin nổi bật', '', 'file', 'module.block_headline.php', 'default', 'no_title', '[TOP]', 0, '1', '0', 'news', 0, 4, 1), 
(143, 7, 'Quảng cáo giữa trang', '', 'banner', '1', 'default', 'no_title', '[TOP]', 0, '1', '0', '', 1, 1, 1), 
(144, 7, 'Quảng cáo giữa trang', '', 'banner', '1', 'default', 'no_title', '[TOP]', 0, '1', '0', '', 1, 46, 1), 
(145, 7, 'Quảng cáo giữa trang', '', 'banner', '1', 'default', 'no_title', '[TOP]', 0, '1', '0', '', 1, 35, 1), 
(146, 7, 'Quảng cáo giữa trang', '', 'banner', '1', 'default', 'no_title', '[TOP]', 0, '1', '0', '', 1, 15, 1), 
(149, 7, 'Quảng cáo giữa trang', '', 'banner', '1', 'default', 'no_title', '[TOP]', 0, '1', '0', '', 1, 13, 1), 
(150, 7, 'Quảng cáo giữa trang', '', 'banner', '1', 'default', 'no_title', '[TOP]', 0, '1', '0', '', 1, 17, 1), 
(151, 7, 'Quảng cáo giữa trang', '', 'banner', '1', 'default', 'no_title', '[TOP]', 0, '1', '0', '', 1, 16, 1), 
(152, 7, 'Quảng cáo giữa trang', '', 'banner', '1', 'default', 'no_title', '[TOP]', 0, '1', '0', '', 1, 4, 2), 
(153, 7, 'Quảng cáo giữa trang', '', 'banner', '1', 'default', 'no_title', '[TOP]', 0, '1', '0', '', 1, 12, 1), 
(154, 7, 'Quảng cáo giữa trang', '', 'banner', '1', 'default', 'no_title', '[TOP]', 0, '1', '0', '', 1, 11, 1), 
(155, 7, 'Quảng cáo giữa trang', '', 'banner', '1', 'default', 'no_title', '[TOP]', 0, '1', '0', '', 1, 3, 1), 
(156, 7, 'Quảng cáo giữa trang', '', 'banner', '1', 'default', 'no_title', '[TOP]', 0, '1', '0', '', 1, 9, 1), 
(157, 7, 'Quảng cáo giữa trang', '', 'banner', '1', 'default', 'no_title', '[TOP]', 0, '1', '0', '', 1, 48, 1), 
(158, 7, 'Quảng cáo giữa trang', '', 'banner', '1', 'default', 'no_title', '[TOP]', 0, '1', '0', '', 1, 41, 1), 
(159, 7, 'Quảng cáo giữa trang', '', 'banner', '1', 'default', 'no_title', '[TOP]', 0, '1', '0', '', 1, 40, 1), 
(160, 7, 'Quảng cáo giữa trang', '', 'banner', '1', 'default', 'no_title', '[TOP]', 0, '1', '0', '', 1, 38, 1), 
(161, 7, 'Quảng cáo giữa trang', '', 'banner', '1', 'default', 'no_title', '[TOP]', 0, '1', '0', '', 1, 37, 1), 
(162, 7, 'Quảng cáo giữa trang', '', 'banner', '1', 'default', 'no_title', '[TOP]', 0, '1', '0', '', 1, 39, 1), 
(163, 7, 'Quảng cáo giữa trang', '', 'banner', '1', 'default', 'no_title', '[TOP]', 0, '1', '0', '', 1, 36, 1), 
(164, 7, 'Quảng cáo giữa trang', '', 'banner', '1', 'default', 'no_title', '[TOP]', 0, '1', '0', '', 1, 42, 1), 
(165, 7, 'Quảng cáo giữa trang', '', 'banner', '1', 'default', 'no_title', '[TOP]', 0, '1', '0', '', 1, 33, 1), 
(166, 7, 'Quảng cáo giữa trang', '', 'banner', '1', 'default', 'no_title', '[TOP]', 0, '1', '0', '', 1, 29, 1), 
(167, 7, 'Quảng cáo giữa trang', '', 'banner', '1', 'default', 'no_title', '[TOP]', 0, '1', '0', '', 1, 30, 1), 
(168, 7, 'Quảng cáo giữa trang', '', 'banner', '1', 'default', 'no_title', '[TOP]', 0, '1', '0', '', 1, 34, 1), 
(169, 7, 'Quảng cáo giữa trang', '', 'banner', '1', 'default', 'no_title', '[TOP]', 0, '1', '0', '', 1, 32, 1), 
(170, 7, 'Quảng cáo giữa trang', '', 'banner', '1', 'default', 'no_title', '[TOP]', 0, '1', '0', '', 1, 27, 1), 
(171, 7, 'Quảng cáo giữa trang', '', 'banner', '1', 'default', 'no_title', '[TOP]', 0, '1', '0', '', 1, 26, 1), 
(172, 7, 'Quảng cáo giữa trang', '', 'banner', '1', 'default', 'no_title', '[TOP]', 0, '1', '0', '', 1, 28, 1), 
(173, 7, 'Quảng cáo giữa trang', '', 'banner', '1', 'default', 'no_title', '[TOP]', 0, '1', '0', '', 1, 31, 1), 
(174, 7, 'Quảng cáo giữa trang', '', 'banner', '1', 'default', 'no_title', '[TOP]', 0, '1', '0', '', 1, 22, 1), 
(175, 7, 'Quảng cáo giữa trang', '', 'banner', '1', 'default', 'no_title', '[TOP]', 0, '1', '0', '', 1, 24, 1), 
(176, 7, 'Quảng cáo giữa trang', '', 'banner', '1', 'default', 'no_title', '[TOP]', 0, '1', '0', '', 1, 20, 1), 
(177, 8, 'Đăng nhập thành viên', '', 'file', 'global.login.php', 'default', 'orange', '[RIGHT]', 0, '1', '0', 'global', 1, 1, 2), 
(178, 8, 'Đăng nhập thành viên', '', 'file', 'global.login.php', 'default', 'orange', '[RIGHT]', 0, '1', '0', 'global', 1, 46, 2), 
(179, 8, 'Đăng nhập thành viên', '', 'file', 'global.login.php', 'default', 'orange', '[RIGHT]', 0, '1', '0', 'global', 1, 35, 2), 
(180, 8, 'Đăng nhập thành viên', '', 'file', 'global.login.php', 'default', 'orange', '[RIGHT]', 0, '1', '0', 'global', 1, 15, 2), 
(183, 8, 'Đăng nhập thành viên', '', 'file', 'global.login.php', 'default', 'orange', '[RIGHT]', 0, '1', '0', 'global', 1, 13, 2), 
(184, 8, 'Đăng nhập thành viên', '', 'file', 'global.login.php', 'default', 'orange', '[RIGHT]', 0, '1', '0', 'global', 1, 17, 2), 
(185, 8, 'Đăng nhập thành viên', '', 'file', 'global.login.php', 'default', 'orange', '[RIGHT]', 0, '1', '0', 'global', 1, 16, 2), 
(186, 8, 'Đăng nhập thành viên', '', 'file', 'global.login.php', 'default', 'orange', '[RIGHT]', 0, '1', '0', 'global', 1, 4, 2), 
(187, 8, 'Đăng nhập thành viên', '', 'file', 'global.login.php', 'default', 'orange', '[RIGHT]', 0, '1', '0', 'global', 1, 12, 2), 
(188, 8, 'Đăng nhập thành viên', '', 'file', 'global.login.php', 'default', 'orange', '[RIGHT]', 0, '1', '0', 'global', 1, 11, 2), 
(189, 8, 'Đăng nhập thành viên', '', 'file', 'global.login.php', 'default', 'orange', '[RIGHT]', 0, '1', '0', 'global', 1, 3, 2), 
(190, 8, 'Đăng nhập thành viên', '', 'file', 'global.login.php', 'default', 'orange', '[RIGHT]', 0, '1', '0', 'global', 1, 9, 2), 
(191, 8, 'Đăng nhập thành viên', '', 'file', 'global.login.php', 'default', 'orange', '[RIGHT]', 0, '1', '0', 'global', 1, 48, 2), 
(192, 8, 'Đăng nhập thành viên', '', 'file', 'global.login.php', 'default', 'orange', '[RIGHT]', 0, '1', '0', 'global', 1, 41, 2), 
(193, 8, 'Đăng nhập thành viên', '', 'file', 'global.login.php', 'default', 'orange', '[RIGHT]', 0, '1', '0', 'global', 1, 40, 2), 
(194, 8, 'Đăng nhập thành viên', '', 'file', 'global.login.php', 'default', 'orange', '[RIGHT]', 0, '1', '0', 'global', 1, 38, 2), 
(195, 8, 'Đăng nhập thành viên', '', 'file', 'global.login.php', 'default', 'orange', '[RIGHT]', 0, '1', '0', 'global', 1, 37, 2), 
(196, 8, 'Đăng nhập thành viên', '', 'file', 'global.login.php', 'default', 'orange', '[RIGHT]', 0, '1', '0', 'global', 1, 39, 2), 
(197, 8, 'Đăng nhập thành viên', '', 'file', 'global.login.php', 'default', 'orange', '[RIGHT]', 0, '1', '0', 'global', 1, 36, 2), 
(198, 8, 'Đăng nhập thành viên', '', 'file', 'global.login.php', 'default', 'orange', '[RIGHT]', 0, '1', '0', 'global', 1, 42, 2), 
(199, 8, 'Đăng nhập thành viên', '', 'file', 'global.login.php', 'default', 'orange', '[RIGHT]', 0, '1', '0', 'global', 1, 33, 2), 
(200, 8, 'Đăng nhập thành viên', '', 'file', 'global.login.php', 'default', 'orange', '[RIGHT]', 0, '1', '0', 'global', 1, 29, 2), 
(201, 8, 'Đăng nhập thành viên', '', 'file', 'global.login.php', 'default', 'orange', '[RIGHT]', 0, '1', '0', 'global', 1, 30, 2), 
(202, 8, 'Đăng nhập thành viên', '', 'file', 'global.login.php', 'default', 'orange', '[RIGHT]', 0, '1', '0', 'global', 1, 34, 2), 
(203, 8, 'Đăng nhập thành viên', '', 'file', 'global.login.php', 'default', 'orange', '[RIGHT]', 0, '1', '0', 'global', 1, 32, 2), 
(204, 8, 'Đăng nhập thành viên', '', 'file', 'global.login.php', 'default', 'orange', '[RIGHT]', 0, '1', '0', 'global', 1, 27, 2), 
(205, 8, 'Đăng nhập thành viên', '', 'file', 'global.login.php', 'default', 'orange', '[RIGHT]', 0, '1', '0', 'global', 1, 26, 2), 
(206, 8, 'Đăng nhập thành viên', '', 'file', 'global.login.php', 'default', 'orange', '[RIGHT]', 0, '1', '0', 'global', 1, 28, 2), 
(207, 8, 'Đăng nhập thành viên', '', 'file', 'global.login.php', 'default', 'orange', '[RIGHT]', 0, '1', '0', 'global', 1, 31, 2), 
(208, 8, 'Đăng nhập thành viên', '', 'file', 'global.login.php', 'default', 'orange', '[RIGHT]', 0, '1', '0', 'global', 1, 22, 2), 
(209, 8, 'Đăng nhập thành viên', '', 'file', 'global.login.php', 'default', 'orange', '[RIGHT]', 0, '1', '0', 'global', 1, 24, 2), 
(210, 8, 'Đăng nhập thành viên', '', 'file', 'global.login.php', 'default', 'orange', '[RIGHT]', 0, '1', '0', 'global', 1, 20, 3), 
(212, 2, 'Thống kê truy cập', '', 'file', 'global.counter.php', 'default', '', '[LEFT]', 0, '1', '0', 'global', 1, 51, 1), 
(214, 3, 'Quảng cáo trái', '', 'banner', '2', 'default', '', '[LEFT]', 0, '1', '0', 'global', 1, 51, 2), 
(216, 4, 'Giới thiệu', '', 'file', 'global.about.php', 'default', 'orange', '[RIGHT]', 0, '1', '0', 'global', 1, 51, 1), 
(218, 5, 'Thăm dò ý kiến', '', 'file', 'global.voting.php', 'default', '', '[RIGHT]', 0, '1', '0', 'global', 1, 51, 2), 
(220, 7, 'Quảng cáo giữa trang', '', 'banner', '1', 'default', 'no_title', '[TOP]', 0, '1', '0', '', 1, 51, 1), 
(222, 8, 'Đăng nhập thành viên', '', 'file', 'global.login.php', 'default', 'orange', '[RIGHT]', 0, '1', '0', 'global', 1, 51, 3), 
(223, 2, 'Thống kê truy cập', '', 'file', 'global.counter.php', 'default', '', '[LEFT]', 0, '1', '0', 'global', 1, 54, 1), 
(224, 3, 'Quảng cáo trái', '', 'banner', '2', 'default', '', '[LEFT]', 0, '1', '0', 'global', 1, 54, 2), 
(225, 4, 'Giới thiệu', '', 'file', 'global.about.php', 'default', 'orange', '[RIGHT]', 0, '1', '0', 'global', 1, 54, 1), 
(226, 5, 'Thăm dò ý kiến', '', 'file', 'global.voting.php', 'default', '', '[RIGHT]', 0, '1', '0', 'global', 1, 54, 2), 
(227, 7, 'Quảng cáo giữa trang', '', 'banner', '1', 'default', 'no_title', '[TOP]', 0, '1', '0', '', 1, 54, 1), 
(228, 8, 'Đăng nhập thành viên', '', 'file', 'global.login.php', 'default', 'orange', '[RIGHT]', 0, '1', '0', 'global', 1, 54, 3), 
(229, 9, 'News', '', 'file', 'module.block_newscenter.php', 'modern', 'no_title', '[HEADER]', 0, '1', '0', 'news', 0, 4, 1), 
(230, 10, 'Giới thiệu', '', 'file', 'global.about.php', 'modern', 'no_title_html', '[RIGHT]', 0, '1', '0', 'global', 1, 1, 4), 
(231, 10, 'Giới thiệu', '', 'file', 'global.about.php', 'modern', 'no_title_html', '[RIGHT]', 0, '1', '0', 'global', 1, 46, 4), 
(232, 10, 'Giới thiệu', '', 'file', 'global.about.php', 'modern', 'no_title_html', '[RIGHT]', 0, '1', '0', 'global', 1, 58, 1), 
(233, 10, 'Giới thiệu', '', 'file', 'global.about.php', 'modern', 'no_title_html', '[RIGHT]', 0, '1', '0', 'global', 1, 60, 1), 
(234, 10, 'Giới thiệu', '', 'file', 'global.about.php', 'modern', 'no_title_html', '[RIGHT]', 0, '1', '0', 'global', 1, 63, 1), 
(235, 10, 'Giới thiệu', '', 'file', 'global.about.php', 'modern', 'no_title_html', '[RIGHT]', 0, '1', '0', 'global', 1, 35, 4), 
(236, 10, 'Giới thiệu', '', 'file', 'global.about.php', 'modern', 'no_title_html', '[RIGHT]', 0, '1', '0', 'global', 1, 65, 1), 
(237, 10, 'Giới thiệu', '', 'file', 'global.about.php', 'modern', 'no_title_html', '[RIGHT]', 0, '1', '0', 'global', 1, 15, 4), 
(238, 10, 'Giới thiệu', '', 'file', 'global.about.php', 'modern', 'no_title_html', '[RIGHT]', 0, '1', '0', 'global', 1, 66, 1), 
(239, 10, 'Giới thiệu', '', 'file', 'global.about.php', 'modern', 'no_title_html', '[RIGHT]', 0, '1', '0', 'global', 1, 67, 1), 
(240, 10, 'Giới thiệu', '', 'file', 'global.about.php', 'modern', 'no_title_html', '[RIGHT]', 0, '1', '0', 'global', 1, 13, 4), 
(241, 10, 'Giới thiệu', '', 'file', 'global.about.php', 'modern', 'no_title_html', '[RIGHT]', 0, '1', '0', 'global', 1, 17, 4), 
(242, 10, 'Giới thiệu', '', 'file', 'global.about.php', 'modern', 'no_title_html', '[RIGHT]', 0, '1', '0', 'global', 1, 16, 4), 
(243, 10, 'Giới thiệu', '', 'file', 'global.about.php', 'modern', 'no_title_html', '[RIGHT]', 0, '1', '0', 'global', 1, 4, 4), 
(244, 10, 'Giới thiệu', '', 'file', 'global.about.php', 'modern', 'no_title_html', '[RIGHT]', 0, '1', '0', 'global', 1, 12, 4), 
(245, 10, 'Giới thiệu', '', 'file', 'global.about.php', 'modern', 'no_title_html', '[RIGHT]', 0, '1', '0', 'global', 1, 11, 4), 
(246, 10, 'Giới thiệu', '', 'file', 'global.about.php', 'modern', 'no_title_html', '[RIGHT]', 0, '1', '0', 'global', 1, 3, 4), 
(247, 10, 'Giới thiệu', '', 'file', 'global.about.php', 'modern', 'no_title_html', '[RIGHT]', 0, '1', '0', 'global', 1, 9, 4), 
(248, 10, 'Giới thiệu', '', 'file', 'global.about.php', 'modern', 'no_title_html', '[RIGHT]', 0, '1', '0', 'global', 1, 54, 4), 
(249, 10, 'Giới thiệu', '', 'file', 'global.about.php', 'modern', 'no_title_html', '[RIGHT]', 0, '1', '0', 'global', 1, 48, 4), 
(250, 10, 'Giới thiệu', '', 'file', 'global.about.php', 'modern', 'no_title_html', '[RIGHT]', 0, '1', '0', 'global', 1, 41, 4), 
(251, 10, 'Giới thiệu', '', 'file', 'global.about.php', 'modern', 'no_title_html', '[RIGHT]', 0, '1', '0', 'global', 1, 40, 4), 
(252, 10, 'Giới thiệu', '', 'file', 'global.about.php', 'modern', 'no_title_html', '[RIGHT]', 0, '1', '0', 'global', 1, 38, 4), 
(253, 10, 'Giới thiệu', '', 'file', 'global.about.php', 'modern', 'no_title_html', '[RIGHT]', 0, '1', '0', 'global', 1, 37, 4), 
(254, 10, 'Giới thiệu', '', 'file', 'global.about.php', 'modern', 'no_title_html', '[RIGHT]', 0, '1', '0', 'global', 1, 39, 4), 
(255, 10, 'Giới thiệu', '', 'file', 'global.about.php', 'modern', 'no_title_html', '[RIGHT]', 0, '1', '0', 'global', 1, 36, 4), 
(256, 10, 'Giới thiệu', '', 'file', 'global.about.php', 'modern', 'no_title_html', '[RIGHT]', 0, '1', '0', 'global', 1, 42, 4), 
(257, 10, 'Giới thiệu', '', 'file', 'global.about.php', 'modern', 'no_title_html', '[RIGHT]', 0, '1', '0', 'global', 1, 33, 4), 
(258, 10, 'Giới thiệu', '', 'file', 'global.about.php', 'modern', 'no_title_html', '[RIGHT]', 0, '1', '0', 'global', 1, 29, 4), 
(259, 10, 'Giới thiệu', '', 'file', 'global.about.php', 'modern', 'no_title_html', '[RIGHT]', 0, '1', '0', 'global', 1, 30, 4), 
(260, 10, 'Giới thiệu', '', 'file', 'global.about.php', 'modern', 'no_title_html', '[RIGHT]', 0, '1', '0', 'global', 1, 34, 4), 
(261, 10, 'Giới thiệu', '', 'file', 'global.about.php', 'modern', 'no_title_html', '[RIGHT]', 0, '1', '0', 'global', 1, 32, 4), 
(262, 10, 'Giới thiệu', '', 'file', 'global.about.php', 'modern', 'no_title_html', '[RIGHT]', 0, '1', '0', 'global', 1, 51, 4), 
(263, 10, 'Giới thiệu', '', 'file', 'global.about.php', 'modern', 'no_title_html', '[RIGHT]', 0, '1', '0', 'global', 1, 27, 4), 
(264, 10, 'Giới thiệu', '', 'file', 'global.about.php', 'modern', 'no_title_html', '[RIGHT]', 0, '1', '0', 'global', 1, 26, 4), 
(265, 10, 'Giới thiệu', '', 'file', 'global.about.php', 'modern', 'no_title_html', '[RIGHT]', 0, '1', '0', 'global', 1, 28, 4), 
(266, 10, 'Giới thiệu', '', 'file', 'global.about.php', 'modern', 'no_title_html', '[RIGHT]', 0, '1', '0', 'global', 1, 31, 4), 
(267, 10, 'Giới thiệu', '', 'file', 'global.about.php', 'modern', 'no_title_html', '[RIGHT]', 0, '1', '0', 'global', 1, 22, 4), 
(268, 10, 'Giới thiệu', '', 'file', 'global.about.php', 'modern', 'no_title_html', '[RIGHT]', 0, '1', '0', 'global', 1, 24, 4), 
(269, 10, 'Giới thiệu', '', 'file', 'global.about.php', 'modern', 'no_title_html', '[RIGHT]', 0, '1', '0', 'global', 1, 20, 4), 
(270, 11, 'Đăng nhập', '', 'file', 'global.login.php', 'modern', '', '[RIGHT]', 0, '1', '0', 'global', 1, 1, 5), 
(271, 11, 'Đăng nhập', '', 'file', 'global.login.php', 'modern', '', '[RIGHT]', 0, '1', '0', 'global', 1, 46, 5), 
(272, 11, 'Đăng nhập', '', 'file', 'global.login.php', 'modern', '', '[RIGHT]', 0, '1', '0', 'global', 1, 58, 2), 
(273, 11, 'Đăng nhập', '', 'file', 'global.login.php', 'modern', '', '[RIGHT]', 0, '1', '0', 'global', 1, 60, 2), 
(274, 11, 'Đăng nhập', '', 'file', 'global.login.php', 'modern', '', '[RIGHT]', 0, '1', '0', 'global', 1, 63, 2), 
(275, 11, 'Đăng nhập', '', 'file', 'global.login.php', 'modern', '', '[RIGHT]', 0, '1', '0', 'global', 1, 35, 5), 
(276, 11, 'Đăng nhập', '', 'file', 'global.login.php', 'modern', '', '[RIGHT]', 0, '1', '0', 'global', 1, 65, 2), 
(277, 11, 'Đăng nhập', '', 'file', 'global.login.php', 'modern', '', '[RIGHT]', 0, '1', '0', 'global', 1, 15, 5), 
(278, 11, 'Đăng nhập', '', 'file', 'global.login.php', 'modern', '', '[RIGHT]', 0, '1', '0', 'global', 1, 66, 2), 
(279, 11, 'Đăng nhập', '', 'file', 'global.login.php', 'modern', '', '[RIGHT]', 0, '1', '0', 'global', 1, 67, 2), 
(280, 11, 'Đăng nhập', '', 'file', 'global.login.php', 'modern', '', '[RIGHT]', 0, '1', '0', 'global', 1, 13, 5), 
(281, 11, 'Đăng nhập', '', 'file', 'global.login.php', 'modern', '', '[RIGHT]', 0, '1', '0', 'global', 1, 17, 5), 
(282, 11, 'Đăng nhập', '', 'file', 'global.login.php', 'modern', '', '[RIGHT]', 0, '1', '0', 'global', 1, 16, 5), 
(283, 11, 'Đăng nhập', '', 'file', 'global.login.php', 'modern', '', '[RIGHT]', 0, '1', '0', 'global', 1, 4, 5), 
(284, 11, 'Đăng nhập', '', 'file', 'global.login.php', 'modern', '', '[RIGHT]', 0, '1', '0', 'global', 1, 12, 5), 
(285, 11, 'Đăng nhập', '', 'file', 'global.login.php', 'modern', '', '[RIGHT]', 0, '1', '0', 'global', 1, 11, 5), 
(286, 11, 'Đăng nhập', '', 'file', 'global.login.php', 'modern', '', '[RIGHT]', 0, '1', '0', 'global', 1, 3, 5), 
(287, 11, 'Đăng nhập', '', 'file', 'global.login.php', 'modern', '', '[RIGHT]', 0, '1', '0', 'global', 1, 9, 5), 
(288, 11, 'Đăng nhập', '', 'file', 'global.login.php', 'modern', '', '[RIGHT]', 0, '1', '0', 'global', 1, 54, 5), 
(289, 11, 'Đăng nhập', '', 'file', 'global.login.php', 'modern', '', '[RIGHT]', 0, '1', '0', 'global', 1, 48, 5), 
(290, 11, 'Đăng nhập', '', 'file', 'global.login.php', 'modern', '', '[RIGHT]', 0, '1', '0', 'global', 1, 41, 5), 
(291, 11, 'Đăng nhập', '', 'file', 'global.login.php', 'modern', '', '[RIGHT]', 0, '1', '0', 'global', 1, 40, 5), 
(292, 11, 'Đăng nhập', '', 'file', 'global.login.php', 'modern', '', '[RIGHT]', 0, '1', '0', 'global', 1, 38, 5), 
(293, 11, 'Đăng nhập', '', 'file', 'global.login.php', 'modern', '', '[RIGHT]', 0, '1', '0', 'global', 1, 37, 5), 
(294, 11, 'Đăng nhập', '', 'file', 'global.login.php', 'modern', '', '[RIGHT]', 0, '1', '0', 'global', 1, 39, 5), 
(295, 11, 'Đăng nhập', '', 'file', 'global.login.php', 'modern', '', '[RIGHT]', 0, '1', '0', 'global', 1, 36, 5), 
(296, 11, 'Đăng nhập', '', 'file', 'global.login.php', 'modern', '', '[RIGHT]', 0, '1', '0', 'global', 1, 42, 5), 
(297, 11, 'Đăng nhập', '', 'file', 'global.login.php', 'modern', '', '[RIGHT]', 0, '1', '0', 'global', 1, 33, 5), 
(298, 11, 'Đăng nhập', '', 'file', 'global.login.php', 'modern', '', '[RIGHT]', 0, '1', '0', 'global', 1, 29, 5), 
(299, 11, 'Đăng nhập', '', 'file', 'global.login.php', 'modern', '', '[RIGHT]', 0, '1', '0', 'global', 1, 30, 5), 
(300, 11, 'Đăng nhập', '', 'file', 'global.login.php', 'modern', '', '[RIGHT]', 0, '1', '0', 'global', 1, 34, 5), 
(301, 11, 'Đăng nhập', '', 'file', 'global.login.php', 'modern', '', '[RIGHT]', 0, '1', '0', 'global', 1, 32, 5), 
(302, 11, 'Đăng nhập', '', 'file', 'global.login.php', 'modern', '', '[RIGHT]', 0, '1', '0', 'global', 1, 51, 5), 
(303, 11, 'Đăng nhập', '', 'file', 'global.login.php', 'modern', '', '[RIGHT]', 0, '1', '0', 'global', 1, 27, 5), 
(304, 11, 'Đăng nhập', '', 'file', 'global.login.php', 'modern', '', '[RIGHT]', 0, '1', '0', 'global', 1, 26, 5), 
(305, 11, 'Đăng nhập', '', 'file', 'global.login.php', 'modern', '', '[RIGHT]', 0, '1', '0', 'global', 1, 28, 5), 
(306, 11, 'Đăng nhập', '', 'file', 'global.login.php', 'modern', '', '[RIGHT]', 0, '1', '0', 'global', 1, 31, 5), 
(307, 11, 'Đăng nhập', '', 'file', 'global.login.php', 'modern', '', '[RIGHT]', 0, '1', '0', 'global', 1, 22, 5), 
(308, 11, 'Đăng nhập', '', 'file', 'global.login.php', 'modern', '', '[RIGHT]', 0, '1', '0', 'global', 1, 24, 5), 
(309, 11, 'Đăng nhập', '', 'file', 'global.login.php', 'modern', '', '[RIGHT]', 0, '1', '0', 'global', 1, 20, 5), 
(310, 12, 'Thăm dò ý kiến', '', 'file', 'global.voting.php', 'modern', '', '[RIGHT]', 0, '1', '0', 'global', 1, 1, 6), 
(311, 12, 'Thăm dò ý kiến', '', 'file', 'global.voting.php', 'modern', '', '[RIGHT]', 0, '1', '0', 'global', 1, 46, 6), 
(312, 12, 'Thăm dò ý kiến', '', 'file', 'global.voting.php', 'modern', '', '[RIGHT]', 0, '1', '0', 'global', 1, 58, 3), 
(313, 12, 'Thăm dò ý kiến', '', 'file', 'global.voting.php', 'modern', '', '[RIGHT]', 0, '1', '0', 'global', 1, 60, 3), 
(314, 12, 'Thăm dò ý kiến', '', 'file', 'global.voting.php', 'modern', '', '[RIGHT]', 0, '1', '0', 'global', 1, 63, 3), 
(315, 12, 'Thăm dò ý kiến', '', 'file', 'global.voting.php', 'modern', '', '[RIGHT]', 0, '1', '0', 'global', 1, 35, 6), 
(316, 12, 'Thăm dò ý kiến', '', 'file', 'global.voting.php', 'modern', '', '[RIGHT]', 0, '1', '0', 'global', 1, 65, 3), 
(317, 12, 'Thăm dò ý kiến', '', 'file', 'global.voting.php', 'modern', '', '[RIGHT]', 0, '1', '0', 'global', 1, 15, 6), 
(318, 12, 'Thăm dò ý kiến', '', 'file', 'global.voting.php', 'modern', '', '[RIGHT]', 0, '1', '0', 'global', 1, 66, 3), 
(319, 12, 'Thăm dò ý kiến', '', 'file', 'global.voting.php', 'modern', '', '[RIGHT]', 0, '1', '0', 'global', 1, 67, 3), 
(320, 12, 'Thăm dò ý kiến', '', 'file', 'global.voting.php', 'modern', '', '[RIGHT]', 0, '1', '0', 'global', 1, 13, 6), 
(321, 12, 'Thăm dò ý kiến', '', 'file', 'global.voting.php', 'modern', '', '[RIGHT]', 0, '1', '0', 'global', 1, 17, 6), 
(322, 12, 'Thăm dò ý kiến', '', 'file', 'global.voting.php', 'modern', '', '[RIGHT]', 0, '1', '0', 'global', 1, 16, 6), 
(323, 12, 'Thăm dò ý kiến', '', 'file', 'global.voting.php', 'modern', '', '[RIGHT]', 0, '1', '0', 'global', 1, 4, 6), 
(324, 12, 'Thăm dò ý kiến', '', 'file', 'global.voting.php', 'modern', '', '[RIGHT]', 0, '1', '0', 'global', 1, 12, 6), 
(325, 12, 'Thăm dò ý kiến', '', 'file', 'global.voting.php', 'modern', '', '[RIGHT]', 0, '1', '0', 'global', 1, 11, 6), 
(326, 12, 'Thăm dò ý kiến', '', 'file', 'global.voting.php', 'modern', '', '[RIGHT]', 0, '1', '0', 'global', 1, 3, 6), 
(327, 12, 'Thăm dò ý kiến', '', 'file', 'global.voting.php', 'modern', '', '[RIGHT]', 0, '1', '0', 'global', 1, 9, 6), 
(328, 12, 'Thăm dò ý kiến', '', 'file', 'global.voting.php', 'modern', '', '[RIGHT]', 0, '1', '0', 'global', 1, 54, 6), 
(329, 12, 'Thăm dò ý kiến', '', 'file', 'global.voting.php', 'modern', '', '[RIGHT]', 0, '1', '0', 'global', 1, 48, 6), 
(330, 12, 'Thăm dò ý kiến', '', 'file', 'global.voting.php', 'modern', '', '[RIGHT]', 0, '1', '0', 'global', 1, 41, 6), 
(331, 12, 'Thăm dò ý kiến', '', 'file', 'global.voting.php', 'modern', '', '[RIGHT]', 0, '1', '0', 'global', 1, 40, 6), 
(332, 12, 'Thăm dò ý kiến', '', 'file', 'global.voting.php', 'modern', '', '[RIGHT]', 0, '1', '0', 'global', 1, 38, 6), 
(333, 12, 'Thăm dò ý kiến', '', 'file', 'global.voting.php', 'modern', '', '[RIGHT]', 0, '1', '0', 'global', 1, 37, 6), 
(334, 12, 'Thăm dò ý kiến', '', 'file', 'global.voting.php', 'modern', '', '[RIGHT]', 0, '1', '0', 'global', 1, 39, 6), 
(335, 12, 'Thăm dò ý kiến', '', 'file', 'global.voting.php', 'modern', '', '[RIGHT]', 0, '1', '0', 'global', 1, 36, 6), 
(336, 12, 'Thăm dò ý kiến', '', 'file', 'global.voting.php', 'modern', '', '[RIGHT]', 0, '1', '0', 'global', 1, 42, 6), 
(337, 12, 'Thăm dò ý kiến', '', 'file', 'global.voting.php', 'modern', '', '[RIGHT]', 0, '1', '0', 'global', 1, 33, 6), 
(338, 12, 'Thăm dò ý kiến', '', 'file', 'global.voting.php', 'modern', '', '[RIGHT]', 0, '1', '0', 'global', 1, 29, 6), 
(339, 12, 'Thăm dò ý kiến', '', 'file', 'global.voting.php', 'modern', '', '[RIGHT]', 0, '1', '0', 'global', 1, 30, 6), 
(340, 12, 'Thăm dò ý kiến', '', 'file', 'global.voting.php', 'modern', '', '[RIGHT]', 0, '1', '0', 'global', 1, 34, 6), 
(341, 12, 'Thăm dò ý kiến', '', 'file', 'global.voting.php', 'modern', '', '[RIGHT]', 0, '1', '0', 'global', 1, 32, 6), 
(342, 12, 'Thăm dò ý kiến', '', 'file', 'global.voting.php', 'modern', '', '[RIGHT]', 0, '1', '0', 'global', 1, 51, 6), 
(343, 12, 'Thăm dò ý kiến', '', 'file', 'global.voting.php', 'modern', '', '[RIGHT]', 0, '1', '0', 'global', 1, 27, 6), 
(344, 12, 'Thăm dò ý kiến', '', 'file', 'global.voting.php', 'modern', '', '[RIGHT]', 0, '1', '0', 'global', 1, 26, 6), 
(345, 12, 'Thăm dò ý kiến', '', 'file', 'global.voting.php', 'modern', '', '[RIGHT]', 0, '1', '0', 'global', 1, 28, 6), 
(346, 12, 'Thăm dò ý kiến', '', 'file', 'global.voting.php', 'modern', '', '[RIGHT]', 0, '1', '0', 'global', 1, 31, 6), 
(347, 12, 'Thăm dò ý kiến', '', 'file', 'global.voting.php', 'modern', '', '[RIGHT]', 0, '1', '0', 'global', 1, 22, 6), 
(348, 12, 'Thăm dò ý kiến', '', 'file', 'global.voting.php', 'modern', '', '[RIGHT]', 0, '1', '0', 'global', 1, 24, 6), 
(349, 12, 'Thăm dò ý kiến', '', 'file', 'global.voting.php', 'modern', '', '[RIGHT]', 0, '1', '0', 'global', 1, 20, 6), 
(350, 13, 'Bộ đếm', '', 'file', 'global.counter.php', 'modern', '', '[RIGHT]', 0, '1', '0', 'global', 1, 1, 7), 
(351, 13, 'Bộ đếm', '', 'file', 'global.counter.php', 'modern', '', '[RIGHT]', 0, '1', '0', 'global', 1, 46, 7), 
(352, 13, 'Bộ đếm', '', 'file', 'global.counter.php', 'modern', '', '[RIGHT]', 0, '1', '0', 'global', 1, 58, 4), 
(353, 13, 'Bộ đếm', '', 'file', 'global.counter.php', 'modern', '', '[RIGHT]', 0, '1', '0', 'global', 1, 60, 4), 
(354, 13, 'Bộ đếm', '', 'file', 'global.counter.php', 'modern', '', '[RIGHT]', 0, '1', '0', 'global', 1, 63, 4), 
(355, 13, 'Bộ đếm', '', 'file', 'global.counter.php', 'modern', '', '[RIGHT]', 0, '1', '0', 'global', 1, 35, 7), 
(356, 13, 'Bộ đếm', '', 'file', 'global.counter.php', 'modern', '', '[RIGHT]', 0, '1', '0', 'global', 1, 65, 4), 
(357, 13, 'Bộ đếm', '', 'file', 'global.counter.php', 'modern', '', '[RIGHT]', 0, '1', '0', 'global', 1, 15, 7), 
(358, 13, 'Bộ đếm', '', 'file', 'global.counter.php', 'modern', '', '[RIGHT]', 0, '1', '0', 'global', 1, 66, 4), 
(359, 13, 'Bộ đếm', '', 'file', 'global.counter.php', 'modern', '', '[RIGHT]', 0, '1', '0', 'global', 1, 67, 4), 
(360, 13, 'Bộ đếm', '', 'file', 'global.counter.php', 'modern', '', '[RIGHT]', 0, '1', '0', 'global', 1, 13, 7), 
(361, 13, 'Bộ đếm', '', 'file', 'global.counter.php', 'modern', '', '[RIGHT]', 0, '1', '0', 'global', 1, 17, 7), 
(362, 13, 'Bộ đếm', '', 'file', 'global.counter.php', 'modern', '', '[RIGHT]', 0, '1', '0', 'global', 1, 16, 7), 
(363, 13, 'Bộ đếm', '', 'file', 'global.counter.php', 'modern', '', '[RIGHT]', 0, '1', '0', 'global', 1, 4, 7), 
(364, 13, 'Bộ đếm', '', 'file', 'global.counter.php', 'modern', '', '[RIGHT]', 0, '1', '0', 'global', 1, 12, 7), 
(365, 13, 'Bộ đếm', '', 'file', 'global.counter.php', 'modern', '', '[RIGHT]', 0, '1', '0', 'global', 1, 11, 7), 
(366, 13, 'Bộ đếm', '', 'file', 'global.counter.php', 'modern', '', '[RIGHT]', 0, '1', '0', 'global', 1, 3, 7), 
(367, 13, 'Bộ đếm', '', 'file', 'global.counter.php', 'modern', '', '[RIGHT]', 0, '1', '0', 'global', 1, 9, 7), 
(368, 13, 'Bộ đếm', '', 'file', 'global.counter.php', 'modern', '', '[RIGHT]', 0, '1', '0', 'global', 1, 54, 7), 
(369, 13, 'Bộ đếm', '', 'file', 'global.counter.php', 'modern', '', '[RIGHT]', 0, '1', '0', 'global', 1, 48, 7), 
(370, 13, 'Bộ đếm', '', 'file', 'global.counter.php', 'modern', '', '[RIGHT]', 0, '1', '0', 'global', 1, 41, 7), 
(371, 13, 'Bộ đếm', '', 'file', 'global.counter.php', 'modern', '', '[RIGHT]', 0, '1', '0', 'global', 1, 40, 7), 
(372, 13, 'Bộ đếm', '', 'file', 'global.counter.php', 'modern', '', '[RIGHT]', 0, '1', '0', 'global', 1, 38, 7), 
(373, 13, 'Bộ đếm', '', 'file', 'global.counter.php', 'modern', '', '[RIGHT]', 0, '1', '0', 'global', 1, 37, 7), 
(374, 13, 'Bộ đếm', '', 'file', 'global.counter.php', 'modern', '', '[RIGHT]', 0, '1', '0', 'global', 1, 39, 7), 
(375, 13, 'Bộ đếm', '', 'file', 'global.counter.php', 'modern', '', '[RIGHT]', 0, '1', '0', 'global', 1, 36, 7), 
(376, 13, 'Bộ đếm', '', 'file', 'global.counter.php', 'modern', '', '[RIGHT]', 0, '1', '0', 'global', 1, 42, 7), 
(377, 13, 'Bộ đếm', '', 'file', 'global.counter.php', 'modern', '', '[RIGHT]', 0, '1', '0', 'global', 1, 33, 7), 
(378, 13, 'Bộ đếm', '', 'file', 'global.counter.php', 'modern', '', '[RIGHT]', 0, '1', '0', 'global', 1, 29, 7), 
(379, 13, 'Bộ đếm', '', 'file', 'global.counter.php', 'modern', '', '[RIGHT]', 0, '1', '0', 'global', 1, 30, 7), 
(380, 13, 'Bộ đếm', '', 'file', 'global.counter.php', 'modern', '', '[RIGHT]', 0, '1', '0', 'global', 1, 34, 7), 
(381, 13, 'Bộ đếm', '', 'file', 'global.counter.php', 'modern', '', '[RIGHT]', 0, '1', '0', 'global', 1, 32, 7), 
(382, 13, 'Bộ đếm', '', 'file', 'global.counter.php', 'modern', '', '[RIGHT]', 0, '1', '0', 'global', 1, 51, 7), 
(383, 13, 'Bộ đếm', '', 'file', 'global.counter.php', 'modern', '', '[RIGHT]', 0, '1', '0', 'global', 1, 27, 7), 
(384, 13, 'Bộ đếm', '', 'file', 'global.counter.php', 'modern', '', '[RIGHT]', 0, '1', '0', 'global', 1, 26, 7), 
(385, 13, 'Bộ đếm', '', 'file', 'global.counter.php', 'modern', '', '[RIGHT]', 0, '1', '0', 'global', 1, 28, 7), 
(386, 13, 'Bộ đếm', '', 'file', 'global.counter.php', 'modern', '', '[RIGHT]', 0, '1', '0', 'global', 1, 31, 7), 
(387, 13, 'Bộ đếm', '', 'file', 'global.counter.php', 'modern', '', '[RIGHT]', 0, '1', '0', 'global', 1, 22, 7), 
(388, 13, 'Bộ đếm', '', 'file', 'global.counter.php', 'modern', '', '[RIGHT]', 0, '1', '0', 'global', 1, 24, 7), 
(389, 13, 'Bộ đếm', '', 'file', 'global.counter.php', 'modern', '', '[RIGHT]', 0, '1', '0', 'global', 1, 20, 7), 
(390, 14, 'News Right', '', 'file', 'module.block_newsright.php', 'modern', 'no_title', '[RIGHT]', 0, '1', '0', 'news', 0, 4, 8), 
(391, 14, 'News Right', '', 'file', 'module.block_newsright.php', 'modern', 'no_title', '[RIGHT]', 0, '1', '0', 'news', 0, 12, 8), 
(392, 14, 'News Right', '', 'file', 'module.block_newsright.php', 'modern', 'no_title', '[RIGHT]', 0, '1', '0', 'news', 0, 11, 8), 
(393, 14, 'News Right', '', 'file', 'module.block_newsright.php', 'modern', 'no_title', '[RIGHT]', 0, '1', '0', 'news', 0, 3, 8), 
(394, 14, 'News Right', '', 'file', 'module.block_newsright.php', 'modern', 'no_title', '[RIGHT]', 0, '1', '0', 'news', 0, 9, 8), 
(395, 15, 'Quảng cáo top banner', '', 'banner', '1', 'modern', 'no_title', '[TOPADV]', 0, '1', '0', '', 1, 1, 1), 
(396, 15, 'Quảng cáo top banner', '', 'banner', '1', 'modern', 'no_title', '[TOPADV]', 0, '1', '0', '', 1, 46, 1), 
(397, 15, 'Quảng cáo top banner', '', 'banner', '1', 'modern', 'no_title', '[TOPADV]', 0, '1', '0', '', 1, 58, 1), 
(398, 15, 'Quảng cáo top banner', '', 'banner', '1', 'modern', 'no_title', '[TOPADV]', 0, '1', '0', '', 1, 60, 1), 
(399, 15, 'Quảng cáo top banner', '', 'banner', '1', 'modern', 'no_title', '[TOPADV]', 0, '1', '0', '', 1, 63, 1), 
(400, 15, 'Quảng cáo top banner', '', 'banner', '1', 'modern', 'no_title', '[TOPADV]', 0, '1', '0', '', 1, 35, 1), 
(401, 15, 'Quảng cáo top banner', '', 'banner', '1', 'modern', 'no_title', '[TOPADV]', 0, '1', '0', '', 1, 65, 1), 
(402, 15, 'Quảng cáo top banner', '', 'banner', '1', 'modern', 'no_title', '[TOPADV]', 0, '1', '0', '', 1, 15, 1), 
(403, 15, 'Quảng cáo top banner', '', 'banner', '1', 'modern', 'no_title', '[TOPADV]', 0, '1', '0', '', 1, 66, 1), 
(404, 15, 'Quảng cáo top banner', '', 'banner', '1', 'modern', 'no_title', '[TOPADV]', 0, '1', '0', '', 1, 67, 1), 
(405, 15, 'Quảng cáo top banner', '', 'banner', '1', 'modern', 'no_title', '[TOPADV]', 0, '1', '0', '', 1, 13, 1), 
(406, 15, 'Quảng cáo top banner', '', 'banner', '1', 'modern', 'no_title', '[TOPADV]', 0, '1', '0', '', 1, 17, 1), 
(407, 15, 'Quảng cáo top banner', '', 'banner', '1', 'modern', 'no_title', '[TOPADV]', 0, '1', '0', '', 1, 16, 1), 
(408, 15, 'Quảng cáo top banner', '', 'banner', '1', 'modern', 'no_title', '[TOPADV]', 0, '1', '0', '', 1, 4, 1), 
(409, 15, 'Quảng cáo top banner', '', 'banner', '1', 'modern', 'no_title', '[TOPADV]', 0, '1', '0', '', 1, 12, 1), 
(410, 15, 'Quảng cáo top banner', '', 'banner', '1', 'modern', 'no_title', '[TOPADV]', 0, '1', '0', '', 1, 11, 1), 
(411, 15, 'Quảng cáo top banner', '', 'banner', '1', 'modern', 'no_title', '[TOPADV]', 0, '1', '0', '', 1, 3, 1), 
(412, 15, 'Quảng cáo top banner', '', 'banner', '1', 'modern', 'no_title', '[TOPADV]', 0, '1', '0', '', 1, 9, 1), 
(413, 15, 'Quảng cáo top banner', '', 'banner', '1', 'modern', 'no_title', '[TOPADV]', 0, '1', '0', '', 1, 54, 1), 
(414, 15, 'Quảng cáo top banner', '', 'banner', '1', 'modern', 'no_title', '[TOPADV]', 0, '1', '0', '', 1, 48, 1), 
(415, 15, 'Quảng cáo top banner', '', 'banner', '1', 'modern', 'no_title', '[TOPADV]', 0, '1', '0', '', 1, 41, 1), 
(416, 15, 'Quảng cáo top banner', '', 'banner', '1', 'modern', 'no_title', '[TOPADV]', 0, '1', '0', '', 1, 40, 1), 
(417, 15, 'Quảng cáo top banner', '', 'banner', '1', 'modern', 'no_title', '[TOPADV]', 0, '1', '0', '', 1, 38, 1), 
(418, 15, 'Quảng cáo top banner', '', 'banner', '1', 'modern', 'no_title', '[TOPADV]', 0, '1', '0', '', 1, 37, 1), 
(419, 15, 'Quảng cáo top banner', '', 'banner', '1', 'modern', 'no_title', '[TOPADV]', 0, '1', '0', '', 1, 39, 1), 
(420, 15, 'Quảng cáo top banner', '', 'banner', '1', 'modern', 'no_title', '[TOPADV]', 0, '1', '0', '', 1, 36, 1), 
(421, 15, 'Quảng cáo top banner', '', 'banner', '1', 'modern', 'no_title', '[TOPADV]', 0, '1', '0', '', 1, 42, 1), 
(422, 15, 'Quảng cáo top banner', '', 'banner', '1', 'modern', 'no_title', '[TOPADV]', 0, '1', '0', '', 1, 33, 1), 
(423, 15, 'Quảng cáo top banner', '', 'banner', '1', 'modern', 'no_title', '[TOPADV]', 0, '1', '0', '', 1, 29, 1), 
(424, 15, 'Quảng cáo top banner', '', 'banner', '1', 'modern', 'no_title', '[TOPADV]', 0, '1', '0', '', 1, 30, 1), 
(425, 15, 'Quảng cáo top banner', '', 'banner', '1', 'modern', 'no_title', '[TOPADV]', 0, '1', '0', '', 1, 34, 1), 
(426, 15, 'Quảng cáo top banner', '', 'banner', '1', 'modern', 'no_title', '[TOPADV]', 0, '1', '0', '', 1, 32, 1), 
(427, 15, 'Quảng cáo top banner', '', 'banner', '1', 'modern', 'no_title', '[TOPADV]', 0, '1', '0', '', 1, 51, 1), 
(428, 15, 'Quảng cáo top banner', '', 'banner', '1', 'modern', 'no_title', '[TOPADV]', 0, '1', '0', '', 1, 27, 1), 
(429, 15, 'Quảng cáo top banner', '', 'banner', '1', 'modern', 'no_title', '[TOPADV]', 0, '1', '0', '', 1, 26, 1), 
(430, 15, 'Quảng cáo top banner', '', 'banner', '1', 'modern', 'no_title', '[TOPADV]', 0, '1', '0', '', 1, 28, 1), 
(431, 15, 'Quảng cáo top banner', '', 'banner', '1', 'modern', 'no_title', '[TOPADV]', 0, '1', '0', '', 1, 31, 1), 
(432, 15, 'Quảng cáo top banner', '', 'banner', '1', 'modern', 'no_title', '[TOPADV]', 0, '1', '0', '', 1, 22, 1), 
(433, 15, 'Quảng cáo top banner', '', 'banner', '1', 'modern', 'no_title', '[TOPADV]', 0, '1', '0', '', 1, 24, 1), 
(434, 15, 'Quảng cáo top banner', '', 'banner', '1', 'modern', 'no_title', '[TOPADV]', 0, '1', '0', '', 1, 20, 1);


-- ---------------------------------------


--
-- Table structure for table `nv_vi_contact_rows`
--

DROP TABLE IF EXISTS `nv_vi_contact_rows`;
CREATE TABLE `nv_vi_contact_rows` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `full_name` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `fax` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `note` mediumtext NOT NULL,
  `admins` mediumtext NOT NULL,
  `act` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `full_name` (`full_name`)
) ENGINE=MyISAM  AUTO_INCREMENT=2  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv_vi_contact_rows`
--

INSERT INTO `nv_vi_contact_rows` VALUES
(1, 'Webmaster', '', '', '', '', '1/1/1/0;', 1);


-- ---------------------------------------


--
-- Table structure for table `nv_vi_contact_send`
--

DROP TABLE IF EXISTS `nv_vi_contact_send`;
CREATE TABLE `nv_vi_contact_send` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `cid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL,
  `content` mediumtext NOT NULL,
  `send_time` int(11) unsigned NOT NULL DEFAULT '0',
  `sender_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `sender_name` varchar(100) NOT NULL,
  `sender_email` varchar(100) NOT NULL,
  `sender_phone` varchar(255) NOT NULL,
  `sender_ip` varchar(15) NOT NULL,
  `is_read` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `is_reply` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `reply_content` mediumtext NOT NULL,
  `reply_time` int(11) unsigned NOT NULL DEFAULT '0',
  `reply_aid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `sender_name` (`sender_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv_vi_counter`
--

DROP TABLE IF EXISTS `nv_vi_counter`;
CREATE TABLE `nv_vi_counter` (
  `c_type` varchar(100) NOT NULL,
  `c_val` varchar(100) NOT NULL,
  `c_count` int(11) unsigned NOT NULL DEFAULT '0',
  `last_update` int(11) NOT NULL DEFAULT '0',
  UNIQUE KEY `c_type` (`c_type`,`c_val`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv_vi_counter`
--

INSERT INTO `nv_vi_counter` VALUES
('c_time', 'start', 0, 0), 
('c_time', 'last', 1295627120, 0), 
('total', 'hits', 1, 1295627120), 
('year', '2009', 0, 0), 
('year', '2010', 0, 0), 
('year', '2011', 1, 1295627120), 
('year', '2012', 0, 0), 
('year', '2013', 0, 0), 
('year', '2014', 0, 0), 
('year', '2015', 0, 0), 
('year', '2016', 0, 0), 
('year', '2017', 0, 0), 
('year', '2018', 0, 0), 
('year', '2019', 0, 0), 
('year', '2020', 0, 0), 
('month', 'Jan', 1, 1295627120), 
('month', 'Feb', 0, 0), 
('month', 'Mar', 0, 0), 
('month', 'Apr', 0, 0), 
('month', 'May', 0, 0), 
('month', 'Jun', 0, 0), 
('month', 'Jul', 0, 0), 
('month', 'Aug', 0, 0), 
('month', 'Sep', 0, 0), 
('month', 'Oct', 0, 0), 
('month', 'Nov', 0, 0), 
('month', 'Dec', 0, 0), 
('day', '01', 0, 0), 
('day', '02', 0, 0), 
('day', '03', 0, 0), 
('day', '04', 0, 0), 
('day', '05', 0, 0), 
('day', '06', 0, 0), 
('day', '07', 0, 0), 
('day', '08', 0, 0), 
('day', '09', 0, 0), 
('day', '10', 0, 0), 
('day', '11', 0, 0), 
('day', '12', 0, 0), 
('day', '13', 0, 0), 
('day', '14', 0, 0), 
('day', '15', 0, 0), 
('day', '16', 0, 0), 
('day', '17', 0, 0), 
('day', '18', 0, 0), 
('day', '19', 0, 0), 
('day', '20', 0, 0), 
('day', '21', 1, 1295627120), 
('day', '22', 0, 0), 
('day', '23', 0, 0), 
('day', '24', 0, 0), 
('day', '25', 0, 0), 
('day', '26', 0, 0), 
('day', '27', 0, 0), 
('day', '28', 0, 0), 
('day', '29', 0, 0), 
('day', '30', 0, 0), 
('day', '31', 0, 0), 
('dayofweek', 'Sunday', 0, 0), 
('dayofweek', 'Monday', 0, 0), 
('dayofweek', 'Tuesday', 0, 0), 
('dayofweek', 'Wednesday', 0, 0), 
('dayofweek', 'Thursday', 0, 0), 
('dayofweek', 'Friday', 1, 1295627120), 
('dayofweek', 'Saturday', 0, 0), 
('hour', '00', 0, 0), 
('hour', '01', 0, 0), 
('hour', '02', 0, 0), 
('hour', '03', 0, 0), 
('hour', '04', 0, 0), 
('hour', '05', 0, 0), 
('hour', '06', 0, 0), 
('hour', '07', 0, 0), 
('hour', '08', 0, 0), 
('hour', '09', 0, 0), 
('hour', '10', 0, 0), 
('hour', '11', 0, 0), 
('hour', '12', 0, 0), 
('hour', '13', 0, 0), 
('hour', '14', 0, 0), 
('hour', '15', 0, 0), 
('hour', '16', 0, 0), 
('hour', '17', 0, 0), 
('hour', '18', 0, 0), 
('hour', '19', 0, 0), 
('hour', '20', 0, 0), 
('hour', '21', 0, 0), 
('hour', '22', 0, 0), 
('hour', '23', 1, 1295627120), 
('bot', 'Alexa', 0, 0), 
('bot', 'AltaVista Scooter', 0, 0), 
('bot', 'Altavista Mercator', 0, 0), 
('bot', 'Altavista Search', 0, 0), 
('bot', 'Aport.ru Bot', 0, 0), 
('bot', 'Ask Jeeves', 0, 0), 
('bot', 'Baidu', 0, 0), 
('bot', 'Exabot', 0, 0), 
('bot', 'FAST Enterprise', 0, 0), 
('bot', 'FAST WebCrawler', 0, 0), 
('bot', 'Francis', 0, 0), 
('bot', 'Gigablast', 0, 0), 
('bot', 'Google AdsBot', 0, 0), 
('bot', 'Google Adsense', 0, 0), 
('bot', 'Google Bot', 0, 0), 
('bot', 'Google Desktop', 0, 0), 
('bot', 'Google Feedfetcher', 0, 0), 
('bot', 'Heise IT-Markt', 0, 0), 
('bot', 'Heritrix', 0, 0), 
('bot', 'IBM Research', 0, 0), 
('bot', 'ICCrawler - ICjobs', 0, 0), 
('bot', 'Ichiro', 0, 0), 
('bot', 'InfoSeek Spider', 0, 0), 
('bot', 'Lycos.com Bot', 0, 0), 
('bot', 'MSN Bot', 0, 0), 
('bot', 'MSN Bot Media', 0, 0), 
('bot', 'MSN Bot News', 0, 0), 
('bot', 'MSN NewsBlogs', 0, 0), 
('bot', 'Majestic-12', 0, 0), 
('bot', 'Metager', 0, 0), 
('bot', 'NG-Search', 0, 0), 
('bot', 'Nutch Bot', 0, 0), 
('bot', 'NutchCVS', 0, 0), 
('bot', 'OmniExplorer', 0, 0), 
('bot', 'Online Link Validator', 0, 0), 
('bot', 'Open-source Web Search', 0, 0), 
('bot', 'Psbot', 0, 0), 
('bot', 'Rambler', 0, 0), 
('bot', 'SEO Crawler', 0, 0), 
('bot', 'SEOSearch', 0, 0), 
('bot', 'Seekport', 0, 0), 
('bot', 'Sensis', 0, 0), 
('bot', 'Seoma', 0, 0), 
('bot', 'Snappy', 0, 0), 
('bot', 'Steeler', 0, 0), 
('bot', 'Synoo', 0, 0), 
('bot', 'Telekom', 0, 0), 
('bot', 'TurnitinBot', 0, 0), 
('bot', 'Vietnamese Search', 0, 0), 
('bot', 'Voyager', 0, 0), 
('bot', 'W3 Sitesearch', 0, 0), 
('bot', 'W3C Linkcheck', 0, 0), 
('bot', 'W3C Validator', 0, 0), 
('bot', 'WiseNut', 0, 0), 
('bot', 'YaCy', 0, 0), 
('bot', 'Yahoo Bot', 0, 0), 
('bot', 'Yahoo MMCrawler', 0, 0), 
('bot', 'Yahoo Slurp', 0, 0), 
('bot', 'YahooSeeker', 0, 0), 
('bot', 'Yandex', 0, 0), 
('bot', 'Yandex Blog', 0, 0), 
('bot', 'Yandex Direct Bot', 0, 0), 
('bot', 'Yandex Something', 0, 0), 
('browser', 'netcaptor', 0, 0), 
('browser', 'opera', 0, 0), 
('browser', 'aol', 0, 0), 
('browser', 'aol2', 0, 0), 
('browser', 'mosaic', 0, 0), 
('browser', 'k-meleon', 0, 0), 
('browser', 'konqueror', 0, 0), 
('browser', 'avantbrowser', 0, 0), 
('browser', 'avantgo', 0, 0), 
('browser', 'proxomitron', 0, 0), 
('browser', 'chrome', 0, 0), 
('browser', 'safari', 0, 0), 
('browser', 'lynx', 0, 0), 
('browser', 'links', 0, 0), 
('browser', 'galeon', 0, 0), 
('browser', 'abrowse', 0, 0), 
('browser', 'amaya', 0, 0), 
('browser', 'ant', 0, 0), 
('browser', 'aweb', 0, 0), 
('browser', 'beonex', 0, 0), 
('browser', 'blazer', 0, 0), 
('browser', 'camino', 0, 0), 
('browser', 'chimera', 0, 0), 
('browser', 'columbus', 0, 0), 
('browser', 'crazybrowser', 0, 0), 
('browser', 'curl', 0, 0), 
('browser', 'deepnet', 0, 0), 
('browser', 'dillo', 0, 0), 
('browser', 'doris', 0, 0), 
('browser', 'elinks', 0, 0), 
('browser', 'epiphany', 0, 0), 
('browser', 'ibrowse', 0, 0), 
('browser', 'icab', 0, 0), 
('browser', 'ice', 0, 0), 
('browser', 'isilox', 0, 0), 
('browser', 'lotus', 0, 0), 
('browser', 'lunascape', 0, 0), 
('browser', 'maxthon', 0, 0), 
('browser', 'mbrowser', 0, 0), 
('browser', 'multibrowser', 0, 0), 
('browser', 'nautilus', 0, 0), 
('browser', 'netfront', 0, 0), 
('browser', 'netpositive', 0, 0), 
('browser', 'omniweb', 0, 0), 
('browser', 'oregano', 0, 0), 
('browser', 'phaseout', 0, 0), 
('browser', 'plink', 0, 0), 
('browser', 'phoenix', 0, 0), 
('browser', 'shiira', 0, 0), 
('browser', 'sleipnir', 0, 0), 
('browser', 'slimbrowser', 0, 0), 
('browser', 'staroffice', 0, 0), 
('browser', 'sunrise', 0, 0), 
('browser', 'voyager', 0, 0), 
('browser', 'w3m', 0, 0), 
('browser', 'webtv', 0, 0), 
('browser', 'xiino', 0, 0), 
('browser', 'explorer', 0, 0), 
('browser', 'firefox', 1, 1295627120), 
('browser', 'netscape', 0, 0), 
('browser', 'netscape2', 0, 0), 
('browser', 'mozilla', 0, 0), 
('browser', 'mozilla2', 0, 0), 
('browser', 'firebird', 0, 0), 
('browser', 'Mobile', 0, 0), 
('browser', 'Unknown', 0, 0), 
('os', 'windows7', 0, 0), 
('os', 'windowsvista', 0, 0), 
('os', 'windows2003', 0, 0), 
('os', 'windowsxp', 0, 0), 
('os', 'windowsxp2', 0, 0), 
('os', 'windows2k', 0, 0), 
('os', 'windows95', 0, 0), 
('os', 'windowsce', 0, 0), 
('os', 'windowsme', 0, 0), 
('os', 'windowsme2', 0, 0), 
('os', 'windowsnt', 0, 0), 
('os', 'windowsnt2', 0, 0), 
('os', 'windows98', 0, 0), 
('os', 'windows', 0, 0), 
('os', 'linux', 0, 0), 
('os', 'linux2', 1, 1295627120), 
('os', 'linux3', 0, 0), 
('os', 'macosx', 0, 0), 
('os', 'macppc', 0, 0), 
('os', 'mac', 0, 0), 
('os', 'amiga', 0, 0), 
('os', 'beos', 0, 0), 
('os', 'freebsd', 0, 0), 
('os', 'freebsd2', 0, 0), 
('os', 'irix', 0, 0), 
('os', 'netbsd', 0, 0), 
('os', 'netbsd2', 0, 0), 
('os', 'os2', 0, 0), 
('os', 'os22', 0, 0), 
('os', 'openbsd', 0, 0), 
('os', 'openbsd2', 0, 0), 
('os', 'palm', 0, 0), 
('os', 'palm2', 0, 0), 
('os', 'Unspecified', 0, 0), 
('country', 'AD', 0, 0), 
('country', 'AE', 0, 0), 
('country', 'AF', 0, 0), 
('country', 'AG', 0, 0), 
('country', 'AI', 0, 0), 
('country', 'AL', 0, 0), 
('country', 'AM', 0, 0), 
('country', 'AN', 0, 0), 
('country', 'AO', 0, 0), 
('country', 'AQ', 0, 0), 
('country', 'AR', 0, 0), 
('country', 'AS', 0, 0), 
('country', 'AT', 0, 0), 
('country', 'AU', 0, 0), 
('country', 'AW', 0, 0), 
('country', 'AZ', 0, 0), 
('country', 'BA', 0, 0), 
('country', 'BB', 0, 0), 
('country', 'BD', 0, 0), 
('country', 'BE', 0, 0), 
('country', 'BF', 0, 0), 
('country', 'BG', 0, 0), 
('country', 'BH', 0, 0), 
('country', 'BI', 0, 0), 
('country', 'BJ', 0, 0), 
('country', 'BM', 0, 0), 
('country', 'BN', 0, 0), 
('country', 'BO', 0, 0), 
('country', 'BR', 0, 0), 
('country', 'BS', 0, 0), 
('country', 'BT', 0, 0), 
('country', 'BW', 0, 0), 
('country', 'BY', 0, 0), 
('country', 'BZ', 0, 0), 
('country', 'CA', 0, 0), 
('country', 'CD', 0, 0), 
('country', 'CF', 0, 0), 
('country', 'CG', 0, 0), 
('country', 'CH', 0, 0), 
('country', 'CI', 0, 0), 
('country', 'CK', 0, 0), 
('country', 'CL', 0, 0), 
('country', 'CM', 0, 0), 
('country', 'CN', 0, 0), 
('country', 'CO', 0, 0), 
('country', 'CR', 0, 0), 
('country', 'CS', 0, 0), 
('country', 'CU', 0, 0), 
('country', 'CV', 0, 0), 
('country', 'CY', 0, 0), 
('country', 'CZ', 0, 0), 
('country', 'DE', 0, 0), 
('country', 'DJ', 0, 0), 
('country', 'DK', 0, 0), 
('country', 'DM', 0, 0), 
('country', 'DO', 0, 0), 
('country', 'DZ', 0, 0), 
('country', 'EC', 0, 0), 
('country', 'EE', 0, 0), 
('country', 'EG', 0, 0), 
('country', 'ER', 0, 0), 
('country', 'ES', 0, 0), 
('country', 'ET', 0, 0), 
('country', 'EU', 0, 0), 
('country', 'FI', 0, 0), 
('country', 'FJ', 0, 0), 
('country', 'FK', 0, 0), 
('country', 'FM', 0, 0), 
('country', 'FO', 0, 0), 
('country', 'FR', 0, 0), 
('country', 'GA', 0, 0), 
('country', 'GB', 0, 0), 
('country', 'GD', 0, 0), 
('country', 'GE', 0, 0), 
('country', 'GF', 0, 0), 
('country', 'GH', 0, 0), 
('country', 'GI', 0, 0), 
('country', 'GL', 0, 0), 
('country', 'GM', 0, 0), 
('country', 'GN', 0, 0), 
('country', 'GP', 0, 0), 
('country', 'GQ', 0, 0), 
('country', 'GR', 0, 0), 
('country', 'GS', 0, 0), 
('country', 'GT', 0, 0), 
('country', 'GU', 0, 0), 
('country', 'GW', 0, 0), 
('country', 'GY', 0, 0), 
('country', 'HK', 0, 0), 
('country', 'HN', 0, 0), 
('country', 'HR', 0, 0), 
('country', 'HT', 0, 0), 
('country', 'HU', 0, 0), 
('country', 'ID', 0, 0), 
('country', 'IE', 0, 0), 
('country', 'IL', 0, 0), 
('country', 'IN', 0, 0), 
('country', 'IO', 0, 0), 
('country', 'IQ', 0, 0), 
('country', 'IR', 0, 0), 
('country', 'IS', 0, 0), 
('country', 'IT', 0, 0), 
('country', 'JM', 0, 0), 
('country', 'JO', 0, 0), 
('country', 'JP', 0, 0), 
('country', 'KE', 0, 0), 
('country', 'KG', 0, 0), 
('country', 'KH', 0, 0), 
('country', 'KI', 0, 0), 
('country', 'KM', 0, 0), 
('country', 'KN', 0, 0), 
('country', 'KR', 0, 0), 
('country', 'KW', 0, 0), 
('country', 'KY', 0, 0), 
('country', 'KZ', 0, 0), 
('country', 'LA', 0, 0), 
('country', 'LB', 0, 0), 
('country', 'LC', 0, 0), 
('country', 'LI', 0, 0), 
('country', 'LK', 0, 0), 
('country', 'LR', 0, 0), 
('country', 'LS', 0, 0), 
('country', 'LT', 0, 0), 
('country', 'LU', 0, 0), 
('country', 'LV', 0, 0), 
('country', 'LY', 0, 0), 
('country', 'MA', 0, 0), 
('country', 'MC', 0, 0), 
('country', 'MD', 0, 0), 
('country', 'MG', 0, 0), 
('country', 'MH', 0, 0), 
('country', 'MK', 0, 0), 
('country', 'ML', 0, 0), 
('country', 'MM', 0, 0), 
('country', 'MN', 0, 0), 
('country', 'MO', 0, 0), 
('country', 'MP', 0, 0), 
('country', 'MQ', 0, 0), 
('country', 'MR', 0, 0), 
('country', 'MT', 0, 0), 
('country', 'MU', 0, 0), 
('country', 'MV', 0, 0), 
('country', 'MW', 0, 0), 
('country', 'MX', 0, 0), 
('country', 'MY', 0, 0), 
('country', 'MZ', 0, 0), 
('country', 'NA', 0, 0), 
('country', 'NC', 0, 0), 
('country', 'NE', 0, 0), 
('country', 'NF', 0, 0), 
('country', 'NG', 0, 0), 
('country', 'NI', 0, 0), 
('country', 'NL', 0, 0), 
('country', 'NO', 0, 0), 
('country', 'NP', 0, 0), 
('country', 'NR', 0, 0), 
('country', 'NU', 0, 0), 
('country', 'NZ', 0, 0), 
('country', 'OM', 0, 0), 
('country', 'PA', 0, 0), 
('country', 'PE', 0, 0), 
('country', 'PF', 0, 0), 
('country', 'PG', 0, 0), 
('country', 'PH', 0, 0), 
('country', 'PK', 0, 0), 
('country', 'PL', 0, 0), 
('country', 'PR', 0, 0), 
('country', 'PS', 0, 0), 
('country', 'PT', 0, 0), 
('country', 'PW', 0, 0), 
('country', 'PY', 0, 0), 
('country', 'QA', 0, 0), 
('country', 'RE', 0, 0), 
('country', 'RO', 0, 0), 
('country', 'RU', 0, 0), 
('country', 'RW', 0, 0), 
('country', 'SA', 0, 0), 
('country', 'SB', 0, 0), 
('country', 'SC', 0, 0), 
('country', 'SD', 0, 0), 
('country', 'SE', 0, 0), 
('country', 'SG', 0, 0), 
('country', 'SI', 0, 0), 
('country', 'SK', 0, 0), 
('country', 'SL', 0, 0), 
('country', 'SM', 0, 0), 
('country', 'SN', 0, 0), 
('country', 'SO', 0, 0), 
('country', 'SR', 0, 0), 
('country', 'ST', 0, 0), 
('country', 'SV', 0, 0), 
('country', 'SY', 0, 0), 
('country', 'SZ', 0, 0), 
('country', 'TD', 0, 0), 
('country', 'TF', 0, 0), 
('country', 'TG', 0, 0), 
('country', 'TH', 0, 0), 
('country', 'TJ', 0, 0), 
('country', 'TK', 0, 0), 
('country', 'TL', 0, 0), 
('country', 'TM', 0, 0), 
('country', 'TN', 0, 0), 
('country', 'TO', 0, 0), 
('country', 'TR', 0, 0), 
('country', 'TT', 0, 0), 
('country', 'TV', 0, 0), 
('country', 'TW', 0, 0), 
('country', 'TZ', 0, 0), 
('country', 'UA', 0, 0), 
('country', 'UG', 0, 0), 
('country', 'US', 0, 0), 
('country', 'UY', 0, 0), 
('country', 'UZ', 0, 0), 
('country', 'VA', 0, 0), 
('country', 'VC', 0, 0), 
('country', 'VE', 0, 0), 
('country', 'VG', 0, 0), 
('country', 'VI', 0, 0), 
('country', 'VN', 0, 0), 
('country', 'VU', 0, 0), 
('country', 'WS', 0, 0), 
('country', 'YE', 0, 0), 
('country', 'YT', 0, 0), 
('country', 'YU', 0, 0), 
('country', 'ZA', 0, 0), 
('country', 'ZM', 0, 0), 
('country', 'ZW', 0, 0), 
('country', 'ZZ', 1, 1295627120), 
('country', 'unkown', 0, 0);


-- ---------------------------------------


--
-- Table structure for table `nv_vi_download`
--

DROP TABLE IF EXISTS `nv_vi_download`;
CREATE TABLE `nv_vi_download` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `catid` mediumint(8) unsigned NOT NULL,
  `title` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL,
  `description` mediumtext NOT NULL,
  `introtext` mediumtext NOT NULL,
  `uploadtime` int(11) unsigned NOT NULL,
  `updatetime` int(11) unsigned NOT NULL DEFAULT '0',
  `user_id` mediumint(8) unsigned NOT NULL,
  `user_name` varchar(100) NOT NULL,
  `author_name` varchar(100) NOT NULL,
  `author_email` varchar(60) NOT NULL,
  `author_url` varchar(255) NOT NULL,
  `fileupload` mediumtext NOT NULL,
  `linkdirect` mediumtext NOT NULL,
  `version` varchar(20) NOT NULL,
  `filesize` int(11) NOT NULL DEFAULT '0',
  `fileimage` varchar(255) NOT NULL,
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `copyright` varchar(255) NOT NULL,
  `view_hits` int(11) NOT NULL DEFAULT '0',
  `download_hits` int(11) NOT NULL DEFAULT '0',
  `comment_allow` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `who_comment` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `groups_comment` varchar(255) NOT NULL,
  `comment_hits` int(11) NOT NULL DEFAULT '0',
  `rating_detail` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `alias` (`alias`),
  KEY `catid` (`catid`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv_vi_download_categories`
--

DROP TABLE IF EXISTS `nv_vi_download_categories`;
CREATE TABLE `nv_vi_download_categories` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `parentid` mediumint(8) unsigned NOT NULL,
  `title` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL,
  `description` mediumtext NOT NULL,
  `who_view` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `groups_view` varchar(255) NOT NULL,
  `who_download` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `groups_download` varchar(255) NOT NULL,
  `weight` smallint(4) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv_vi_download_comments`
--

DROP TABLE IF EXISTS `nv_vi_download_comments`;
CREATE TABLE `nv_vi_download_comments` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `fid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `subject` varchar(255) NOT NULL,
  `post_id` mediumint(8) unsigned NOT NULL,
  `post_name` varchar(100) NOT NULL,
  `post_email` varchar(60) NOT NULL,
  `post_ip` varchar(45) NOT NULL,
  `post_time` int(11) unsigned NOT NULL DEFAULT '0',
  `comment` mediumtext NOT NULL,
  `admin_reply` varchar(255) NOT NULL,
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fid` (`fid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv_vi_download_config`
--

DROP TABLE IF EXISTS `nv_vi_download_config`;
CREATE TABLE `nv_vi_download_config` (
  `config_name` varchar(30) NOT NULL,
  `config_value` varchar(255) NOT NULL,
  UNIQUE KEY `config_name` (`config_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv_vi_download_config`
--

INSERT INTO `nv_vi_download_config` VALUES
('is_addfile', '1'), 
('is_upload', '1'), 
('who_upload', '1'), 
('groups_upload', ''), 
('maxfilesize', '2097152'), 
('upload_filetype', 'doc,xls,zip,rar'), 
('upload_dir', 'files'), 
('temp_dir', 'temp'), 
('who_autocomment', '0'), 
('groups_autocomment', ''), 
('who_addfile', '0'), 
('groups_addfile', ''), 
('is_zip', '1'), 
('is_resume', '1'), 
('max_speed', '0');


-- ---------------------------------------


--
-- Table structure for table `nv_vi_download_report`
--

DROP TABLE IF EXISTS `nv_vi_download_report`;
CREATE TABLE `nv_vi_download_report` (
  `fid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `post_ip` varchar(45) NOT NULL,
  `post_time` int(11) unsigned NOT NULL DEFAULT '0',
  UNIQUE KEY `fid` (`fid`),
  KEY `post_time` (`post_time`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv_vi_download_tmp`
--

DROP TABLE IF EXISTS `nv_vi_download_tmp`;
CREATE TABLE `nv_vi_download_tmp` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `catid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL,
  `description` mediumtext NOT NULL,
  `introtext` mediumtext NOT NULL,
  `uploadtime` int(11) unsigned NOT NULL DEFAULT '0',
  `user_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `user_name` varchar(100) NOT NULL,
  `author_name` varchar(100) NOT NULL,
  `author_email` varchar(60) NOT NULL,
  `author_url` varchar(255) NOT NULL,
  `fileupload` mediumtext NOT NULL,
  `linkdirect` mediumtext NOT NULL,
  `version` varchar(20) NOT NULL,
  `filesize` varchar(255) NOT NULL,
  `fileimage` varchar(255) NOT NULL,
  `copyright` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `title` (`title`),
  KEY `catid` (`catid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv_vi_modfuncs`
--

DROP TABLE IF EXISTS `nv_vi_modfuncs`;
CREATE TABLE `nv_vi_modfuncs` (
  `func_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `func_name` varchar(55) NOT NULL,
  `func_custom_name` varchar(255) NOT NULL,
  `in_module` varchar(55) NOT NULL,
  `show_func` tinyint(4) NOT NULL DEFAULT '0',
  `in_submenu` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `subweight` smallint(2) unsigned NOT NULL DEFAULT '1',
  `layout` varchar(50) NOT NULL DEFAULT 'leftbodyright',
  `setting` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`func_id`),
  UNIQUE KEY `func_name` (`func_name`,`in_module`)
) ENGINE=MyISAM  AUTO_INCREMENT=68  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv_vi_modfuncs`
--

INSERT INTO `nv_vi_modfuncs` VALUES
(1, 'main', 'Main', 'about', 1, 0, 1, 'body-right', ''), 
(2, 'comment', 'Comment', 'news', 0, 0, 0, 'body-right', ''), 
(3, 'detail', 'Detail', 'news', 1, 0, 4, 'body-right', ''), 
(4, 'main', 'Main', 'news', 1, 0, 1, 'body-right', ''), 
(7, 'rating', 'Rating', 'news', 0, 0, 0, 'body-right', ''), 
(8, 'savefile', 'Savefile', 'news', 0, 0, 0, 'body-right', ''), 
(9, 'search', 'Search', 'news', 1, 0, 5, 'body-right', ''), 
(10, 'sendmail', 'Sendmail', 'news', 0, 0, 0, 'body-right', ''), 
(11, 'topic', 'Topic', 'news', 1, 0, 3, 'body-right', ''), 
(12, 'viewcat', 'Viewcat', 'news', 1, 0, 2, 'body-right', ''), 
(13, 'down', 'Down', 'download', 1, 0, 4, 'body-right', ''), 
(14, 'getcomment', 'Getcomment', 'download', 0, 0, 0, 'body-right', ''), 
(15, 'main', 'Main', 'download', 1, 0, 1, 'body-right', ''), 
(16, 'report', 'Report', 'download', 1, 0, 6, 'body-right', ''), 
(17, 'upload', 'Upload', 'download', 1, 0, 5, 'body-right', ''), 
(20, 'detail', 'Detail', 'weblinks', 1, 0, 3, 'body-right', ''), 
(21, 'link', 'Link', 'weblinks', 0, 0, 0, 'body-right', ''), 
(22, 'main', 'Main', 'weblinks', 1, 0, 1, 'body-right', ''), 
(23, 'reportlink', 'Reportlink', 'weblinks', 0, 0, 0, 'body-right', ''), 
(24, 'viewcat', 'Viewcat', 'weblinks', 1, 0, 2, 'body-right', ''), 
(25, 'visitlink', 'Visitlink', 'weblinks', 0, 0, 0, 'body-right', ''), 
(26, 'active', 'Active', 'users', 1, 0, 7, 'body-right', ''), 
(27, 'changepass', 'Thay đổi mật khẩu', 'users', 1, 1, 6, 'body-right', ''), 
(28, 'editinfo', 'Editinfo', 'users', 1, 0, 8, 'body-right', ''), 
(29, 'login', 'Đăng nhập', 'users', 1, 1, 2, 'body-right', ''), 
(30, 'logout', 'Logout', 'users', 1, 0, 3, 'body-right', ''), 
(31, 'lostactivelink', 'Lostactivelink', 'users', 1, 0, 9, 'body-right', ''), 
(32, 'lostpass', 'Quên mật khẩu', 'users', 1, 1, 5, 'body-right', ''), 
(33, 'main', 'Main', 'users', 1, 0, 1, 'body-right', ''), 
(34, 'register', 'Đăng ký', 'users', 1, 1, 4, 'body-right', ''), 
(35, 'main', 'Main', 'contact', 1, 0, 1, 'body-right', ''), 
(36, 'allbots', 'Máy chủ tìm kiếm', 'statistics', 1, 1, 6, 'left-body', ''), 
(37, 'allbrowsers', 'Theo trình duyệt', 'statistics', 1, 1, 4, 'left-body', ''), 
(38, 'allcountries', 'Theo quốc gia', 'statistics', 1, 1, 3, 'left-body', ''), 
(39, 'allos', 'Theo hệ điều hành', 'statistics', 1, 1, 5, 'left-body', ''), 
(40, 'allreferers', 'Theo đường dẫn đến site', 'statistics', 1, 1, 2, 'left-body', ''), 
(41, 'main', 'Main', 'statistics', 1, 0, 1, 'left-body', ''), 
(42, 'referer', 'đường dẫn đến site theo tháng', 'statistics', 1, 0, 7, 'left-body', ''), 
(43, 'main', 'Main', 'voting', 0, 0, 0, 'body-right', ''), 
(44, 'result', 'Result', 'voting', 0, 0, 0, 'body-right', ''), 
(45, 'click', 'Click', 'banners', 0, 0, 0, 'body-right', ''), 
(46, 'main', 'Main', 'banners', 1, 0, 1, 'body-right', ''), 
(47, 'adv', 'Adv', 'search', 0, 0, 0, 'body-right', ''), 
(48, 'main', 'Main', 'search', 1, 0, 1, 'body-right', ''), 
(49, 'print', 'Print', 'news', 0, 0, 0, '', ''), 
(50, 'postcomment', 'Postcomment', 'news', 0, 0, 0, '', ''), 
(51, 'openid', 'Openid', 'users', 1, 1, 6, 'body-right', ''), 
(54, 'main', 'Main', 'rss', 1, 0, 1, 'body-right', ''), 
(55, 'rss', 'Rss', 'news', 0, 0, 0, '', ''), 
(56, 'rss', 'Rss', 'download', 0, 0, 0, '', ''), 
(57, 'rss', 'Rss', 'weblinks', 0, 0, 0, '', ''), 
(58, 'addads', 'Addads', 'banners', 1, 0, 1, 'body-right', ''), 
(59, 'cledit', 'Cledit', 'banners', 0, 0, 0, '', ''), 
(60, 'clientinfo', 'Clientinfo', 'banners', 1, 0, 2, 'body-right', ''), 
(61, 'clinfo', 'Clinfo', 'banners', 0, 0, 0, '', ''), 
(62, 'logininfo', 'Logininfo', 'banners', 0, 0, 0, '', ''), 
(63, 'stats', 'Stats', 'banners', 1, 0, 3, 'body-right', ''), 
(64, 'viewmap', 'Viewmap', 'banners', 0, 0, 0, '', ''), 
(65, 'search', 'Search', 'download', 1, 0, 1, 'body-right', ''), 
(66, 'viewcat', 'Viewcat', 'download', 1, 0, 2, 'body-right', ''), 
(67, 'viewfile', 'Viewfile', 'download', 1, 0, 3, 'body-right', '');


-- ---------------------------------------


--
-- Table structure for table `nv_vi_modthemes`
--

DROP TABLE IF EXISTS `nv_vi_modthemes`;
CREATE TABLE `nv_vi_modthemes` (
  `func_id` int(11) DEFAULT NULL,
  `layout` varchar(100) DEFAULT NULL,
  `theme` varchar(100) DEFAULT NULL,
  UNIQUE KEY `func_id` (`func_id`,`layout`,`theme`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv_vi_modthemes`
--

INSERT INTO `nv_vi_modthemes` VALUES
(0, 'body-right', 'modern'), 
(0, 'left-body-right', 'default'), 
(1, 'body', 'modern'), 
(1, 'left-body-right', 'default'), 
(3, 'body-right', 'modern'), 
(3, 'left-body-right', 'default'), 
(4, 'body-right', 'modern'), 
(4, 'left-body-right', 'default'), 
(9, 'body-right', 'modern'), 
(9, 'left-body-right', 'default'), 
(11, 'body-right', 'modern'), 
(11, 'left-body-right', 'default'), 
(12, 'body-right', 'modern'), 
(12, 'left-body-right', 'default'), 
(13, 'body-right', 'modern'), 
(13, 'left-body-right', 'default'), 
(15, 'body-right', 'modern'), 
(15, 'left-body-right', 'default'), 
(16, 'body-right', 'modern'), 
(16, 'left-body-right', 'default'), 
(17, 'body-right', 'modern'), 
(17, 'left-body-right', 'default'), 
(20, 'body-right', 'modern'), 
(20, 'left-body-right', 'default'), 
(22, 'body-right', 'modern'), 
(22, 'left-body-right', 'default'), 
(24, 'body-right', 'modern'), 
(24, 'left-body-right', 'default'), 
(26, 'body-right', 'modern'), 
(26, 'left-body-right', 'default'), 
(27, 'body-right', 'modern'), 
(27, 'left-body-right', 'default'), 
(28, 'body-right', 'modern'), 
(28, 'left-body-right', 'default'), 
(29, 'body-right', 'modern'), 
(29, 'left-body-right', 'default'), 
(30, 'body-right', 'modern'), 
(30, 'left-body-right', 'default'), 
(31, 'body-right', 'modern'), 
(31, 'left-body-right', 'default'), 
(32, 'body-right', 'modern'), 
(32, 'left-body-right', 'default'), 
(33, 'body-right', 'modern'), 
(33, 'left-body-right', 'default'), 
(34, 'body-right', 'modern'), 
(34, 'left-body-right', 'default'), 
(35, 'body-right', 'modern'), 
(35, 'left-body-right', 'default'), 
(36, 'body', 'modern'), 
(36, 'left-body', 'default'), 
(37, 'body', 'modern'), 
(37, 'left-body', 'default'), 
(38, 'body', 'modern'), 
(38, 'left-body', 'default'), 
(39, 'body', 'modern'), 
(39, 'left-body', 'default'), 
(40, 'body', 'modern'), 
(40, 'left-body', 'default'), 
(41, 'body', 'modern'), 
(41, 'left-body', 'default'), 
(42, 'body', 'modern'), 
(42, 'left-body', 'default'), 
(46, 'body-right', 'modern'), 
(46, 'left-body-right', 'default'), 
(48, 'body-right', 'modern'), 
(48, 'left-body-right', 'default'), 
(51, 'body-right', 'modern'), 
(51, 'left-body-right', 'default'), 
(54, 'body', 'modern'), 
(54, 'left-body-right', 'default'), 
(58, 'body-right', 'modern'), 
(58, 'left-body-right', 'default'), 
(60, 'body-right', 'modern'), 
(60, 'left-body-right', 'default'), 
(63, 'body-right', 'modern'), 
(63, 'left-body-right', 'default'), 
(65, 'body-right', 'modern'), 
(66, 'body-right', 'modern'), 
(67, 'body-right', 'modern');


-- ---------------------------------------


--
-- Table structure for table `nv_vi_modules`
--

DROP TABLE IF EXISTS `nv_vi_modules`;
CREATE TABLE `nv_vi_modules` (
  `title` varchar(55) NOT NULL,
  `module_file` varchar(55) NOT NULL DEFAULT '',
  `module_data` varchar(55) NOT NULL DEFAULT '',
  `custom_title` varchar(255) NOT NULL,
  `set_time` int(11) unsigned NOT NULL DEFAULT '0',
  `admin_file` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `theme` varchar(100) NOT NULL,
  `keywords` mediumtext NOT NULL,
  `groups_view` varchar(255) NOT NULL,
  `in_menu` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `weight` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `submenu` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `act` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `admins` varchar(255) NOT NULL,
  `rss` tinyint(4) NOT NULL DEFAULT '1',
  PRIMARY KEY (`title`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv_vi_modules`
--

INSERT INTO `nv_vi_modules` VALUES
('about', 'about', 'about', 'Giới thiệu', 1276333182, 1, '', '', '0', 1, 1, 1, 1, '', 0), 
('news', 'news', 'news', 'Tin Tức', 1270400000, 1, '', '', '0', 1, 2, 1, 1, '', 1), 
('download', 'download', 'download', 'Tải file', 1276597148, 1, '', '', '0', 1, 3, 1, 1, '', 1), 
('weblinks', 'weblinks', 'weblinks', 'Liên kết site', 1276834052, 1, '', '', '0', 1, 4, 1, 1, '', 1), 
('users', 'users', 'users', 'Thành viên', 1274080277, 1, '', '', '0', 1, 5, 1, 1, '', 0), 
('contact', 'contact', 'contact', 'Liên hệ', 1275351337, 1, '', '', '0', 1, 6, 1, 1, '', 0), 
('statistics', 'statistics', 'statistics', 'Thống kê', 1276520928, 0, '', 'truy cập, online, statistics', '0', 1, 7, 1, 1, '', 0), 
('voting', 'voting', 'voting', 'Thăm dò ý kiến', 1275315261, 1, '', '', '0', 0, 8, 1, 1, '', 1), 
('banners', 'banners', 'banners', 'Quảng cáo', 1270400000, 1, '', '', '0', 0, 9, 1, 1, '', 0), 
('search', 'search', 'search', 'Tìm kiếm', 1273474173, 0, '', '', '0', 0, 10, 1, 1, '', 0), 
('rss', 'rss', 'rss', 'Rss', 1279366705, 1, '', '', '0', 0, 11, 1, 1, '', 0);


-- ---------------------------------------


--
-- Table structure for table `nv_vi_news_1`
--

DROP TABLE IF EXISTS `nv_vi_news_1`;
CREATE TABLE `nv_vi_news_1` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) NOT NULL DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` mediumtext NOT NULL,
  `homeimgfile` varchar(255) NOT NULL DEFAULT '',
  `homeimgalt` varchar(255) NOT NULL DEFAULT '',
  `homeimgthumb` varchar(255) NOT NULL DEFAULT '',
  `imgposition` tinyint(1) NOT NULL DEFAULT '1',
  `bodytext` mediumtext NOT NULL,
  `copyright` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `ratingdetail` varchar(255) NOT NULL DEFAULT '',
  `allowed_send` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_print` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_save` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitslm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `keywords` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `listcatid` (`listcatid`)
) ENGINE=MyISAM  AUTO_INCREMENT=7  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv_vi_news_1`
--

INSERT INTO `nv_vi_news_1` VALUES
(1, '1,8,12', 0, 1, 'Quỳnh Nhi', 1, 1274989177, 1275318126, 1, 1274989140, 0, 2, 'Ra mắt công ty mã nguồn mở đầu tiên tại Việt Nam', 'Ra-mat-cong-ty-ma-nguon-mo-dau-tien-tai-Viet-Nam', 'Mã nguồn mở NukeViet vốn đã quá quen thuộc với cộng đồng CNTT Việt Nam trong mấy năm qua. Tuy chưa hoạt động chính thức, nhưng chỉ trong khoảng 5 năm gần đây, mã nguồn mở NukeViet đã được dùng phổ biến ở Việt Nam, áp dụng ở hầu hết các lĩnh vực, từ tin tức đến thương mại điện tử, từ các website cá nhân cho tới những hệ thống website doanh nghiệp.', '2010_05/nangly.jpg', 'Thành lập VINADES.,JSC', 'thumb/nangly.jpg|block/nangly.jpg', 1, '<p style=\"text-align: justify;\"> Để chuyên nghiệp hóa việc phát hành mã nguồn mở NukeViet, Ban quản trị NukeViet quyết định thành lập doanh nghiệp chuyên quản NukeViet mang tên Công ty cổ phần Phát triển nguồn mở Việt Nam (Viết tắt là VINADES.,JSC), chính thức ra mắt vào ngày 25-2-2010 (trụ sở tại 67B/35 Khương Hạ, Khương Đình, Thanh Xuân, Hà Nội) nhằm phát triển, phổ biến hệ thống NukeViet tại Việt Nam.<br  /> <br  /> Theo ông Nguyễn Anh Tú, Chủ tịch HĐQT VINADES, công ty sẽ phát triển bộ mã nguồn NukeViet nhất quán theo con đường mã nguồn mở đã chọn, chuyên nghiệp và quy mô hơn bao giờ hết. Đặc biệt là hoàn toàn miễn phí đúng tinh thần mã nguồn mở quốc tế.<br  /> <br  /> NukeViet là một hệ quản trị nội dung mã nguồn mở (Opensource Content Management System) thuần Việt từ nền tảng PHP-Nuke và cơ sở dữ liệu MySQL. Người sử dụng thường gọi NukeViet là portal vì nó có khả năng tích hợp nhiều ứng dụng trên nền web, cho phép người sử dụng có thể dễ dàng xuất bản và quản trị các nội dung của họ lên internet hoặc intranet.<br  /> <br  /> NukeViet cung cấp nhiều dịch vụ và ứng dụng nhờ khả năng tăng cường tính năng thêm các module, block... tạo sự dễ dàng cài đặt, quản lý, ngay cả với những người mới tiếp cận với website. Người dùng có thể tìm hiểu thêm thông tin và tải về sản phẩm tại địa chỉ http://nukeviet.vn</p><blockquote> <p style=\"text-align: justify;\"> <em>Thông tin ra mắt công ty VINADES có thể tìm thấy trên trang 7 báo Hà Nội Mới ra ngày 25/02/2010 (<a href=\"http://hanoimoi.com.vn/newsdetail/Cong_nghe/309750/ra-mat-cong-ty-ma-nguon-mo-dau-tien-tai-viet-nam.htm\" target=\"_blank\">xem chi tiết</a>), Bản tin tiếng Anh của đài tiếng nói Việt Nam ngày 26/02/2010 (<a href=\"http://english.vovnews.vn/Home/First-opensource-company-starts-operation/20102/112960.vov\" target=\"_blank\">xem chi tiết</a>); trang 7 báo An ninh Thủ Đô số 2858 ra vào thứ 2 ngày 01/03/2010 và các trang tin tức, báo điện tử khác.</em></p></blockquote>', 0, 1, 2, 1, '29|6', 1, 1, 1, 97, 0, 0, 'nguồn mở, quen thuộc, cộng đồng, việt nam, hoạt động, gần đây, phổ biến, áp dụng, hầu hết, hết các, lĩnh vực, tin tức, thương mại điện, điện tử, cá nhân, hệ thống'), 
(2, '1,8,12', 1, 1, 'laser', 2, 1274989787, 1275318114, 1, 1274989740, 0, 2, 'Công bố dự án NukeViet 3.0 sau 1 tháng ra mắt VINADES.,JSC', 'Cong-bo-du-an-NukeViet-3-0-sau-1-thang-ra-mat-VINADES-JSC', 'NukeViet 3.0 - Một nền tảng được xây dựng hoàn toàn mới với những công nghệ web tiên tiến nhất hiện nay hứa hẹn sẽ làm một cuộc cách mạng về mã nguồn mở ở Việt Nam. Món quà này là lời cảm ơn chân thành nhất mà VINADES.,JSC muốn gửi tới cộng đồng sau một tháng chính thức ra mắt.', '2010_05/nukeviet3.jpg', 'NukeViet 3.0', 'thumb/nukeviet3.jpg|block/nukeviet3.jpg', 1, '<p style=\"font-weight: bold;\"> <span style=\"font-size: 14pt;\">Câu chuyện của NukeViet và VINADES.,JSC</span></p><p style=\"font-weight: bold;\"> Từ một trăn trở</p><p style=\"text-align: justify;\"> Giữa năm 2009, trước yêu cầu cấp thiết phải đổi mới và làm một cuộc cách mạng cho mã nguồn mở NukeViet, một cuộc thảo luận sôi nổi đã diễn ra với tiêu đề &quot;Lối đi nào để chuyên nghiệp hóa mã nguồn mở NukeViet&quot;.</p><p> Kết quả của cuộc thảo luận này là 55 bài viết với hàng chục ý kiến đóng góp đã được đưa ra. Các giải pháp về tài chính, nhân lực, phương hướng hoạt động được đem ra thảo luận. rockbuilc, Nkd833 đề xuất phương án thành lập doanh nghiệp chuyên quản NukeViet như một giải pháp toàn diện để giải quyết vấn đề chuyên nghiệp hóa NukeViet. Các vấn đề được các thành viên tham gia thảo luận và mổ xẻ thẳng thắn, nhiều ý kiến phản biện trái chiều cũng được đưa ra trên tinh thần xây dựng. Sau 2 tháng thảo luận, Ban Quản Trị đã có dự định...</p><p> <span style=\"font-weight: bold;\">Gặp mặt</span></p><p> Tháng 11, Sau khi tham khảo các ý kiến của mọi người trên diễn đàn, Anh Tú đã trực tiếp về Việt Nam. Một cuộc offline được tổ chức chớp nhoáng với sự tham gia của các thành viên chủ chốt tại Hà Nội. Các cuộc tìm hiểu và tiếp xúc được triển khai gấp rút trong giai đoạn này.</p><p> <span style=\"font-weight: bold;\">Một mô hình - một lối đi</span></p><p style=\"text-align: justify;\"> Hướng đi chuyên nghiệp hóa việc phát triển NukeViet đã được anh Tú chọn lựa: &quot;Thành lập doanh nghiệp chuyên quản NukeViet&quot;. Doanh nghiệp chuyên quản NukeViet được thành lập từ chính nhu cầu của cộng đồng nhằm chuyên nghiệp hóa NukeViet, vì vậy mô hình công ty cổ phần được chọn lựa để đáp ứng yêu cầu đó. Chịu trách nhiệm triển khai, laser đã lên phương án đầu tư, mục tiêu, kế hoạch phát triển ngắn và dài hạn.</p><p> <br  /> <span style=\"font-weight: bold;\">Triển khai thực hiện</span></p><p style=\"text-align: justify;\"> Tháng 1 năm 2010, việc thành lập đã được xúc tiến. Ngày 25/02/2010, trên các bản tin tiếng Anh và tiếng Việt xuất hiện bản tin &quot;Ra mắt công ty mã nguồn mở đầu tiên tại Việt Nam&quot;. Đó là Công ty cổ phần Phát triển nguồn mở Việt Nam (VIET NAM OPEN SOURCE DEVELOPMENT JOINT STOCK COMPANY - VINADES.,JSC). Đây là một vài hình ảnh trong ngày khai trương:</p><div style=\"text-align: center;\"> <img alt=\"Anh Tú phát biểu khai trương VINADES.,JSC \" height=\"332\" src=\"http://nukeviet.vn/uploads/spaw2/images/anhtu-phatbieu.jpg\" style=\"border: 0px solid;\" width=\"500\" /></div><div style=\"text-align: center;\"> Anh Tú phát biểu khai trương VINADES.,JSC <p> <br  /> <img alt=\"\" border=\"0\" src=\"http://nukeviet.vn/uploads/spaw2/images/hung-phatbieu.jpg\" style=\"width: 500px;\" width=\"500\" /></p> <p> Nguyễn Hùng giới thiệu đôi nét về công ty, mục tiêu và phương hướng hoạt động.</p> <p> <br  /> <img alt=\"\" border=\"0\" height=\"332\" src=\"http://nukeviet.vn/uploads/spaw2/images/nangly.jpg\" style=\"width: 500px; height: 332px;\" width=\"500\" /></p> <p> Cùng nâng ly chúc mừng khai trương.</p></div><p style=\"font-weight: bold;\"> ... và lời cảm ơn gửi tới cộng đồng</p><p style=\"text-align: justify;\"> VINADES.,JSC từ khi được thai nghén tới lúc chập chững những bước đi ban đầu đều có sự động viên, ủng hộ và đóng góp lớn nhỏ của cộng đồng NukeViet - Một cộng đồng gắn liền với những ký ức, những kỷ niệm buồn vui và mang trong mỗi thành viên một đam mê, một hoài bão lớn lao. &quot;Lửa thử vàng, gian nan thử sức&quot;, mỗi khó khăn trả qua khiến cộng đồng NukeViet lớn dần lên, gắn kết với nhau bằng một sợi dây vô hình không thể chia cắt: đó là niềm đam mê với mã nguồn mở, với công nghệ web. VINADES.,JSC được tạo ra từ cộng đồng và sẽ cố gắng hết sức để hoạt động vì lợi ích của cộng đồng.</p><p>  </p><div style=\"text-align: center;\"> <img alt=\"\" border=\"0\" height=\"375\" src=\"http://nukeviet.vn/uploads/spaw2/images/anhvp2.jpg\" style=\"width: 500px; height: 375px;\" width=\"500\" /></div><p>  </p><p style=\"text-align: center;\"> Văn phòng làm việc của VINADES.,JSC ở Hà Nội.</p><div style=\"text-align: center;\"> <img alt=\"\" border=\"0\" height=\"375\" src=\"http://nukeviet.vn/uploads/spaw2/images/anhvp3.jpg\" style=\"width: 500px; height: 375px;\" width=\"500\" /></div><p>  </p><p style=\"text-align: center;\"> Một góc văn phòng nhìn từ trong ra ngoài.</p><p style=\"font-weight: bold;\"> NukeViet 3.0 - Cuộc cách mạng của NukeViet</p><p style=\"text-align: justify;\"> Sau nhiều tháng triển khai, NukeViet 3.0 đã được định hình và dự định công bố bản beta trong thời gian gần. NukeViet 3.0 là phiên bản mang tính cách mạng của hệ thống NukeViet vì 100% các dòng code của NukeViet 3.0 đã được viết mới hoàn toàn chứ không sử dụng nền tảng cũ. Việc này đã ngốn rất nhiều thời gian và công sức của đội ngũ lập trình. Đó cũng là lý do vì sao bản 2.0 không được cải tiến nhiều trong thời gian qua.</p><div style=\"text-align: justify;\"> NukeViet 3.0 được xây dựng với mong muốn có một nền tảng ổn định để sau đó có thể đầu tư lâu dài, xây dựng một thư viện ứng dụng phong phú. VINADES.,JSC sẽ song hành cùng cộng đồng NukeViet trong việc hỗ trợ và phát triển NukeViet thành một mã nguồn mở hoạt động ở quy mô chuyên nghiệp. Đây là bước đi đầu tiên trong trong tiến trình chuyên nghiệp hóa này. Các ứng dụng bổ sung sẽ được xây dựng bài bản, chất lượng. Cộng đồng NukeViet sẽ không chỉ là cộng đồng người sử dụng mà sẽ được đầu tư về đào tạo để trở thành một cộng đồng lập trình mạnh. Thông tin chi tiết về dự án phát triển NukeViet 3.0 được cập nhật tại đây: <a href=\"http://nukeviet.vn/phpbb/viewforum.php?f=99\" target=\"_blank\">http://nukeviet.vn/phpbb/viewforum.php?f=99</a></div>', 0, 1, 2, 1, '39|9', 1, 1, 1, 91, 0, 0, 'nền tảng, xây dựng, hoàn toàn, với những, công nghệ, tiên tiến, hiện nay, hứa hẹn, cách mạng, nguồn mở, việt nam, món quà, cảm ơn, chân thành, thành nhất, cộng đồng'), 
(6, '1,8,10', 0, 1, '', 0, 1274994722, 1275318001, 1, 1274994720, 0, 2, 'Thư mời hợp tác liên kết quảng cáo và cung cấp hosting thử nghiệm', 'Thu-moi-hop-tac', 'Hiện tại VINADES.,JSC đang tiến hành phát triển bộ mã nguồn NukeViet phiên bản 3.0 – một thế hệ CMS hoàn toàn mới với nhiều tính năng ưu việt, được đầu tư bài bản với kinh phí lớn. Với thiện chí hợp tác cùng phát triển VINADES.,JSC xin trân trọng gửi lời mời hợp tác đến Quý đối tác là các công ty cung cấp tên miền - hosting, các doanh nghiệp quan tâm và mong muốn hợp tác cùng VINADES để cùng thực hiện chung các hoạt động kinh doanh nhằm gia tăng giá trị, quảng bá thương hiệu chung cho cả hai bên.', '2010_05/hoptac.jpg', '', 'thumb/hoptac.jpg|block/hoptac.jpg', 1, '<div style=\"text-align: center;\"> <h2 style=\"color: rgb(255, 69, 0);\"> THƯ MỜI HỢP TÁC</h2> <h4> TRONG VIỆC LIÊN KẾT QUẢNG CÁO, CUNG CẤP HOSTING THỬ NGHIỆM PHÁT TRIỂN</h4> <h2> MÃ NGUỒN MỞ NUKEVIET</h2> </div> <p style=\"text-align: justify; line-height: 130%; font-weight: bold;\">  </p> <p style=\"text-align: justify; line-height: 130%; font-weight: bold;\"> Kính gửi: QUÍ KHÁCH VÀ ĐỐI TÁC</p> <p style=\"text-align: justify; line-height: 130%; font-style: italic; text-indent: 1cm;\"> Lời đầu tiên, Ban giám đốc công ty cổ phần Phát Triển Nguồn Mở Việt Nam (VINADES.,JSC) xin gửi đến Quý đối tác lời chào trân trọng, lời chúc may mắn và thành công. Tiếp đến chúng tôi xin được giới thiệu và ngỏ lời mời hợp tác kinh doanh.</p> <p style=\"text-align: justify; line-height: 130%; font-style: italic; text-indent: 1cm;\"> VINADES.,JSC ra đời nhằm chuyên nghiệp hóa việc phát hànhmã nguồn mở NukeViet. Đồng thời khai thác các dự án từ NukeViet tạo kinh phí phát triển bền vững cho mã nguồn này.</p> <p style=\"text-align: justify; line-height: 130%; font-style: italic; text-indent: 1cm;\"> NukeViet là hệ quản trị nội dung, là website đa năng đầu tiên của Việt Nam do cộng đồng người Việt phát triển. Có nhiều lợi thế như cộng đồng người sử dụng đông đảo nhất tại Việt Nam hiện nay, sản phẩm thuần Việt, dễ sử dụng, dễ phát triển.</p> <p style=\"text-align: justify; line-height: 130%; font-style: italic; text-indent: 1cm;\"> Hiện tại VINADES.,JSC đang tiến hành phát triển bộ mã nguồn NukeViet phiên bản 3.0 – một thế hệ CMS hoàn toàn mới với nhiều tính năng ưu việt, được đầu tư bài bản với kinh phí lớn.</p> <p style=\"text-align: justify; line-height: 130%; font-style: italic; text-indent: 1cm;\"> Với thiện chí hợp tác cùng phát triển VINADES.,JSC xin trân trọng gửi lời mời hợp tác đến Quý đối tác là các công ty cung cấp tên miền -hosting, các doanh nghiệp quan tâm và mong muốn hợp tác cùng VINADES để cùng thực hiện chung các hoạt động kinh doanh nhằm gia tăng giá trị, quảng bá thương hiệu chung cho cả hai bên.</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm; font-weight: bold;\"> Phương thức hợp tác nhưsau:</p> <p style=\"text-align: justify; line-height: 130%; font-weight: bold;\"> 1.Quảng cáo, trao đổi banner, liên kết website:</p> <p style=\"text-align: justify; line-height: 130%;\"> a. Mô tả hình thức:</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Quảng cáo trên website &amp; hệ thống kênh truyền thông của 2 bên.</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Quảng cáo trên các phiên bản phát hành của mã nguồn mở NukeViet.</p> <p style=\"text-align: justify; line-height: 130%;\"> b, Lợi ích:</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Quảng bá rộng rãi cho đối tượng của 2 bên.</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Giảm chi phí quảng bá cho 2 bên.</p> <p style=\"text-align: justify; line-height: 130%;\"> c, Trách nhiệm:</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Hai bên sẽ thỏa thuận và đưa quảng cáo của mình vào website của đối tác. Thỏa thuận vị trí, kích thước và trang đặt banner quảng cáo nhằm mang lại hiệu quả cao cho cả hai bên.</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Mở forum hỗ trợ người dùng hosting ngay tại diễn đàn NukeViet.VN để quý công ty dễ dàng hỗ trợ người sử dụng cũng như thực hiện các kế hoạch truyền thông của mình tới cộng đồng NukeViet.</p> <p style=\"text-align: justify; line-height: 130%; font-weight: bold;\"> 2.Hợp tác cung cấp hosting thử nghiệm NukeViet:</p> <p style=\"text-align: justify; line-height: 130%;\"> a. Mô tả hình thức:</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Hai bên ký hợp đồng nguyên tắc &amp; thỏa thuận hợp tác trong việc hợp tác phát triển mã nguồn mở NukeViet. Theo đó:</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> + Phía đối tác cung cấp mỗi loại 1 gói hosting đại lý cho VINADES.,JSC để chúng tôi test trong quá trình phát triển mã nguồn mở NukeViet, để đảm bảo NukeViet sẵn sàng tương thích với hosting của quý khách ngay khi ra mắt.</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> + VINADES.,JSC sẽ công báo thông tin chứng nhận host của phía đối tác là phù hợp, tương thích tốt nhất với NukeViet tới cộng đồng những người phát triển và sử dụng NukeViet.</p> <p style=\"text-align: justify; line-height: 130%;\"> b. Lợi ích:</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Mở rộng thị trường theo cả hướng đối tượng.</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Tiết kiệm chi phí –nâng cao hiệu quả kinh doanh.</p> <p style=\"text-align: justify; line-height: 130%;\"> c. Trách nhiệm:</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Bên đối tác cung cấp miễn phí host để VINADES.,JSC thực hiện việc test tương thích mã nguồn NukeViet trên các gói hosting của đối tác.</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - VINADES.,JSC công bố tới cộng đồng về kết quả chứng nhận chất lượng host của phía đối tác.</p> <p style=\"text-align: justify; line-height: 130%; font-weight: bold;\"> 3,Hợp tác nhân lực hỗ trợ người sử dụng:</p> <p style=\"text-align: justify; line-height: 130%;\"> a, Mô tả hình thức:</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Hai bên sẽ hỗ trợ lẫn nhau trong quá trình giải quyết các yêu cầu của khách hàng.</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> + Bên đối tác gửi các yêu cầu của khách hàng về mã nguồn NukeViet tới VINADES.,JSC</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> + VINADES gửi các yêu cầu của khách hàng có liên quan đến dịch vụ hosting tới phía đối tác.</p> <p style=\"text-align: justify; line-height: 130%;\"> b, Lợi ích:</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Giảm thiểu chi phí, nhân lực hỗ trợ khách hàng của cả 2 bên.</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Tăng hiệu quả hỗ trợ khách hàng.</p> <p style=\"text-align: justify; line-height: 130%;\"> c, Trách nhiệm:</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Khi nhận được yêu cầu hỗ trợ VINADES hoặc bên đối tác cần ưu tiên xử lý nhanh gọn nhằm nâng cao hiệuquả của sự hợp tác song phưong này.</p> <p style=\"text-align: justify; line-height: 130%; font-weight: bold;\"> 4. Các hình thức khác:</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> Ngoài các hình thức đã đề xuất ở trên, là đơn vị phát hành mã nguồn mở NukeViet chúng tôi có thể phát hành quảng cáo trên giao diện phần mềm, trên các bài viết giới thiệu xuất hiện ngay sau khi cài đặt phần mềm… chúng tôi tin tưởng rằng với lượng phát hành lên đến hàng chục ngàn lượt tải về cho mỗi phiên bản là một cơ hội quảng cáo rất hiệu quả đến cộng đồng Webmaster Việt Nam.</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> Với mong muốn tạo nên cộng đồng phát triển và sử dụng NukeViet rộng lớn đúng như mục tiêu đề ra,chúng tôi luôn linh động trong các hình thức hợp tác nhằm mang lại sự thuận tiện cho đối tác cũng như mục tiêu hợp tác đa phương. Chúng tôi sẽ tiếp nhận các hình thức hợp tác khác mà bên đối tác trình bày hợp lý và hiệu quả, mong nhận được thêm nhiều hình thức hợp tác khác từ đối tác. Phương châm của chúng tôi “Cùng hợp tác để phát triển”.</p> <p style=\"text-align: justify; line-height: 130%; font-style: italic; text-indent: 1cm;\"> Trân trọng cảm ơn, rất mong được hợp tác cùng quý vị.</p> <span style=\"font-weight: bold;\">Thông tin liên hệ:</span> <p style=\"text-align: justify;\"> CÔNGTY CỔ PHẦN PHÁT TRIỂN NGUỒN MỞ VIỆT NAM (VINADES.,JSC)</p> <p style=\"text-align: justify; text-indent: 1cm;\"> Trụ sở chính: 67B (ngõ 35) phố Khương Hạ, Khương Đình, ThanhXuân, Hà Nội.</p> <p style=\"text-align: justify; text-indent: 1cm;\"> Điện thoại: (84-4) 85 872007</p> <p style=\"text-align: justify; text-indent: 1cm;\"> Fax: (84-4) 35 500 914</p> <p style=\"text-align: justify; text-indent: 1cm;\"> Website: <a href=\"http://www.vinades.vn/\">www.vinades.vn</a> – <a href=\"http://www.nukeviet.vn/\">www.nukeviet.vn</a></p> <p style=\"text-align: justify; text-indent: 1cm;\"> Email: <a href=\"mailto:contact@vinades.vn\">contact@vinades.vn</a></p>', 0, 1, 2, 1, '29|8', 1, 1, 1, 73, 0, 0, 'hiện tại, tiến hành, phát triển, phiên bản, thế hệ, hoàn toàn, tính năng, ưu việt, kinh phí, thiện chí, hợp tác, trân trọng, mời hợp tác, đối tác, các công ty, công ty, cung cấp, tên miền, các doanh, doanh nghiệp, quan tâm');


-- ---------------------------------------


--
-- Table structure for table `nv_vi_news_10`
--

DROP TABLE IF EXISTS `nv_vi_news_10`;
CREATE TABLE `nv_vi_news_10` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) NOT NULL DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` mediumtext NOT NULL,
  `homeimgfile` varchar(255) NOT NULL DEFAULT '',
  `homeimgalt` varchar(255) NOT NULL DEFAULT '',
  `homeimgthumb` varchar(255) NOT NULL DEFAULT '',
  `imgposition` tinyint(1) NOT NULL DEFAULT '1',
  `bodytext` mediumtext NOT NULL,
  `copyright` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `ratingdetail` varchar(255) NOT NULL DEFAULT '',
  `allowed_send` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_print` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_save` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitslm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `keywords` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `listcatid` (`listcatid`)
) ENGINE=MyISAM  AUTO_INCREMENT=7  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv_vi_news_10`
--

INSERT INTO `nv_vi_news_10` VALUES
(6, '1,8,10', 0, 1, '', 0, 1274994722, 1275318001, 1, 1274994720, 0, 2, 'Thư mời hợp tác liên kết quảng cáo và cung cấp hosting thử nghiệm', 'Thu-moi-hop-tac', 'Hiện tại VINADES.,JSC đang tiến hành phát triển bộ mã nguồn NukeViet phiên bản 3.0 – một thế hệ CMS hoàn toàn mới với nhiều tính năng ưu việt, được đầu tư bài bản với kinh phí lớn. Với thiện chí hợp tác cùng phát triển VINADES.,JSC xin trân trọng gửi lời mời hợp tác đến Quý đối tác là các công ty cung cấp tên miền - hosting, các doanh nghiệp quan tâm và mong muốn hợp tác cùng VINADES để cùng thực hiện chung các hoạt động kinh doanh nhằm gia tăng giá trị, quảng bá thương hiệu chung cho cả hai bên.', '2010_05/hoptac.jpg', '', 'thumb/hoptac.jpg|block/hoptac.jpg', 1, '<div style=\"text-align: center;\"> <h2 style=\"color: rgb(255, 69, 0);\"> THƯ MỜI HỢP TÁC</h2> <h4> TRONG VIỆC LIÊN KẾT QUẢNG CÁO, CUNG CẤP HOSTING THỬ NGHIỆM PHÁT TRIỂN</h4> <h2> MÃ NGUỒN MỞ NUKEVIET</h2> </div> <p style=\"text-align: justify; line-height: 130%; font-weight: bold;\">  </p> <p style=\"text-align: justify; line-height: 130%; font-weight: bold;\"> Kính gửi: QUÍ KHÁCH VÀ ĐỐI TÁC</p> <p style=\"text-align: justify; line-height: 130%; font-style: italic; text-indent: 1cm;\"> Lời đầu tiên, Ban giám đốc công ty cổ phần Phát Triển Nguồn Mở Việt Nam (VINADES.,JSC) xin gửi đến Quý đối tác lời chào trân trọng, lời chúc may mắn và thành công. Tiếp đến chúng tôi xin được giới thiệu và ngỏ lời mời hợp tác kinh doanh.</p> <p style=\"text-align: justify; line-height: 130%; font-style: italic; text-indent: 1cm;\"> VINADES.,JSC ra đời nhằm chuyên nghiệp hóa việc phát hànhmã nguồn mở NukeViet. Đồng thời khai thác các dự án từ NukeViet tạo kinh phí phát triển bền vững cho mã nguồn này.</p> <p style=\"text-align: justify; line-height: 130%; font-style: italic; text-indent: 1cm;\"> NukeViet là hệ quản trị nội dung, là website đa năng đầu tiên của Việt Nam do cộng đồng người Việt phát triển. Có nhiều lợi thế như cộng đồng người sử dụng đông đảo nhất tại Việt Nam hiện nay, sản phẩm thuần Việt, dễ sử dụng, dễ phát triển.</p> <p style=\"text-align: justify; line-height: 130%; font-style: italic; text-indent: 1cm;\"> Hiện tại VINADES.,JSC đang tiến hành phát triển bộ mã nguồn NukeViet phiên bản 3.0 – một thế hệ CMS hoàn toàn mới với nhiều tính năng ưu việt, được đầu tư bài bản với kinh phí lớn.</p> <p style=\"text-align: justify; line-height: 130%; font-style: italic; text-indent: 1cm;\"> Với thiện chí hợp tác cùng phát triển VINADES.,JSC xin trân trọng gửi lời mời hợp tác đến Quý đối tác là các công ty cung cấp tên miền -hosting, các doanh nghiệp quan tâm và mong muốn hợp tác cùng VINADES để cùng thực hiện chung các hoạt động kinh doanh nhằm gia tăng giá trị, quảng bá thương hiệu chung cho cả hai bên.</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm; font-weight: bold;\"> Phương thức hợp tác nhưsau:</p> <p style=\"text-align: justify; line-height: 130%; font-weight: bold;\"> 1.Quảng cáo, trao đổi banner, liên kết website:</p> <p style=\"text-align: justify; line-height: 130%;\"> a. Mô tả hình thức:</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Quảng cáo trên website &amp; hệ thống kênh truyền thông của 2 bên.</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Quảng cáo trên các phiên bản phát hành của mã nguồn mở NukeViet.</p> <p style=\"text-align: justify; line-height: 130%;\"> b, Lợi ích:</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Quảng bá rộng rãi cho đối tượng của 2 bên.</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Giảm chi phí quảng bá cho 2 bên.</p> <p style=\"text-align: justify; line-height: 130%;\"> c, Trách nhiệm:</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Hai bên sẽ thỏa thuận và đưa quảng cáo của mình vào website của đối tác. Thỏa thuận vị trí, kích thước và trang đặt banner quảng cáo nhằm mang lại hiệu quả cao cho cả hai bên.</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Mở forum hỗ trợ người dùng hosting ngay tại diễn đàn NukeViet.VN để quý công ty dễ dàng hỗ trợ người sử dụng cũng như thực hiện các kế hoạch truyền thông của mình tới cộng đồng NukeViet.</p> <p style=\"text-align: justify; line-height: 130%; font-weight: bold;\"> 2.Hợp tác cung cấp hosting thử nghiệm NukeViet:</p> <p style=\"text-align: justify; line-height: 130%;\"> a. Mô tả hình thức:</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Hai bên ký hợp đồng nguyên tắc &amp; thỏa thuận hợp tác trong việc hợp tác phát triển mã nguồn mở NukeViet. Theo đó:</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> + Phía đối tác cung cấp mỗi loại 1 gói hosting đại lý cho VINADES.,JSC để chúng tôi test trong quá trình phát triển mã nguồn mở NukeViet, để đảm bảo NukeViet sẵn sàng tương thích với hosting của quý khách ngay khi ra mắt.</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> + VINADES.,JSC sẽ công báo thông tin chứng nhận host của phía đối tác là phù hợp, tương thích tốt nhất với NukeViet tới cộng đồng những người phát triển và sử dụng NukeViet.</p> <p style=\"text-align: justify; line-height: 130%;\"> b. Lợi ích:</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Mở rộng thị trường theo cả hướng đối tượng.</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Tiết kiệm chi phí –nâng cao hiệu quả kinh doanh.</p> <p style=\"text-align: justify; line-height: 130%;\"> c. Trách nhiệm:</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Bên đối tác cung cấp miễn phí host để VINADES.,JSC thực hiện việc test tương thích mã nguồn NukeViet trên các gói hosting của đối tác.</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - VINADES.,JSC công bố tới cộng đồng về kết quả chứng nhận chất lượng host của phía đối tác.</p> <p style=\"text-align: justify; line-height: 130%; font-weight: bold;\"> 3,Hợp tác nhân lực hỗ trợ người sử dụng:</p> <p style=\"text-align: justify; line-height: 130%;\"> a, Mô tả hình thức:</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Hai bên sẽ hỗ trợ lẫn nhau trong quá trình giải quyết các yêu cầu của khách hàng.</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> + Bên đối tác gửi các yêu cầu của khách hàng về mã nguồn NukeViet tới VINADES.,JSC</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> + VINADES gửi các yêu cầu của khách hàng có liên quan đến dịch vụ hosting tới phía đối tác.</p> <p style=\"text-align: justify; line-height: 130%;\"> b, Lợi ích:</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Giảm thiểu chi phí, nhân lực hỗ trợ khách hàng của cả 2 bên.</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Tăng hiệu quả hỗ trợ khách hàng.</p> <p style=\"text-align: justify; line-height: 130%;\"> c, Trách nhiệm:</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Khi nhận được yêu cầu hỗ trợ VINADES hoặc bên đối tác cần ưu tiên xử lý nhanh gọn nhằm nâng cao hiệuquả của sự hợp tác song phưong này.</p> <p style=\"text-align: justify; line-height: 130%; font-weight: bold;\"> 4. Các hình thức khác:</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> Ngoài các hình thức đã đề xuất ở trên, là đơn vị phát hành mã nguồn mở NukeViet chúng tôi có thể phát hành quảng cáo trên giao diện phần mềm, trên các bài viết giới thiệu xuất hiện ngay sau khi cài đặt phần mềm… chúng tôi tin tưởng rằng với lượng phát hành lên đến hàng chục ngàn lượt tải về cho mỗi phiên bản là một cơ hội quảng cáo rất hiệu quả đến cộng đồng Webmaster Việt Nam.</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> Với mong muốn tạo nên cộng đồng phát triển và sử dụng NukeViet rộng lớn đúng như mục tiêu đề ra,chúng tôi luôn linh động trong các hình thức hợp tác nhằm mang lại sự thuận tiện cho đối tác cũng như mục tiêu hợp tác đa phương. Chúng tôi sẽ tiếp nhận các hình thức hợp tác khác mà bên đối tác trình bày hợp lý và hiệu quả, mong nhận được thêm nhiều hình thức hợp tác khác từ đối tác. Phương châm của chúng tôi “Cùng hợp tác để phát triển”.</p> <p style=\"text-align: justify; line-height: 130%; font-style: italic; text-indent: 1cm;\"> Trân trọng cảm ơn, rất mong được hợp tác cùng quý vị.</p> <span style=\"font-weight: bold;\">Thông tin liên hệ:</span> <p style=\"text-align: justify;\"> CÔNGTY CỔ PHẦN PHÁT TRIỂN NGUỒN MỞ VIỆT NAM (VINADES.,JSC)</p> <p style=\"text-align: justify; text-indent: 1cm;\"> Trụ sở chính: 67B (ngõ 35) phố Khương Hạ, Khương Đình, ThanhXuân, Hà Nội.</p> <p style=\"text-align: justify; text-indent: 1cm;\"> Điện thoại: (84-4) 85 872007</p> <p style=\"text-align: justify; text-indent: 1cm;\"> Fax: (84-4) 35 500 914</p> <p style=\"text-align: justify; text-indent: 1cm;\"> Website: <a href=\"http://www.vinades.vn/\">www.vinades.vn</a> – <a href=\"http://www.nukeviet.vn/\">www.nukeviet.vn</a></p> <p style=\"text-align: justify; text-indent: 1cm;\"> Email: <a href=\"mailto:contact@vinades.vn\">contact@vinades.vn</a></p>', 0, 1, 2, 1, '29|8', 1, 1, 1, 73, 0, 0, 'hiện tại, tiến hành, phát triển, phiên bản, thế hệ, hoàn toàn, tính năng, ưu việt, kinh phí, thiện chí, hợp tác, trân trọng, mời hợp tác, đối tác, các công ty, công ty, cung cấp, tên miền, các doanh, doanh nghiệp, quan tâm');


-- ---------------------------------------


--
-- Table structure for table `nv_vi_news_11`
--

DROP TABLE IF EXISTS `nv_vi_news_11`;
CREATE TABLE `nv_vi_news_11` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) NOT NULL DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` mediumtext NOT NULL,
  `homeimgfile` varchar(255) NOT NULL DEFAULT '',
  `homeimgalt` varchar(255) NOT NULL DEFAULT '',
  `homeimgthumb` varchar(255) NOT NULL DEFAULT '',
  `imgposition` tinyint(1) NOT NULL DEFAULT '1',
  `bodytext` mediumtext NOT NULL,
  `copyright` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `ratingdetail` varchar(255) NOT NULL DEFAULT '',
  `allowed_send` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_print` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_save` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitslm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `keywords` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `listcatid` (`listcatid`)
) ENGINE=MyISAM  AUTO_INCREMENT=7  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv_vi_news_12`
--

DROP TABLE IF EXISTS `nv_vi_news_12`;
CREATE TABLE `nv_vi_news_12` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) NOT NULL DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` mediumtext NOT NULL,
  `homeimgfile` varchar(255) NOT NULL DEFAULT '',
  `homeimgalt` varchar(255) NOT NULL DEFAULT '',
  `homeimgthumb` varchar(255) NOT NULL DEFAULT '',
  `imgposition` tinyint(1) NOT NULL DEFAULT '1',
  `bodytext` mediumtext NOT NULL,
  `copyright` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `ratingdetail` varchar(255) NOT NULL DEFAULT '',
  `allowed_send` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_print` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_save` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitslm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `keywords` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `listcatid` (`listcatid`)
) ENGINE=MyISAM  AUTO_INCREMENT=7  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv_vi_news_12`
--

INSERT INTO `nv_vi_news_12` VALUES
(1, '1,8,12', 0, 1, 'Quỳnh Nhi', 1, 1274989177, 1275318126, 1, 1274989140, 0, 2, 'Ra mắt công ty mã nguồn mở đầu tiên tại Việt Nam', 'Ra-mat-cong-ty-ma-nguon-mo-dau-tien-tai-Viet-Nam', 'Mã nguồn mở NukeViet vốn đã quá quen thuộc với cộng đồng CNTT Việt Nam trong mấy năm qua. Tuy chưa hoạt động chính thức, nhưng chỉ trong khoảng 5 năm gần đây, mã nguồn mở NukeViet đã được dùng phổ biến ở Việt Nam, áp dụng ở hầu hết các lĩnh vực, từ tin tức đến thương mại điện tử, từ các website cá nhân cho tới những hệ thống website doanh nghiệp.', '2010_05/nangly.jpg', 'Thành lập VINADES.,JSC', 'thumb/nangly.jpg|block/nangly.jpg', 1, '<p style=\"text-align: justify;\"> Để chuyên nghiệp hóa việc phát hành mã nguồn mở NukeViet, Ban quản trị NukeViet quyết định thành lập doanh nghiệp chuyên quản NukeViet mang tên Công ty cổ phần Phát triển nguồn mở Việt Nam (Viết tắt là VINADES.,JSC), chính thức ra mắt vào ngày 25-2-2010 (trụ sở tại 67B/35 Khương Hạ, Khương Đình, Thanh Xuân, Hà Nội) nhằm phát triển, phổ biến hệ thống NukeViet tại Việt Nam.<br  /> <br  /> Theo ông Nguyễn Anh Tú, Chủ tịch HĐQT VINADES, công ty sẽ phát triển bộ mã nguồn NukeViet nhất quán theo con đường mã nguồn mở đã chọn, chuyên nghiệp và quy mô hơn bao giờ hết. Đặc biệt là hoàn toàn miễn phí đúng tinh thần mã nguồn mở quốc tế.<br  /> <br  /> NukeViet là một hệ quản trị nội dung mã nguồn mở (Opensource Content Management System) thuần Việt từ nền tảng PHP-Nuke và cơ sở dữ liệu MySQL. Người sử dụng thường gọi NukeViet là portal vì nó có khả năng tích hợp nhiều ứng dụng trên nền web, cho phép người sử dụng có thể dễ dàng xuất bản và quản trị các nội dung của họ lên internet hoặc intranet.<br  /> <br  /> NukeViet cung cấp nhiều dịch vụ và ứng dụng nhờ khả năng tăng cường tính năng thêm các module, block... tạo sự dễ dàng cài đặt, quản lý, ngay cả với những người mới tiếp cận với website. Người dùng có thể tìm hiểu thêm thông tin và tải về sản phẩm tại địa chỉ http://nukeviet.vn</p><blockquote> <p style=\"text-align: justify;\"> <em>Thông tin ra mắt công ty VINADES có thể tìm thấy trên trang 7 báo Hà Nội Mới ra ngày 25/02/2010 (<a href=\"http://hanoimoi.com.vn/newsdetail/Cong_nghe/309750/ra-mat-cong-ty-ma-nguon-mo-dau-tien-tai-viet-nam.htm\" target=\"_blank\">xem chi tiết</a>), Bản tin tiếng Anh của đài tiếng nói Việt Nam ngày 26/02/2010 (<a href=\"http://english.vovnews.vn/Home/First-opensource-company-starts-operation/20102/112960.vov\" target=\"_blank\">xem chi tiết</a>); trang 7 báo An ninh Thủ Đô số 2858 ra vào thứ 2 ngày 01/03/2010 và các trang tin tức, báo điện tử khác.</em></p></blockquote>', 0, 1, 2, 1, '29|6', 1, 1, 1, 97, 0, 0, 'nguồn mở, quen thuộc, cộng đồng, việt nam, hoạt động, gần đây, phổ biến, áp dụng, hầu hết, hết các, lĩnh vực, tin tức, thương mại điện, điện tử, cá nhân, hệ thống'), 
(2, '1,8,12', 1, 1, 'laser', 2, 1274989787, 1275318114, 1, 1274989740, 0, 2, 'Công bố dự án NukeViet 3.0 sau 1 tháng ra mắt VINADES.,JSC', 'Cong-bo-du-an-NukeViet-3-0-sau-1-thang-ra-mat-VINADES-JSC', 'NukeViet 3.0 - Một nền tảng được xây dựng hoàn toàn mới với những công nghệ web tiên tiến nhất hiện nay hứa hẹn sẽ làm một cuộc cách mạng về mã nguồn mở ở Việt Nam. Món quà này là lời cảm ơn chân thành nhất mà VINADES.,JSC muốn gửi tới cộng đồng sau một tháng chính thức ra mắt.', '2010_05/nukeviet3.jpg', 'NukeViet 3.0', 'thumb/nukeviet3.jpg|block/nukeviet3.jpg', 1, '<p style=\"font-weight: bold;\"> <span style=\"font-size: 14pt;\">Câu chuyện của NukeViet và VINADES.,JSC</span></p><p style=\"font-weight: bold;\"> Từ một trăn trở</p><p style=\"text-align: justify;\"> Giữa năm 2009, trước yêu cầu cấp thiết phải đổi mới và làm một cuộc cách mạng cho mã nguồn mở NukeViet, một cuộc thảo luận sôi nổi đã diễn ra với tiêu đề &quot;Lối đi nào để chuyên nghiệp hóa mã nguồn mở NukeViet&quot;.</p><p> Kết quả của cuộc thảo luận này là 55 bài viết với hàng chục ý kiến đóng góp đã được đưa ra. Các giải pháp về tài chính, nhân lực, phương hướng hoạt động được đem ra thảo luận. rockbuilc, Nkd833 đề xuất phương án thành lập doanh nghiệp chuyên quản NukeViet như một giải pháp toàn diện để giải quyết vấn đề chuyên nghiệp hóa NukeViet. Các vấn đề được các thành viên tham gia thảo luận và mổ xẻ thẳng thắn, nhiều ý kiến phản biện trái chiều cũng được đưa ra trên tinh thần xây dựng. Sau 2 tháng thảo luận, Ban Quản Trị đã có dự định...</p><p> <span style=\"font-weight: bold;\">Gặp mặt</span></p><p> Tháng 11, Sau khi tham khảo các ý kiến của mọi người trên diễn đàn, Anh Tú đã trực tiếp về Việt Nam. Một cuộc offline được tổ chức chớp nhoáng với sự tham gia của các thành viên chủ chốt tại Hà Nội. Các cuộc tìm hiểu và tiếp xúc được triển khai gấp rút trong giai đoạn này.</p><p> <span style=\"font-weight: bold;\">Một mô hình - một lối đi</span></p><p style=\"text-align: justify;\"> Hướng đi chuyên nghiệp hóa việc phát triển NukeViet đã được anh Tú chọn lựa: &quot;Thành lập doanh nghiệp chuyên quản NukeViet&quot;. Doanh nghiệp chuyên quản NukeViet được thành lập từ chính nhu cầu của cộng đồng nhằm chuyên nghiệp hóa NukeViet, vì vậy mô hình công ty cổ phần được chọn lựa để đáp ứng yêu cầu đó. Chịu trách nhiệm triển khai, laser đã lên phương án đầu tư, mục tiêu, kế hoạch phát triển ngắn và dài hạn.</p><p> <br  /> <span style=\"font-weight: bold;\">Triển khai thực hiện</span></p><p style=\"text-align: justify;\"> Tháng 1 năm 2010, việc thành lập đã được xúc tiến. Ngày 25/02/2010, trên các bản tin tiếng Anh và tiếng Việt xuất hiện bản tin &quot;Ra mắt công ty mã nguồn mở đầu tiên tại Việt Nam&quot;. Đó là Công ty cổ phần Phát triển nguồn mở Việt Nam (VIET NAM OPEN SOURCE DEVELOPMENT JOINT STOCK COMPANY - VINADES.,JSC). Đây là một vài hình ảnh trong ngày khai trương:</p><div style=\"text-align: center;\"> <img alt=\"Anh Tú phát biểu khai trương VINADES.,JSC \" height=\"332\" src=\"http://nukeviet.vn/uploads/spaw2/images/anhtu-phatbieu.jpg\" style=\"border: 0px solid;\" width=\"500\" /></div><div style=\"text-align: center;\"> Anh Tú phát biểu khai trương VINADES.,JSC <p> <br  /> <img alt=\"\" border=\"0\" src=\"http://nukeviet.vn/uploads/spaw2/images/hung-phatbieu.jpg\" style=\"width: 500px;\" width=\"500\" /></p> <p> Nguyễn Hùng giới thiệu đôi nét về công ty, mục tiêu và phương hướng hoạt động.</p> <p> <br  /> <img alt=\"\" border=\"0\" height=\"332\" src=\"http://nukeviet.vn/uploads/spaw2/images/nangly.jpg\" style=\"width: 500px; height: 332px;\" width=\"500\" /></p> <p> Cùng nâng ly chúc mừng khai trương.</p></div><p style=\"font-weight: bold;\"> ... và lời cảm ơn gửi tới cộng đồng</p><p style=\"text-align: justify;\"> VINADES.,JSC từ khi được thai nghén tới lúc chập chững những bước đi ban đầu đều có sự động viên, ủng hộ và đóng góp lớn nhỏ của cộng đồng NukeViet - Một cộng đồng gắn liền với những ký ức, những kỷ niệm buồn vui và mang trong mỗi thành viên một đam mê, một hoài bão lớn lao. &quot;Lửa thử vàng, gian nan thử sức&quot;, mỗi khó khăn trả qua khiến cộng đồng NukeViet lớn dần lên, gắn kết với nhau bằng một sợi dây vô hình không thể chia cắt: đó là niềm đam mê với mã nguồn mở, với công nghệ web. VINADES.,JSC được tạo ra từ cộng đồng và sẽ cố gắng hết sức để hoạt động vì lợi ích của cộng đồng.</p><p>  </p><div style=\"text-align: center;\"> <img alt=\"\" border=\"0\" height=\"375\" src=\"http://nukeviet.vn/uploads/spaw2/images/anhvp2.jpg\" style=\"width: 500px; height: 375px;\" width=\"500\" /></div><p>  </p><p style=\"text-align: center;\"> Văn phòng làm việc của VINADES.,JSC ở Hà Nội.</p><div style=\"text-align: center;\"> <img alt=\"\" border=\"0\" height=\"375\" src=\"http://nukeviet.vn/uploads/spaw2/images/anhvp3.jpg\" style=\"width: 500px; height: 375px;\" width=\"500\" /></div><p>  </p><p style=\"text-align: center;\"> Một góc văn phòng nhìn từ trong ra ngoài.</p><p style=\"font-weight: bold;\"> NukeViet 3.0 - Cuộc cách mạng của NukeViet</p><p style=\"text-align: justify;\"> Sau nhiều tháng triển khai, NukeViet 3.0 đã được định hình và dự định công bố bản beta trong thời gian gần. NukeViet 3.0 là phiên bản mang tính cách mạng của hệ thống NukeViet vì 100% các dòng code của NukeViet 3.0 đã được viết mới hoàn toàn chứ không sử dụng nền tảng cũ. Việc này đã ngốn rất nhiều thời gian và công sức của đội ngũ lập trình. Đó cũng là lý do vì sao bản 2.0 không được cải tiến nhiều trong thời gian qua.</p><div style=\"text-align: justify;\"> NukeViet 3.0 được xây dựng với mong muốn có một nền tảng ổn định để sau đó có thể đầu tư lâu dài, xây dựng một thư viện ứng dụng phong phú. VINADES.,JSC sẽ song hành cùng cộng đồng NukeViet trong việc hỗ trợ và phát triển NukeViet thành một mã nguồn mở hoạt động ở quy mô chuyên nghiệp. Đây là bước đi đầu tiên trong trong tiến trình chuyên nghiệp hóa này. Các ứng dụng bổ sung sẽ được xây dựng bài bản, chất lượng. Cộng đồng NukeViet sẽ không chỉ là cộng đồng người sử dụng mà sẽ được đầu tư về đào tạo để trở thành một cộng đồng lập trình mạnh. Thông tin chi tiết về dự án phát triển NukeViet 3.0 được cập nhật tại đây: <a href=\"http://nukeviet.vn/phpbb/viewforum.php?f=99\" target=\"_blank\">http://nukeviet.vn/phpbb/viewforum.php?f=99</a></div>', 0, 1, 2, 1, '39|9', 1, 1, 1, 91, 0, 0, 'nền tảng, xây dựng, hoàn toàn, với những, công nghệ, tiên tiến, hiện nay, hứa hẹn, cách mạng, nguồn mở, việt nam, món quà, cảm ơn, chân thành, thành nhất, cộng đồng');


-- ---------------------------------------


--
-- Table structure for table `nv_vi_news_2`
--

DROP TABLE IF EXISTS `nv_vi_news_2`;
CREATE TABLE `nv_vi_news_2` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) NOT NULL DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` mediumtext NOT NULL,
  `homeimgfile` varchar(255) NOT NULL DEFAULT '',
  `homeimgalt` varchar(255) NOT NULL DEFAULT '',
  `homeimgthumb` varchar(255) NOT NULL DEFAULT '',
  `imgposition` tinyint(1) NOT NULL DEFAULT '1',
  `bodytext` mediumtext NOT NULL,
  `copyright` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `ratingdetail` varchar(255) NOT NULL DEFAULT '',
  `allowed_send` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_print` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_save` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitslm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `keywords` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `listcatid` (`listcatid`)
) ENGINE=MyISAM  AUTO_INCREMENT=7  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv_vi_news_2`
--

INSERT INTO `nv_vi_news_2` VALUES
(5, '2', 1, 1, '', 0, 1274993307, 1275318039, 1, 1274993280, 0, 2, 'Giới thiệu về mã nguồn mở NukeViet', 'Gioi-thieu-ve-ma-nguon-mo-NukeViet', 'Chắc hẳn đây không phải lần đầu tiên bạn nghe nói đến mã nguồn mở. Và nếu bạn là người mê lướt web thì hẳn bạn từng nhìn thấy đâu đó cái tên NukeViet. NukeViet, phát âm là Nu-Ke-Việt, chính là phần mềm dùng để xây dựng các Website mà bạn ngày ngày online để truy cập đấy.', '2010_05/1243187502.jpg', '', 'thumb/1243187502.jpg|block/1243187502.jpg', 1, '<p> <strong><span style=\"font-size: 14px;\">THÔNGTIN VỀ MÃ NGUỒN MỞ NUKEVIET</span></strong></p><p style=\"font-weight: bold;\"> I. Giới thiệu chung:</p><p> NukeViet là một hệ quản trị nội dung mã nguồn mở (Opensource Content Management System), người sử dụng thường gọi NukeViet là portal vì nó có khả năng tích hợp nhiều ứng dụng trên nền Web.</p><p> NukeViet có 2 dòng phiên bản chính:</p><p> Dòng phiên bản trước năm 2009 (NukeViet 2.0 trở về trước) được Nguyễn Anh Tú- một lưu học sinh người Việt tại Nga - cùng cộng đồng phát triển thành một ứng dụng thuần Việt từ nền tảng PHP-Nuke.</p><p> Dòng phiên bản NukeViet 3.0 trở về sau (kể từ năm 2010 trở đi) là dòng phiên bản hoàn toàn mới, được xây dựng từ đầu với nhiều tính năng ưu việt.</p><p> NukeViet được viết bằng ngôn ngữ PHP và chủ yếu sử dụng cơ sở dữ liệu MySQL, cho phép người sử dụng có thể dễ dàng xuất bản &amp;quản trị các nội dung của họ lên Internet hoặc Intranet.</p><p> NukeViet được sử dụng ở nhiều website, từ những website cá nhân cho tới những hệ thống website doanh nghiệp, nó cung cấp nhiều dịch vụ và ứng dụng nhờ khả năng tăng cường tính năng bằng cách cài thêm các module, block... NukeViet có thể dễ dàng cài đặt, dễ dàng quản lý kể cả với những người mới sử dụng.</p><p style=\"text-align: justify;\"> NukeViet là giải pháp hoàn hảo cho các Website từ cá nhân cho tới các doanh nghiệp. NukeViet là bộ mã nguồn chất lượng cao, được phát hành theo giấy phép mã nguồn mở nên việc sử dụng NukeViet hoàn toàn miễn phí. Với người sử dụng cá nhân, tất cả đều có thể tự tạo cho mình một website chuyên nghiệp mà không mất bất cứ chi phí nào. Với những nhà phát triển Web, sử dụng NukeViet có thể nhanh chóng xây dựng các hệ thống lớn mà việc lập trình không đòi hỏi quá nhiều thời gian vì NukeViet đã xây dựng sẵn hệ thống quản lý ưu việt.</p><p>  </p><p> Thông tin chi tiết về NukeViet có thểtìm thấy ở bách khoa toàn thư mở Wikipedia: <a href=\"http://vi.wikipedia.org/wiki/NukeViet\">http://vi.wikipedia.org/wiki/NukeViet</a></p><p style=\"font-weight: bold;\"> II. Thông tin về diễn đàn NukeViet:</p><p> Diễn đàn NukeViet hoạt động trên website: <a href=\"http://nukeviet.vn/\"><span style=\"font-weight: bold;\">http://nukeviet.vn</span></a> hiện có trên 13.000 thành viên thực gồm học sinh, sinh viên &amp; nhiều thànhphần khác thuộc giới trí thức ở trong và ngoài nước.</p><p> Là một diễn đàn của các nhà quản lý website, rất nhiều thành viên trong diễn đàn NukeViet là cán bộ, lãnh đạo từ đủ mọi lĩnh vực: công nghệ thông tin, xây dựng,văn hóa - xã hội, thể thao, dịch vụ - du lịch... từ cử nhân, bác sĩ, kỹ sư cho đến bộ đội, công an...</p><p> Nhiều học sinh, sinh viên tham gia diễn đàn NukeViet, đam mê mã nguồn mở và đã thành công với chính công việc mà họ yêu thích.</p>', 0, 1, 2, 1, '40|8', 1, 1, 1, 90, 0, 0, 'quản trị, nội dung, sử dụng, khả năng, tích hợp, ứng dụng');


-- ---------------------------------------


--
-- Table structure for table `nv_vi_news_8`
--

DROP TABLE IF EXISTS `nv_vi_news_8`;
CREATE TABLE `nv_vi_news_8` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) NOT NULL DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` mediumtext NOT NULL,
  `homeimgfile` varchar(255) NOT NULL DEFAULT '',
  `homeimgalt` varchar(255) NOT NULL DEFAULT '',
  `homeimgthumb` varchar(255) NOT NULL DEFAULT '',
  `imgposition` tinyint(1) NOT NULL DEFAULT '1',
  `bodytext` mediumtext NOT NULL,
  `copyright` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `ratingdetail` varchar(255) NOT NULL DEFAULT '',
  `allowed_send` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_print` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_save` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitslm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `keywords` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `listcatid` (`listcatid`)
) ENGINE=MyISAM  AUTO_INCREMENT=7  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv_vi_news_8`
--

INSERT INTO `nv_vi_news_8` VALUES
(1, '1,8,12', 0, 1, 'Quỳnh Nhi', 1, 1274989177, 1275318126, 1, 1274989140, 0, 2, 'Ra mắt công ty mã nguồn mở đầu tiên tại Việt Nam', 'Ra-mat-cong-ty-ma-nguon-mo-dau-tien-tai-Viet-Nam', 'Mã nguồn mở NukeViet vốn đã quá quen thuộc với cộng đồng CNTT Việt Nam trong mấy năm qua. Tuy chưa hoạt động chính thức, nhưng chỉ trong khoảng 5 năm gần đây, mã nguồn mở NukeViet đã được dùng phổ biến ở Việt Nam, áp dụng ở hầu hết các lĩnh vực, từ tin tức đến thương mại điện tử, từ các website cá nhân cho tới những hệ thống website doanh nghiệp.', '2010_05/nangly.jpg', 'Thành lập VINADES.,JSC', 'thumb/nangly.jpg|block/nangly.jpg', 1, '<p style=\"text-align: justify;\"> Để chuyên nghiệp hóa việc phát hành mã nguồn mở NukeViet, Ban quản trị NukeViet quyết định thành lập doanh nghiệp chuyên quản NukeViet mang tên Công ty cổ phần Phát triển nguồn mở Việt Nam (Viết tắt là VINADES.,JSC), chính thức ra mắt vào ngày 25-2-2010 (trụ sở tại 67B/35 Khương Hạ, Khương Đình, Thanh Xuân, Hà Nội) nhằm phát triển, phổ biến hệ thống NukeViet tại Việt Nam.<br  /> <br  /> Theo ông Nguyễn Anh Tú, Chủ tịch HĐQT VINADES, công ty sẽ phát triển bộ mã nguồn NukeViet nhất quán theo con đường mã nguồn mở đã chọn, chuyên nghiệp và quy mô hơn bao giờ hết. Đặc biệt là hoàn toàn miễn phí đúng tinh thần mã nguồn mở quốc tế.<br  /> <br  /> NukeViet là một hệ quản trị nội dung mã nguồn mở (Opensource Content Management System) thuần Việt từ nền tảng PHP-Nuke và cơ sở dữ liệu MySQL. Người sử dụng thường gọi NukeViet là portal vì nó có khả năng tích hợp nhiều ứng dụng trên nền web, cho phép người sử dụng có thể dễ dàng xuất bản và quản trị các nội dung của họ lên internet hoặc intranet.<br  /> <br  /> NukeViet cung cấp nhiều dịch vụ và ứng dụng nhờ khả năng tăng cường tính năng thêm các module, block... tạo sự dễ dàng cài đặt, quản lý, ngay cả với những người mới tiếp cận với website. Người dùng có thể tìm hiểu thêm thông tin và tải về sản phẩm tại địa chỉ http://nukeviet.vn</p><blockquote> <p style=\"text-align: justify;\"> <em>Thông tin ra mắt công ty VINADES có thể tìm thấy trên trang 7 báo Hà Nội Mới ra ngày 25/02/2010 (<a href=\"http://hanoimoi.com.vn/newsdetail/Cong_nghe/309750/ra-mat-cong-ty-ma-nguon-mo-dau-tien-tai-viet-nam.htm\" target=\"_blank\">xem chi tiết</a>), Bản tin tiếng Anh của đài tiếng nói Việt Nam ngày 26/02/2010 (<a href=\"http://english.vovnews.vn/Home/First-opensource-company-starts-operation/20102/112960.vov\" target=\"_blank\">xem chi tiết</a>); trang 7 báo An ninh Thủ Đô số 2858 ra vào thứ 2 ngày 01/03/2010 và các trang tin tức, báo điện tử khác.</em></p></blockquote>', 0, 1, 2, 1, '29|6', 1, 1, 1, 97, 0, 0, 'nguồn mở, quen thuộc, cộng đồng, việt nam, hoạt động, gần đây, phổ biến, áp dụng, hầu hết, hết các, lĩnh vực, tin tức, thương mại điện, điện tử, cá nhân, hệ thống'), 
(2, '1,8,12', 1, 1, 'laser', 2, 1274989787, 1275318114, 1, 1274989740, 0, 2, 'Công bố dự án NukeViet 3.0 sau 1 tháng ra mắt VINADES.,JSC', 'Cong-bo-du-an-NukeViet-3-0-sau-1-thang-ra-mat-VINADES-JSC', 'NukeViet 3.0 - Một nền tảng được xây dựng hoàn toàn mới với những công nghệ web tiên tiến nhất hiện nay hứa hẹn sẽ làm một cuộc cách mạng về mã nguồn mở ở Việt Nam. Món quà này là lời cảm ơn chân thành nhất mà VINADES.,JSC muốn gửi tới cộng đồng sau một tháng chính thức ra mắt.', '2010_05/nukeviet3.jpg', 'NukeViet 3.0', 'thumb/nukeviet3.jpg|block/nukeviet3.jpg', 1, '<p style=\"font-weight: bold;\"> <span style=\"font-size: 14pt;\">Câu chuyện của NukeViet và VINADES.,JSC</span></p><p style=\"font-weight: bold;\"> Từ một trăn trở</p><p style=\"text-align: justify;\"> Giữa năm 2009, trước yêu cầu cấp thiết phải đổi mới và làm một cuộc cách mạng cho mã nguồn mở NukeViet, một cuộc thảo luận sôi nổi đã diễn ra với tiêu đề &quot;Lối đi nào để chuyên nghiệp hóa mã nguồn mở NukeViet&quot;.</p><p> Kết quả của cuộc thảo luận này là 55 bài viết với hàng chục ý kiến đóng góp đã được đưa ra. Các giải pháp về tài chính, nhân lực, phương hướng hoạt động được đem ra thảo luận. rockbuilc, Nkd833 đề xuất phương án thành lập doanh nghiệp chuyên quản NukeViet như một giải pháp toàn diện để giải quyết vấn đề chuyên nghiệp hóa NukeViet. Các vấn đề được các thành viên tham gia thảo luận và mổ xẻ thẳng thắn, nhiều ý kiến phản biện trái chiều cũng được đưa ra trên tinh thần xây dựng. Sau 2 tháng thảo luận, Ban Quản Trị đã có dự định...</p><p> <span style=\"font-weight: bold;\">Gặp mặt</span></p><p> Tháng 11, Sau khi tham khảo các ý kiến của mọi người trên diễn đàn, Anh Tú đã trực tiếp về Việt Nam. Một cuộc offline được tổ chức chớp nhoáng với sự tham gia của các thành viên chủ chốt tại Hà Nội. Các cuộc tìm hiểu và tiếp xúc được triển khai gấp rút trong giai đoạn này.</p><p> <span style=\"font-weight: bold;\">Một mô hình - một lối đi</span></p><p style=\"text-align: justify;\"> Hướng đi chuyên nghiệp hóa việc phát triển NukeViet đã được anh Tú chọn lựa: &quot;Thành lập doanh nghiệp chuyên quản NukeViet&quot;. Doanh nghiệp chuyên quản NukeViet được thành lập từ chính nhu cầu của cộng đồng nhằm chuyên nghiệp hóa NukeViet, vì vậy mô hình công ty cổ phần được chọn lựa để đáp ứng yêu cầu đó. Chịu trách nhiệm triển khai, laser đã lên phương án đầu tư, mục tiêu, kế hoạch phát triển ngắn và dài hạn.</p><p> <br  /> <span style=\"font-weight: bold;\">Triển khai thực hiện</span></p><p style=\"text-align: justify;\"> Tháng 1 năm 2010, việc thành lập đã được xúc tiến. Ngày 25/02/2010, trên các bản tin tiếng Anh và tiếng Việt xuất hiện bản tin &quot;Ra mắt công ty mã nguồn mở đầu tiên tại Việt Nam&quot;. Đó là Công ty cổ phần Phát triển nguồn mở Việt Nam (VIET NAM OPEN SOURCE DEVELOPMENT JOINT STOCK COMPANY - VINADES.,JSC). Đây là một vài hình ảnh trong ngày khai trương:</p><div style=\"text-align: center;\"> <img alt=\"Anh Tú phát biểu khai trương VINADES.,JSC \" height=\"332\" src=\"http://nukeviet.vn/uploads/spaw2/images/anhtu-phatbieu.jpg\" style=\"border: 0px solid;\" width=\"500\" /></div><div style=\"text-align: center;\"> Anh Tú phát biểu khai trương VINADES.,JSC <p> <br  /> <img alt=\"\" border=\"0\" src=\"http://nukeviet.vn/uploads/spaw2/images/hung-phatbieu.jpg\" style=\"width: 500px;\" width=\"500\" /></p> <p> Nguyễn Hùng giới thiệu đôi nét về công ty, mục tiêu và phương hướng hoạt động.</p> <p> <br  /> <img alt=\"\" border=\"0\" height=\"332\" src=\"http://nukeviet.vn/uploads/spaw2/images/nangly.jpg\" style=\"width: 500px; height: 332px;\" width=\"500\" /></p> <p> Cùng nâng ly chúc mừng khai trương.</p></div><p style=\"font-weight: bold;\"> ... và lời cảm ơn gửi tới cộng đồng</p><p style=\"text-align: justify;\"> VINADES.,JSC từ khi được thai nghén tới lúc chập chững những bước đi ban đầu đều có sự động viên, ủng hộ và đóng góp lớn nhỏ của cộng đồng NukeViet - Một cộng đồng gắn liền với những ký ức, những kỷ niệm buồn vui và mang trong mỗi thành viên một đam mê, một hoài bão lớn lao. &quot;Lửa thử vàng, gian nan thử sức&quot;, mỗi khó khăn trả qua khiến cộng đồng NukeViet lớn dần lên, gắn kết với nhau bằng một sợi dây vô hình không thể chia cắt: đó là niềm đam mê với mã nguồn mở, với công nghệ web. VINADES.,JSC được tạo ra từ cộng đồng và sẽ cố gắng hết sức để hoạt động vì lợi ích của cộng đồng.</p><p>  </p><div style=\"text-align: center;\"> <img alt=\"\" border=\"0\" height=\"375\" src=\"http://nukeviet.vn/uploads/spaw2/images/anhvp2.jpg\" style=\"width: 500px; height: 375px;\" width=\"500\" /></div><p>  </p><p style=\"text-align: center;\"> Văn phòng làm việc của VINADES.,JSC ở Hà Nội.</p><div style=\"text-align: center;\"> <img alt=\"\" border=\"0\" height=\"375\" src=\"http://nukeviet.vn/uploads/spaw2/images/anhvp3.jpg\" style=\"width: 500px; height: 375px;\" width=\"500\" /></div><p>  </p><p style=\"text-align: center;\"> Một góc văn phòng nhìn từ trong ra ngoài.</p><p style=\"font-weight: bold;\"> NukeViet 3.0 - Cuộc cách mạng của NukeViet</p><p style=\"text-align: justify;\"> Sau nhiều tháng triển khai, NukeViet 3.0 đã được định hình và dự định công bố bản beta trong thời gian gần. NukeViet 3.0 là phiên bản mang tính cách mạng của hệ thống NukeViet vì 100% các dòng code của NukeViet 3.0 đã được viết mới hoàn toàn chứ không sử dụng nền tảng cũ. Việc này đã ngốn rất nhiều thời gian và công sức của đội ngũ lập trình. Đó cũng là lý do vì sao bản 2.0 không được cải tiến nhiều trong thời gian qua.</p><div style=\"text-align: justify;\"> NukeViet 3.0 được xây dựng với mong muốn có một nền tảng ổn định để sau đó có thể đầu tư lâu dài, xây dựng một thư viện ứng dụng phong phú. VINADES.,JSC sẽ song hành cùng cộng đồng NukeViet trong việc hỗ trợ và phát triển NukeViet thành một mã nguồn mở hoạt động ở quy mô chuyên nghiệp. Đây là bước đi đầu tiên trong trong tiến trình chuyên nghiệp hóa này. Các ứng dụng bổ sung sẽ được xây dựng bài bản, chất lượng. Cộng đồng NukeViet sẽ không chỉ là cộng đồng người sử dụng mà sẽ được đầu tư về đào tạo để trở thành một cộng đồng lập trình mạnh. Thông tin chi tiết về dự án phát triển NukeViet 3.0 được cập nhật tại đây: <a href=\"http://nukeviet.vn/phpbb/viewforum.php?f=99\" target=\"_blank\">http://nukeviet.vn/phpbb/viewforum.php?f=99</a></div>', 0, 1, 2, 1, '39|9', 1, 1, 1, 91, 0, 0, 'nền tảng, xây dựng, hoàn toàn, với những, công nghệ, tiên tiến, hiện nay, hứa hẹn, cách mạng, nguồn mở, việt nam, món quà, cảm ơn, chân thành, thành nhất, cộng đồng'), 
(6, '1,8,10', 0, 1, '', 0, 1274994722, 1275318001, 1, 1274994720, 0, 2, 'Thư mời hợp tác liên kết quảng cáo và cung cấp hosting thử nghiệm', 'Thu-moi-hop-tac', 'Hiện tại VINADES.,JSC đang tiến hành phát triển bộ mã nguồn NukeViet phiên bản 3.0 – một thế hệ CMS hoàn toàn mới với nhiều tính năng ưu việt, được đầu tư bài bản với kinh phí lớn. Với thiện chí hợp tác cùng phát triển VINADES.,JSC xin trân trọng gửi lời mời hợp tác đến Quý đối tác là các công ty cung cấp tên miền - hosting, các doanh nghiệp quan tâm và mong muốn hợp tác cùng VINADES để cùng thực hiện chung các hoạt động kinh doanh nhằm gia tăng giá trị, quảng bá thương hiệu chung cho cả hai bên.', '2010_05/hoptac.jpg', '', 'thumb/hoptac.jpg|block/hoptac.jpg', 1, '<div style=\"text-align: center;\"> <h2 style=\"color: rgb(255, 69, 0);\"> THƯ MỜI HỢP TÁC</h2> <h4> TRONG VIỆC LIÊN KẾT QUẢNG CÁO, CUNG CẤP HOSTING THỬ NGHIỆM PHÁT TRIỂN</h4> <h2> MÃ NGUỒN MỞ NUKEVIET</h2> </div> <p style=\"text-align: justify; line-height: 130%; font-weight: bold;\">  </p> <p style=\"text-align: justify; line-height: 130%; font-weight: bold;\"> Kính gửi: QUÍ KHÁCH VÀ ĐỐI TÁC</p> <p style=\"text-align: justify; line-height: 130%; font-style: italic; text-indent: 1cm;\"> Lời đầu tiên, Ban giám đốc công ty cổ phần Phát Triển Nguồn Mở Việt Nam (VINADES.,JSC) xin gửi đến Quý đối tác lời chào trân trọng, lời chúc may mắn và thành công. Tiếp đến chúng tôi xin được giới thiệu và ngỏ lời mời hợp tác kinh doanh.</p> <p style=\"text-align: justify; line-height: 130%; font-style: italic; text-indent: 1cm;\"> VINADES.,JSC ra đời nhằm chuyên nghiệp hóa việc phát hànhmã nguồn mở NukeViet. Đồng thời khai thác các dự án từ NukeViet tạo kinh phí phát triển bền vững cho mã nguồn này.</p> <p style=\"text-align: justify; line-height: 130%; font-style: italic; text-indent: 1cm;\"> NukeViet là hệ quản trị nội dung, là website đa năng đầu tiên của Việt Nam do cộng đồng người Việt phát triển. Có nhiều lợi thế như cộng đồng người sử dụng đông đảo nhất tại Việt Nam hiện nay, sản phẩm thuần Việt, dễ sử dụng, dễ phát triển.</p> <p style=\"text-align: justify; line-height: 130%; font-style: italic; text-indent: 1cm;\"> Hiện tại VINADES.,JSC đang tiến hành phát triển bộ mã nguồn NukeViet phiên bản 3.0 – một thế hệ CMS hoàn toàn mới với nhiều tính năng ưu việt, được đầu tư bài bản với kinh phí lớn.</p> <p style=\"text-align: justify; line-height: 130%; font-style: italic; text-indent: 1cm;\"> Với thiện chí hợp tác cùng phát triển VINADES.,JSC xin trân trọng gửi lời mời hợp tác đến Quý đối tác là các công ty cung cấp tên miền -hosting, các doanh nghiệp quan tâm và mong muốn hợp tác cùng VINADES để cùng thực hiện chung các hoạt động kinh doanh nhằm gia tăng giá trị, quảng bá thương hiệu chung cho cả hai bên.</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm; font-weight: bold;\"> Phương thức hợp tác nhưsau:</p> <p style=\"text-align: justify; line-height: 130%; font-weight: bold;\"> 1.Quảng cáo, trao đổi banner, liên kết website:</p> <p style=\"text-align: justify; line-height: 130%;\"> a. Mô tả hình thức:</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Quảng cáo trên website &amp; hệ thống kênh truyền thông của 2 bên.</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Quảng cáo trên các phiên bản phát hành của mã nguồn mở NukeViet.</p> <p style=\"text-align: justify; line-height: 130%;\"> b, Lợi ích:</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Quảng bá rộng rãi cho đối tượng của 2 bên.</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Giảm chi phí quảng bá cho 2 bên.</p> <p style=\"text-align: justify; line-height: 130%;\"> c, Trách nhiệm:</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Hai bên sẽ thỏa thuận và đưa quảng cáo của mình vào website của đối tác. Thỏa thuận vị trí, kích thước và trang đặt banner quảng cáo nhằm mang lại hiệu quả cao cho cả hai bên.</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Mở forum hỗ trợ người dùng hosting ngay tại diễn đàn NukeViet.VN để quý công ty dễ dàng hỗ trợ người sử dụng cũng như thực hiện các kế hoạch truyền thông của mình tới cộng đồng NukeViet.</p> <p style=\"text-align: justify; line-height: 130%; font-weight: bold;\"> 2.Hợp tác cung cấp hosting thử nghiệm NukeViet:</p> <p style=\"text-align: justify; line-height: 130%;\"> a. Mô tả hình thức:</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Hai bên ký hợp đồng nguyên tắc &amp; thỏa thuận hợp tác trong việc hợp tác phát triển mã nguồn mở NukeViet. Theo đó:</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> + Phía đối tác cung cấp mỗi loại 1 gói hosting đại lý cho VINADES.,JSC để chúng tôi test trong quá trình phát triển mã nguồn mở NukeViet, để đảm bảo NukeViet sẵn sàng tương thích với hosting của quý khách ngay khi ra mắt.</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> + VINADES.,JSC sẽ công báo thông tin chứng nhận host của phía đối tác là phù hợp, tương thích tốt nhất với NukeViet tới cộng đồng những người phát triển và sử dụng NukeViet.</p> <p style=\"text-align: justify; line-height: 130%;\"> b. Lợi ích:</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Mở rộng thị trường theo cả hướng đối tượng.</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Tiết kiệm chi phí –nâng cao hiệu quả kinh doanh.</p> <p style=\"text-align: justify; line-height: 130%;\"> c. Trách nhiệm:</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Bên đối tác cung cấp miễn phí host để VINADES.,JSC thực hiện việc test tương thích mã nguồn NukeViet trên các gói hosting của đối tác.</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - VINADES.,JSC công bố tới cộng đồng về kết quả chứng nhận chất lượng host của phía đối tác.</p> <p style=\"text-align: justify; line-height: 130%; font-weight: bold;\"> 3,Hợp tác nhân lực hỗ trợ người sử dụng:</p> <p style=\"text-align: justify; line-height: 130%;\"> a, Mô tả hình thức:</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Hai bên sẽ hỗ trợ lẫn nhau trong quá trình giải quyết các yêu cầu của khách hàng.</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> + Bên đối tác gửi các yêu cầu của khách hàng về mã nguồn NukeViet tới VINADES.,JSC</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> + VINADES gửi các yêu cầu của khách hàng có liên quan đến dịch vụ hosting tới phía đối tác.</p> <p style=\"text-align: justify; line-height: 130%;\"> b, Lợi ích:</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Giảm thiểu chi phí, nhân lực hỗ trợ khách hàng của cả 2 bên.</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Tăng hiệu quả hỗ trợ khách hàng.</p> <p style=\"text-align: justify; line-height: 130%;\"> c, Trách nhiệm:</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Khi nhận được yêu cầu hỗ trợ VINADES hoặc bên đối tác cần ưu tiên xử lý nhanh gọn nhằm nâng cao hiệuquả của sự hợp tác song phưong này.</p> <p style=\"text-align: justify; line-height: 130%; font-weight: bold;\"> 4. Các hình thức khác:</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> Ngoài các hình thức đã đề xuất ở trên, là đơn vị phát hành mã nguồn mở NukeViet chúng tôi có thể phát hành quảng cáo trên giao diện phần mềm, trên các bài viết giới thiệu xuất hiện ngay sau khi cài đặt phần mềm… chúng tôi tin tưởng rằng với lượng phát hành lên đến hàng chục ngàn lượt tải về cho mỗi phiên bản là một cơ hội quảng cáo rất hiệu quả đến cộng đồng Webmaster Việt Nam.</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> Với mong muốn tạo nên cộng đồng phát triển và sử dụng NukeViet rộng lớn đúng như mục tiêu đề ra,chúng tôi luôn linh động trong các hình thức hợp tác nhằm mang lại sự thuận tiện cho đối tác cũng như mục tiêu hợp tác đa phương. Chúng tôi sẽ tiếp nhận các hình thức hợp tác khác mà bên đối tác trình bày hợp lý và hiệu quả, mong nhận được thêm nhiều hình thức hợp tác khác từ đối tác. Phương châm của chúng tôi “Cùng hợp tác để phát triển”.</p> <p style=\"text-align: justify; line-height: 130%; font-style: italic; text-indent: 1cm;\"> Trân trọng cảm ơn, rất mong được hợp tác cùng quý vị.</p> <span style=\"font-weight: bold;\">Thông tin liên hệ:</span> <p style=\"text-align: justify;\"> CÔNGTY CỔ PHẦN PHÁT TRIỂN NGUỒN MỞ VIỆT NAM (VINADES.,JSC)</p> <p style=\"text-align: justify; text-indent: 1cm;\"> Trụ sở chính: 67B (ngõ 35) phố Khương Hạ, Khương Đình, ThanhXuân, Hà Nội.</p> <p style=\"text-align: justify; text-indent: 1cm;\"> Điện thoại: (84-4) 85 872007</p> <p style=\"text-align: justify; text-indent: 1cm;\"> Fax: (84-4) 35 500 914</p> <p style=\"text-align: justify; text-indent: 1cm;\"> Website: <a href=\"http://www.vinades.vn/\">www.vinades.vn</a> – <a href=\"http://www.nukeviet.vn/\">www.nukeviet.vn</a></p> <p style=\"text-align: justify; text-indent: 1cm;\"> Email: <a href=\"mailto:contact@vinades.vn\">contact@vinades.vn</a></p>', 0, 1, 2, 1, '29|8', 1, 1, 1, 73, 0, 0, 'hiện tại, tiến hành, phát triển, phiên bản, thế hệ, hoàn toàn, tính năng, ưu việt, kinh phí, thiện chí, hợp tác, trân trọng, mời hợp tác, đối tác, các công ty, công ty, cung cấp, tên miền, các doanh, doanh nghiệp, quan tâm');


-- ---------------------------------------


--
-- Table structure for table `nv_vi_news_9`
--

DROP TABLE IF EXISTS `nv_vi_news_9`;
CREATE TABLE `nv_vi_news_9` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) NOT NULL DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` mediumtext NOT NULL,
  `homeimgfile` varchar(255) NOT NULL DEFAULT '',
  `homeimgalt` varchar(255) NOT NULL DEFAULT '',
  `homeimgthumb` varchar(255) NOT NULL DEFAULT '',
  `imgposition` tinyint(1) NOT NULL DEFAULT '1',
  `bodytext` mediumtext NOT NULL,
  `copyright` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `ratingdetail` varchar(255) NOT NULL DEFAULT '',
  `allowed_send` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_print` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_save` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitslm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `keywords` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `listcatid` (`listcatid`)
) ENGINE=MyISAM  AUTO_INCREMENT=7  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv_vi_news_block`
--

DROP TABLE IF EXISTS `nv_vi_news_block`;
CREATE TABLE `nv_vi_news_block` (
  `bid` int(11) unsigned NOT NULL,
  `id` int(11) unsigned NOT NULL,
  `weight` int(11) unsigned NOT NULL,
  UNIQUE KEY `bid` (`bid`,`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv_vi_news_block`
--

INSERT INTO `nv_vi_news_block` VALUES
(1, 5, 3), 
(1, 2, 2), 
(1, 1, 1), 
(2, 6, 4), 
(2, 5, 3), 
(2, 2, 2), 
(2, 1, 1);


-- ---------------------------------------


--
-- Table structure for table `nv_vi_news_block_cat`
--

DROP TABLE IF EXISTS `nv_vi_news_block_cat`;
CREATE TABLE `nv_vi_news_block_cat` (
  `bid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `adddefault` tinyint(4) NOT NULL DEFAULT '0',
  `number` mediumint(4) NOT NULL DEFAULT '10',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `image` varchar(255) NOT NULL,
  `thumbnail` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `weight` smallint(4) NOT NULL DEFAULT '0',
  `keywords` mediumtext NOT NULL,
  `add_time` int(11) NOT NULL DEFAULT '0',
  `edit_time` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`bid`),
  UNIQUE KEY `title` (`title`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM  AUTO_INCREMENT=3  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv_vi_news_block_cat`
--

INSERT INTO `nv_vi_news_block_cat` VALUES
(1, 0, 4, 'Tin tiêu điểm', 'Tin-tieu-diem', '', '', 'Tin tiêu điểm', 1, '', 1279945710, 1279956943), 
(2, 1, 4, 'Tin mới nhất', 'Tin-moi-nhat', '', '', 'Tin tiêu điểm', 2, '', 1279945725, 1279956445);


-- ---------------------------------------


--
-- Table structure for table `nv_vi_news_cat`
--

DROP TABLE IF EXISTS `nv_vi_news_cat`;
CREATE TABLE `nv_vi_news_cat` (
  `catid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `parentid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL DEFAULT '',
  `description` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL DEFAULT '',
  `thumbnail` varchar(255) NOT NULL DEFAULT '',
  `weight` smallint(4) unsigned NOT NULL DEFAULT '0',
  `order` mediumint(8) NOT NULL DEFAULT '0',
  `lev` smallint(4) NOT NULL DEFAULT '0',
  `viewcat` varchar(50) NOT NULL DEFAULT 'viewcat_page_new',
  `numsubcat` int(11) NOT NULL DEFAULT '0',
  `subcatid` varchar(255) NOT NULL DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `numlinks` tinyint(2) unsigned NOT NULL DEFAULT '3',
  `keywords` mediumtext NOT NULL,
  `admins` mediumtext NOT NULL,
  `add_time` int(11) unsigned NOT NULL DEFAULT '0',
  `edit_time` int(11) unsigned NOT NULL DEFAULT '0',
  `del_cache_time` int(11) NOT NULL DEFAULT '0',
  `who_view` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `groups_view` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`catid`),
  UNIQUE KEY `alias` (`alias`),
  KEY `parentid` (`parentid`)
) ENGINE=MyISAM  AUTO_INCREMENT=13  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv_vi_news_cat`
--

INSERT INTO `nv_vi_news_cat` VALUES
(1, 0, 'Tin tức', 'Tin-tuc', '', '', '', 1, 1, 0, 'viewcat_main_right', 3, '8,12,9', 1, 3, '', '', 1274986690, 1274986690, 1300986690, 0, ''), 
(2, 0, 'Sản phẩm', 'San-pham', '', '', '', 2, 5, 0, 'viewcat_page_new', 0, '', 1, 3, '', '', 1274986705, 1274986705, 1300986705, 0, ''), 
(8, 1, 'Thông cáo báo chí', 'thong-cao-bao-chi', '', '', '', 1, 2, 1, 'viewcat_page_new', 0, '', 1, 3, '', '', 1274987105, 1274987244, 1300987105, 0, ''), 
(9, 1, 'Tin công nghệ', 'Tin-cong-nghe', '', '', '', 3, 4, 1, 'viewcat_page_new', 0, '', 1, 3, '', '', 1274987212, 1274987212, 1300987212, 0, ''), 
(10, 0, 'Đối tác', 'Doi-tac', '', '', '', 3, 9, 0, 'viewcat_main_right', 0, '', 1, 3, '', '', 1274987460, 1274987460, 1300987460, 0, ''), 
(11, 0, 'Tuyển dụng', 'Tuyen-dung', '', '', '', 4, 12, 0, 'viewcat_page_new', 0, '', 1, 3, '', '', 1274987538, 1274987538, 1300987538, 0, ''), 
(12, 1, 'Bản tin nội bộ', 'Ban-tin-noi-bo', '', '', '', 2, 3, 1, 'viewcat_page_new', 0, '', 1, 3, '', '', 1274987902, 1274987902, 1300987902, 0, '');


-- ---------------------------------------


--
-- Table structure for table `nv_vi_news_comments`
--

DROP TABLE IF EXISTS `nv_vi_news_comments`;
CREATE TABLE `nv_vi_news_comments` (
  `cid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `content` mediumtext NOT NULL,
  `post_time` int(11) unsigned NOT NULL DEFAULT '0',
  `userid` int(11) NOT NULL DEFAULT '0',
  `post_name` varchar(100) NOT NULL,
  `post_email` varchar(100) NOT NULL,
  `post_ip` varchar(15) NOT NULL,
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`cid`),
  KEY `post_time` (`post_time`),
  KEY `id` (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv_vi_news_log`
--

DROP TABLE IF EXISTS `nv_vi_news_log`;
CREATE TABLE `nv_vi_news_log` (
  `log_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `log_time` int(11) NOT NULL DEFAULT '0',
  `log_admin` int(11) NOT NULL DEFAULT '0',
  `id` int(11) NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) NOT NULL DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` mediumtext NOT NULL,
  `homeimgfile` varchar(255) NOT NULL DEFAULT '',
  `homeimgalt` varchar(255) NOT NULL DEFAULT '',
  `homeimgthumb` varchar(255) NOT NULL DEFAULT '',
  `imgposition` tinyint(1) NOT NULL DEFAULT '1',
  `bodytext` mediumtext NOT NULL,
  `copyright` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `ratingdetail` varchar(255) NOT NULL DEFAULT '',
  `allowed_send` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_print` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_save` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitslm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `keywords` text NOT NULL,
  PRIMARY KEY (`log_id`),
  KEY `id` (`id`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `listcatid` (`listcatid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv_vi_news_rows`
--

DROP TABLE IF EXISTS `nv_vi_news_rows`;
CREATE TABLE `nv_vi_news_rows` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) NOT NULL DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` mediumtext NOT NULL,
  `homeimgfile` varchar(255) NOT NULL DEFAULT '',
  `homeimgalt` varchar(255) NOT NULL DEFAULT '',
  `homeimgthumb` varchar(255) NOT NULL DEFAULT '',
  `imgposition` tinyint(1) NOT NULL DEFAULT '1',
  `bodytext` mediumtext NOT NULL,
  `copyright` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `ratingdetail` varchar(255) NOT NULL DEFAULT '',
  `allowed_send` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_print` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_save` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitslm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `keywords` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `listcatid` (`listcatid`)
) ENGINE=MyISAM  AUTO_INCREMENT=7  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv_vi_news_rows`
--

INSERT INTO `nv_vi_news_rows` VALUES
(1, '1,8,12', 0, 1, 'Quỳnh Nhi', 1, 1274989177, 1275318126, 1, 1274989140, 0, 2, 'Ra mắt công ty mã nguồn mở đầu tiên tại Việt Nam', 'Ra-mat-cong-ty-ma-nguon-mo-dau-tien-tai-Viet-Nam', 'Mã nguồn mở NukeViet vốn đã quá quen thuộc với cộng đồng CNTT Việt Nam trong mấy năm qua. Tuy chưa hoạt động chính thức, nhưng chỉ trong khoảng 5 năm gần đây, mã nguồn mở NukeViet đã được dùng phổ biến ở Việt Nam, áp dụng ở hầu hết các lĩnh vực, từ tin tức đến thương mại điện tử, từ các website cá nhân cho tới những hệ thống website doanh nghiệp.', '2010_05/nangly.jpg', 'Thành lập VINADES.,JSC', 'thumb/nangly.jpg|block/nangly.jpg', 1, '<p style=\"text-align: justify;\"> Để chuyên nghiệp hóa việc phát hành mã nguồn mở NukeViet, Ban quản trị NukeViet quyết định thành lập doanh nghiệp chuyên quản NukeViet mang tên Công ty cổ phần Phát triển nguồn mở Việt Nam (Viết tắt là VINADES.,JSC), chính thức ra mắt vào ngày 25-2-2010 (trụ sở tại 67B/35 Khương Hạ, Khương Đình, Thanh Xuân, Hà Nội) nhằm phát triển, phổ biến hệ thống NukeViet tại Việt Nam.<br  /> <br  /> Theo ông Nguyễn Anh Tú, Chủ tịch HĐQT VINADES, công ty sẽ phát triển bộ mã nguồn NukeViet nhất quán theo con đường mã nguồn mở đã chọn, chuyên nghiệp và quy mô hơn bao giờ hết. Đặc biệt là hoàn toàn miễn phí đúng tinh thần mã nguồn mở quốc tế.<br  /> <br  /> NukeViet là một hệ quản trị nội dung mã nguồn mở (Opensource Content Management System) thuần Việt từ nền tảng PHP-Nuke và cơ sở dữ liệu MySQL. Người sử dụng thường gọi NukeViet là portal vì nó có khả năng tích hợp nhiều ứng dụng trên nền web, cho phép người sử dụng có thể dễ dàng xuất bản và quản trị các nội dung của họ lên internet hoặc intranet.<br  /> <br  /> NukeViet cung cấp nhiều dịch vụ và ứng dụng nhờ khả năng tăng cường tính năng thêm các module, block... tạo sự dễ dàng cài đặt, quản lý, ngay cả với những người mới tiếp cận với website. Người dùng có thể tìm hiểu thêm thông tin và tải về sản phẩm tại địa chỉ http://nukeviet.vn</p><blockquote> <p style=\"text-align: justify;\"> <em>Thông tin ra mắt công ty VINADES có thể tìm thấy trên trang 7 báo Hà Nội Mới ra ngày 25/02/2010 (<a href=\"http://hanoimoi.com.vn/newsdetail/Cong_nghe/309750/ra-mat-cong-ty-ma-nguon-mo-dau-tien-tai-viet-nam.htm\" target=\"_blank\">xem chi tiết</a>), Bản tin tiếng Anh của đài tiếng nói Việt Nam ngày 26/02/2010 (<a href=\"http://english.vovnews.vn/Home/First-opensource-company-starts-operation/20102/112960.vov\" target=\"_blank\">xem chi tiết</a>); trang 7 báo An ninh Thủ Đô số 2858 ra vào thứ 2 ngày 01/03/2010 và các trang tin tức, báo điện tử khác.</em></p></blockquote>', 0, 1, 2, 1, '29|6', 1, 1, 1, 97, 0, 0, 'nguồn mở, quen thuộc, cộng đồng, việt nam, hoạt động, gần đây, phổ biến, áp dụng, hầu hết, hết các, lĩnh vực, tin tức, thương mại điện, điện tử, cá nhân, hệ thống'), 
(2, '1,8,12', 1, 1, 'laser', 2, 1274989787, 1275318114, 1, 1274989740, 0, 2, 'Công bố dự án NukeViet 3.0 sau 1 tháng ra mắt VINADES.,JSC', 'Cong-bo-du-an-NukeViet-3-0-sau-1-thang-ra-mat-VINADES-JSC', 'NukeViet 3.0 - Một nền tảng được xây dựng hoàn toàn mới với những công nghệ web tiên tiến nhất hiện nay hứa hẹn sẽ làm một cuộc cách mạng về mã nguồn mở ở Việt Nam. Món quà này là lời cảm ơn chân thành nhất mà VINADES.,JSC muốn gửi tới cộng đồng sau một tháng chính thức ra mắt.', '2010_05/nukeviet3.jpg', 'NukeViet 3.0', 'thumb/nukeviet3.jpg|block/nukeviet3.jpg', 1, '<p style=\"font-weight: bold;\"> <span style=\"font-size: 14pt;\">Câu chuyện của NukeViet và VINADES.,JSC</span></p><p style=\"font-weight: bold;\"> Từ một trăn trở</p><p style=\"text-align: justify;\"> Giữa năm 2009, trước yêu cầu cấp thiết phải đổi mới và làm một cuộc cách mạng cho mã nguồn mở NukeViet, một cuộc thảo luận sôi nổi đã diễn ra với tiêu đề &quot;Lối đi nào để chuyên nghiệp hóa mã nguồn mở NukeViet&quot;.</p><p> Kết quả của cuộc thảo luận này là 55 bài viết với hàng chục ý kiến đóng góp đã được đưa ra. Các giải pháp về tài chính, nhân lực, phương hướng hoạt động được đem ra thảo luận. rockbuilc, Nkd833 đề xuất phương án thành lập doanh nghiệp chuyên quản NukeViet như một giải pháp toàn diện để giải quyết vấn đề chuyên nghiệp hóa NukeViet. Các vấn đề được các thành viên tham gia thảo luận và mổ xẻ thẳng thắn, nhiều ý kiến phản biện trái chiều cũng được đưa ra trên tinh thần xây dựng. Sau 2 tháng thảo luận, Ban Quản Trị đã có dự định...</p><p> <span style=\"font-weight: bold;\">Gặp mặt</span></p><p> Tháng 11, Sau khi tham khảo các ý kiến của mọi người trên diễn đàn, Anh Tú đã trực tiếp về Việt Nam. Một cuộc offline được tổ chức chớp nhoáng với sự tham gia của các thành viên chủ chốt tại Hà Nội. Các cuộc tìm hiểu và tiếp xúc được triển khai gấp rút trong giai đoạn này.</p><p> <span style=\"font-weight: bold;\">Một mô hình - một lối đi</span></p><p style=\"text-align: justify;\"> Hướng đi chuyên nghiệp hóa việc phát triển NukeViet đã được anh Tú chọn lựa: &quot;Thành lập doanh nghiệp chuyên quản NukeViet&quot;. Doanh nghiệp chuyên quản NukeViet được thành lập từ chính nhu cầu của cộng đồng nhằm chuyên nghiệp hóa NukeViet, vì vậy mô hình công ty cổ phần được chọn lựa để đáp ứng yêu cầu đó. Chịu trách nhiệm triển khai, laser đã lên phương án đầu tư, mục tiêu, kế hoạch phát triển ngắn và dài hạn.</p><p> <br  /> <span style=\"font-weight: bold;\">Triển khai thực hiện</span></p><p style=\"text-align: justify;\"> Tháng 1 năm 2010, việc thành lập đã được xúc tiến. Ngày 25/02/2010, trên các bản tin tiếng Anh và tiếng Việt xuất hiện bản tin &quot;Ra mắt công ty mã nguồn mở đầu tiên tại Việt Nam&quot;. Đó là Công ty cổ phần Phát triển nguồn mở Việt Nam (VIET NAM OPEN SOURCE DEVELOPMENT JOINT STOCK COMPANY - VINADES.,JSC). Đây là một vài hình ảnh trong ngày khai trương:</p><div style=\"text-align: center;\"> <img alt=\"Anh Tú phát biểu khai trương VINADES.,JSC \" height=\"332\" src=\"http://nukeviet.vn/uploads/spaw2/images/anhtu-phatbieu.jpg\" style=\"border: 0px solid;\" width=\"500\" /></div><div style=\"text-align: center;\"> Anh Tú phát biểu khai trương VINADES.,JSC <p> <br  /> <img alt=\"\" border=\"0\" src=\"http://nukeviet.vn/uploads/spaw2/images/hung-phatbieu.jpg\" style=\"width: 500px;\" width=\"500\" /></p> <p> Nguyễn Hùng giới thiệu đôi nét về công ty, mục tiêu và phương hướng hoạt động.</p> <p> <br  /> <img alt=\"\" border=\"0\" height=\"332\" src=\"http://nukeviet.vn/uploads/spaw2/images/nangly.jpg\" style=\"width: 500px; height: 332px;\" width=\"500\" /></p> <p> Cùng nâng ly chúc mừng khai trương.</p></div><p style=\"font-weight: bold;\"> ... và lời cảm ơn gửi tới cộng đồng</p><p style=\"text-align: justify;\"> VINADES.,JSC từ khi được thai nghén tới lúc chập chững những bước đi ban đầu đều có sự động viên, ủng hộ và đóng góp lớn nhỏ của cộng đồng NukeViet - Một cộng đồng gắn liền với những ký ức, những kỷ niệm buồn vui và mang trong mỗi thành viên một đam mê, một hoài bão lớn lao. &quot;Lửa thử vàng, gian nan thử sức&quot;, mỗi khó khăn trả qua khiến cộng đồng NukeViet lớn dần lên, gắn kết với nhau bằng một sợi dây vô hình không thể chia cắt: đó là niềm đam mê với mã nguồn mở, với công nghệ web. VINADES.,JSC được tạo ra từ cộng đồng và sẽ cố gắng hết sức để hoạt động vì lợi ích của cộng đồng.</p><p>  </p><div style=\"text-align: center;\"> <img alt=\"\" border=\"0\" height=\"375\" src=\"http://nukeviet.vn/uploads/spaw2/images/anhvp2.jpg\" style=\"width: 500px; height: 375px;\" width=\"500\" /></div><p>  </p><p style=\"text-align: center;\"> Văn phòng làm việc của VINADES.,JSC ở Hà Nội.</p><div style=\"text-align: center;\"> <img alt=\"\" border=\"0\" height=\"375\" src=\"http://nukeviet.vn/uploads/spaw2/images/anhvp3.jpg\" style=\"width: 500px; height: 375px;\" width=\"500\" /></div><p>  </p><p style=\"text-align: center;\"> Một góc văn phòng nhìn từ trong ra ngoài.</p><p style=\"font-weight: bold;\"> NukeViet 3.0 - Cuộc cách mạng của NukeViet</p><p style=\"text-align: justify;\"> Sau nhiều tháng triển khai, NukeViet 3.0 đã được định hình và dự định công bố bản beta trong thời gian gần. NukeViet 3.0 là phiên bản mang tính cách mạng của hệ thống NukeViet vì 100% các dòng code của NukeViet 3.0 đã được viết mới hoàn toàn chứ không sử dụng nền tảng cũ. Việc này đã ngốn rất nhiều thời gian và công sức của đội ngũ lập trình. Đó cũng là lý do vì sao bản 2.0 không được cải tiến nhiều trong thời gian qua.</p><div style=\"text-align: justify;\"> NukeViet 3.0 được xây dựng với mong muốn có một nền tảng ổn định để sau đó có thể đầu tư lâu dài, xây dựng một thư viện ứng dụng phong phú. VINADES.,JSC sẽ song hành cùng cộng đồng NukeViet trong việc hỗ trợ và phát triển NukeViet thành một mã nguồn mở hoạt động ở quy mô chuyên nghiệp. Đây là bước đi đầu tiên trong trong tiến trình chuyên nghiệp hóa này. Các ứng dụng bổ sung sẽ được xây dựng bài bản, chất lượng. Cộng đồng NukeViet sẽ không chỉ là cộng đồng người sử dụng mà sẽ được đầu tư về đào tạo để trở thành một cộng đồng lập trình mạnh. Thông tin chi tiết về dự án phát triển NukeViet 3.0 được cập nhật tại đây: <a href=\"http://nukeviet.vn/phpbb/viewforum.php?f=99\" target=\"_blank\">http://nukeviet.vn/phpbb/viewforum.php?f=99</a></div>', 0, 1, 2, 1, '39|9', 1, 1, 1, 91, 0, 0, 'nền tảng, xây dựng, hoàn toàn, với những, công nghệ, tiên tiến, hiện nay, hứa hẹn, cách mạng, nguồn mở, việt nam, món quà, cảm ơn, chân thành, thành nhất, cộng đồng'), 
(5, '2', 1, 1, '', 0, 1274993307, 1275318039, 1, 1274993280, 0, 2, 'Giới thiệu về mã nguồn mở NukeViet', 'Gioi-thieu-ve-ma-nguon-mo-NukeViet', 'Chắc hẳn đây không phải lần đầu tiên bạn nghe nói đến mã nguồn mở. Và nếu bạn là người mê lướt web thì hẳn bạn từng nhìn thấy đâu đó cái tên NukeViet. NukeViet, phát âm là Nu-Ke-Việt, chính là phần mềm dùng để xây dựng các Website mà bạn ngày ngày online để truy cập đấy.', '2010_05/1243187502.jpg', '', 'thumb/1243187502.jpg|block/1243187502.jpg', 1, '<p> <strong><span style=\"font-size: 14px;\">THÔNGTIN VỀ MÃ NGUỒN MỞ NUKEVIET</span></strong></p><p style=\"font-weight: bold;\"> I. Giới thiệu chung:</p><p> NukeViet là một hệ quản trị nội dung mã nguồn mở (Opensource Content Management System), người sử dụng thường gọi NukeViet là portal vì nó có khả năng tích hợp nhiều ứng dụng trên nền Web.</p><p> NukeViet có 2 dòng phiên bản chính:</p><p> Dòng phiên bản trước năm 2009 (NukeViet 2.0 trở về trước) được Nguyễn Anh Tú- một lưu học sinh người Việt tại Nga - cùng cộng đồng phát triển thành một ứng dụng thuần Việt từ nền tảng PHP-Nuke.</p><p> Dòng phiên bản NukeViet 3.0 trở về sau (kể từ năm 2010 trở đi) là dòng phiên bản hoàn toàn mới, được xây dựng từ đầu với nhiều tính năng ưu việt.</p><p> NukeViet được viết bằng ngôn ngữ PHP và chủ yếu sử dụng cơ sở dữ liệu MySQL, cho phép người sử dụng có thể dễ dàng xuất bản &amp;quản trị các nội dung của họ lên Internet hoặc Intranet.</p><p> NukeViet được sử dụng ở nhiều website, từ những website cá nhân cho tới những hệ thống website doanh nghiệp, nó cung cấp nhiều dịch vụ và ứng dụng nhờ khả năng tăng cường tính năng bằng cách cài thêm các module, block... NukeViet có thể dễ dàng cài đặt, dễ dàng quản lý kể cả với những người mới sử dụng.</p><p style=\"text-align: justify;\"> NukeViet là giải pháp hoàn hảo cho các Website từ cá nhân cho tới các doanh nghiệp. NukeViet là bộ mã nguồn chất lượng cao, được phát hành theo giấy phép mã nguồn mở nên việc sử dụng NukeViet hoàn toàn miễn phí. Với người sử dụng cá nhân, tất cả đều có thể tự tạo cho mình một website chuyên nghiệp mà không mất bất cứ chi phí nào. Với những nhà phát triển Web, sử dụng NukeViet có thể nhanh chóng xây dựng các hệ thống lớn mà việc lập trình không đòi hỏi quá nhiều thời gian vì NukeViet đã xây dựng sẵn hệ thống quản lý ưu việt.</p><p>  </p><p> Thông tin chi tiết về NukeViet có thểtìm thấy ở bách khoa toàn thư mở Wikipedia: <a href=\"http://vi.wikipedia.org/wiki/NukeViet\">http://vi.wikipedia.org/wiki/NukeViet</a></p><p style=\"font-weight: bold;\"> II. Thông tin về diễn đàn NukeViet:</p><p> Diễn đàn NukeViet hoạt động trên website: <a href=\"http://nukeviet.vn/\"><span style=\"font-weight: bold;\">http://nukeviet.vn</span></a> hiện có trên 13.000 thành viên thực gồm học sinh, sinh viên &amp; nhiều thànhphần khác thuộc giới trí thức ở trong và ngoài nước.</p><p> Là một diễn đàn của các nhà quản lý website, rất nhiều thành viên trong diễn đàn NukeViet là cán bộ, lãnh đạo từ đủ mọi lĩnh vực: công nghệ thông tin, xây dựng,văn hóa - xã hội, thể thao, dịch vụ - du lịch... từ cử nhân, bác sĩ, kỹ sư cho đến bộ đội, công an...</p><p> Nhiều học sinh, sinh viên tham gia diễn đàn NukeViet, đam mê mã nguồn mở và đã thành công với chính công việc mà họ yêu thích.</p>', 0, 1, 2, 1, '40|8', 1, 1, 1, 90, 0, 0, 'quản trị, nội dung, sử dụng, khả năng, tích hợp, ứng dụng'), 
(6, '1,8,10', 0, 1, '', 0, 1274994722, 1275318001, 1, 1274994720, 0, 2, 'Thư mời hợp tác liên kết quảng cáo và cung cấp hosting thử nghiệm', 'Thu-moi-hop-tac', 'Hiện tại VINADES.,JSC đang tiến hành phát triển bộ mã nguồn NukeViet phiên bản 3.0 – một thế hệ CMS hoàn toàn mới với nhiều tính năng ưu việt, được đầu tư bài bản với kinh phí lớn. Với thiện chí hợp tác cùng phát triển VINADES.,JSC xin trân trọng gửi lời mời hợp tác đến Quý đối tác là các công ty cung cấp tên miền - hosting, các doanh nghiệp quan tâm và mong muốn hợp tác cùng VINADES để cùng thực hiện chung các hoạt động kinh doanh nhằm gia tăng giá trị, quảng bá thương hiệu chung cho cả hai bên.', '2010_05/hoptac.jpg', '', 'thumb/hoptac.jpg|block/hoptac.jpg', 1, '<div style=\"text-align: center;\"> <h2 style=\"color: rgb(255, 69, 0);\"> THƯ MỜI HỢP TÁC</h2> <h4> TRONG VIỆC LIÊN KẾT QUẢNG CÁO, CUNG CẤP HOSTING THỬ NGHIỆM PHÁT TRIỂN</h4> <h2> MÃ NGUỒN MỞ NUKEVIET</h2> </div> <p style=\"text-align: justify; line-height: 130%; font-weight: bold;\">  </p> <p style=\"text-align: justify; line-height: 130%; font-weight: bold;\"> Kính gửi: QUÍ KHÁCH VÀ ĐỐI TÁC</p> <p style=\"text-align: justify; line-height: 130%; font-style: italic; text-indent: 1cm;\"> Lời đầu tiên, Ban giám đốc công ty cổ phần Phát Triển Nguồn Mở Việt Nam (VINADES.,JSC) xin gửi đến Quý đối tác lời chào trân trọng, lời chúc may mắn và thành công. Tiếp đến chúng tôi xin được giới thiệu và ngỏ lời mời hợp tác kinh doanh.</p> <p style=\"text-align: justify; line-height: 130%; font-style: italic; text-indent: 1cm;\"> VINADES.,JSC ra đời nhằm chuyên nghiệp hóa việc phát hànhmã nguồn mở NukeViet. Đồng thời khai thác các dự án từ NukeViet tạo kinh phí phát triển bền vững cho mã nguồn này.</p> <p style=\"text-align: justify; line-height: 130%; font-style: italic; text-indent: 1cm;\"> NukeViet là hệ quản trị nội dung, là website đa năng đầu tiên của Việt Nam do cộng đồng người Việt phát triển. Có nhiều lợi thế như cộng đồng người sử dụng đông đảo nhất tại Việt Nam hiện nay, sản phẩm thuần Việt, dễ sử dụng, dễ phát triển.</p> <p style=\"text-align: justify; line-height: 130%; font-style: italic; text-indent: 1cm;\"> Hiện tại VINADES.,JSC đang tiến hành phát triển bộ mã nguồn NukeViet phiên bản 3.0 – một thế hệ CMS hoàn toàn mới với nhiều tính năng ưu việt, được đầu tư bài bản với kinh phí lớn.</p> <p style=\"text-align: justify; line-height: 130%; font-style: italic; text-indent: 1cm;\"> Với thiện chí hợp tác cùng phát triển VINADES.,JSC xin trân trọng gửi lời mời hợp tác đến Quý đối tác là các công ty cung cấp tên miền -hosting, các doanh nghiệp quan tâm và mong muốn hợp tác cùng VINADES để cùng thực hiện chung các hoạt động kinh doanh nhằm gia tăng giá trị, quảng bá thương hiệu chung cho cả hai bên.</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm; font-weight: bold;\"> Phương thức hợp tác nhưsau:</p> <p style=\"text-align: justify; line-height: 130%; font-weight: bold;\"> 1.Quảng cáo, trao đổi banner, liên kết website:</p> <p style=\"text-align: justify; line-height: 130%;\"> a. Mô tả hình thức:</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Quảng cáo trên website &amp; hệ thống kênh truyền thông của 2 bên.</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Quảng cáo trên các phiên bản phát hành của mã nguồn mở NukeViet.</p> <p style=\"text-align: justify; line-height: 130%;\"> b, Lợi ích:</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Quảng bá rộng rãi cho đối tượng của 2 bên.</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Giảm chi phí quảng bá cho 2 bên.</p> <p style=\"text-align: justify; line-height: 130%;\"> c, Trách nhiệm:</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Hai bên sẽ thỏa thuận và đưa quảng cáo của mình vào website của đối tác. Thỏa thuận vị trí, kích thước và trang đặt banner quảng cáo nhằm mang lại hiệu quả cao cho cả hai bên.</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Mở forum hỗ trợ người dùng hosting ngay tại diễn đàn NukeViet.VN để quý công ty dễ dàng hỗ trợ người sử dụng cũng như thực hiện các kế hoạch truyền thông của mình tới cộng đồng NukeViet.</p> <p style=\"text-align: justify; line-height: 130%; font-weight: bold;\"> 2.Hợp tác cung cấp hosting thử nghiệm NukeViet:</p> <p style=\"text-align: justify; line-height: 130%;\"> a. Mô tả hình thức:</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Hai bên ký hợp đồng nguyên tắc &amp; thỏa thuận hợp tác trong việc hợp tác phát triển mã nguồn mở NukeViet. Theo đó:</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> + Phía đối tác cung cấp mỗi loại 1 gói hosting đại lý cho VINADES.,JSC để chúng tôi test trong quá trình phát triển mã nguồn mở NukeViet, để đảm bảo NukeViet sẵn sàng tương thích với hosting của quý khách ngay khi ra mắt.</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> + VINADES.,JSC sẽ công báo thông tin chứng nhận host của phía đối tác là phù hợp, tương thích tốt nhất với NukeViet tới cộng đồng những người phát triển và sử dụng NukeViet.</p> <p style=\"text-align: justify; line-height: 130%;\"> b. Lợi ích:</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Mở rộng thị trường theo cả hướng đối tượng.</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Tiết kiệm chi phí –nâng cao hiệu quả kinh doanh.</p> <p style=\"text-align: justify; line-height: 130%;\"> c. Trách nhiệm:</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Bên đối tác cung cấp miễn phí host để VINADES.,JSC thực hiện việc test tương thích mã nguồn NukeViet trên các gói hosting của đối tác.</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - VINADES.,JSC công bố tới cộng đồng về kết quả chứng nhận chất lượng host của phía đối tác.</p> <p style=\"text-align: justify; line-height: 130%; font-weight: bold;\"> 3,Hợp tác nhân lực hỗ trợ người sử dụng:</p> <p style=\"text-align: justify; line-height: 130%;\"> a, Mô tả hình thức:</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Hai bên sẽ hỗ trợ lẫn nhau trong quá trình giải quyết các yêu cầu của khách hàng.</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> + Bên đối tác gửi các yêu cầu của khách hàng về mã nguồn NukeViet tới VINADES.,JSC</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> + VINADES gửi các yêu cầu của khách hàng có liên quan đến dịch vụ hosting tới phía đối tác.</p> <p style=\"text-align: justify; line-height: 130%;\"> b, Lợi ích:</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Giảm thiểu chi phí, nhân lực hỗ trợ khách hàng của cả 2 bên.</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Tăng hiệu quả hỗ trợ khách hàng.</p> <p style=\"text-align: justify; line-height: 130%;\"> c, Trách nhiệm:</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Khi nhận được yêu cầu hỗ trợ VINADES hoặc bên đối tác cần ưu tiên xử lý nhanh gọn nhằm nâng cao hiệuquả của sự hợp tác song phưong này.</p> <p style=\"text-align: justify; line-height: 130%; font-weight: bold;\"> 4. Các hình thức khác:</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> Ngoài các hình thức đã đề xuất ở trên, là đơn vị phát hành mã nguồn mở NukeViet chúng tôi có thể phát hành quảng cáo trên giao diện phần mềm, trên các bài viết giới thiệu xuất hiện ngay sau khi cài đặt phần mềm… chúng tôi tin tưởng rằng với lượng phát hành lên đến hàng chục ngàn lượt tải về cho mỗi phiên bản là một cơ hội quảng cáo rất hiệu quả đến cộng đồng Webmaster Việt Nam.</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> Với mong muốn tạo nên cộng đồng phát triển và sử dụng NukeViet rộng lớn đúng như mục tiêu đề ra,chúng tôi luôn linh động trong các hình thức hợp tác nhằm mang lại sự thuận tiện cho đối tác cũng như mục tiêu hợp tác đa phương. Chúng tôi sẽ tiếp nhận các hình thức hợp tác khác mà bên đối tác trình bày hợp lý và hiệu quả, mong nhận được thêm nhiều hình thức hợp tác khác từ đối tác. Phương châm của chúng tôi “Cùng hợp tác để phát triển”.</p> <p style=\"text-align: justify; line-height: 130%; font-style: italic; text-indent: 1cm;\"> Trân trọng cảm ơn, rất mong được hợp tác cùng quý vị.</p> <span style=\"font-weight: bold;\">Thông tin liên hệ:</span> <p style=\"text-align: justify;\"> CÔNGTY CỔ PHẦN PHÁT TRIỂN NGUỒN MỞ VIỆT NAM (VINADES.,JSC)</p> <p style=\"text-align: justify; text-indent: 1cm;\"> Trụ sở chính: 67B (ngõ 35) phố Khương Hạ, Khương Đình, ThanhXuân, Hà Nội.</p> <p style=\"text-align: justify; text-indent: 1cm;\"> Điện thoại: (84-4) 85 872007</p> <p style=\"text-align: justify; text-indent: 1cm;\"> Fax: (84-4) 35 500 914</p> <p style=\"text-align: justify; text-indent: 1cm;\"> Website: <a href=\"http://www.vinades.vn/\">www.vinades.vn</a> – <a href=\"http://www.nukeviet.vn/\">www.nukeviet.vn</a></p> <p style=\"text-align: justify; text-indent: 1cm;\"> Email: <a href=\"mailto:contact@vinades.vn\">contact@vinades.vn</a></p>', 0, 1, 2, 1, '29|8', 1, 1, 1, 73, 0, 0, 'hiện tại, tiến hành, phát triển, phiên bản, thế hệ, hoàn toàn, tính năng, ưu việt, kinh phí, thiện chí, hợp tác, trân trọng, mời hợp tác, đối tác, các công ty, công ty, cung cấp, tên miền, các doanh, doanh nghiệp, quan tâm');


-- ---------------------------------------


--
-- Table structure for table `nv_vi_news_sources`
--

DROP TABLE IF EXISTS `nv_vi_news_sources`;
CREATE TABLE `nv_vi_news_sources` (
  `sourceid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL DEFAULT '',
  `link` varchar(255) NOT NULL DEFAULT '',
  `logo` varchar(255) NOT NULL DEFAULT '',
  `weight` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `add_time` int(11) unsigned NOT NULL,
  `edit_time` int(11) unsigned NOT NULL,
  PRIMARY KEY (`sourceid`),
  UNIQUE KEY `title` (`title`)
) ENGINE=MyISAM  AUTO_INCREMENT=3  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv_vi_news_sources`
--

INSERT INTO `nv_vi_news_sources` VALUES
(1, 'Hanoimoi.com.vn', '', '', 1, 1274989177, 1274989177), 
(2, 'nukeviet.vn', '', '', 2, 1274989787, 1274989787);


-- ---------------------------------------


--
-- Table structure for table `nv_vi_news_topics`
--

DROP TABLE IF EXISTS `nv_vi_news_topics`;
CREATE TABLE `nv_vi_news_topics` (
  `topicid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `image` varchar(255) NOT NULL,
  `thumbnail` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `weight` smallint(4) NOT NULL DEFAULT '0',
  `keywords` mediumtext NOT NULL,
  `add_time` int(11) NOT NULL DEFAULT '0',
  `edit_time` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`topicid`),
  UNIQUE KEY `title` (`title`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM  AUTO_INCREMENT=2  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv_vi_news_topics`
--

INSERT INTO `nv_vi_news_topics` VALUES
(1, 'NukeViet 3', 'NukeViet-3', '', '', 'NukeViet 3', 1, 'NukeViet 3', 1274990212, 1274990212);


-- ---------------------------------------


--
-- Table structure for table `nv_vi_referer_stats`
--

DROP TABLE IF EXISTS `nv_vi_referer_stats`;
CREATE TABLE `nv_vi_referer_stats` (
  `host` varchar(255) NOT NULL,
  `total` int(11) NOT NULL DEFAULT '0',
  `month01` int(11) NOT NULL DEFAULT '0',
  `month02` int(11) NOT NULL DEFAULT '0',
  `month03` int(11) NOT NULL DEFAULT '0',
  `month04` int(11) NOT NULL DEFAULT '0',
  `month05` int(11) NOT NULL DEFAULT '0',
  `month06` int(11) NOT NULL DEFAULT '0',
  `month07` int(11) NOT NULL DEFAULT '0',
  `month08` int(11) NOT NULL DEFAULT '0',
  `month09` int(11) NOT NULL DEFAULT '0',
  `month10` int(11) NOT NULL DEFAULT '0',
  `month11` int(11) NOT NULL DEFAULT '0',
  `month12` int(11) NOT NULL DEFAULT '0',
  `last_update` int(11) NOT NULL DEFAULT '0',
  UNIQUE KEY `host` (`host`),
  KEY `total` (`total`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv_vi_searchkeys`
--

DROP TABLE IF EXISTS `nv_vi_searchkeys`;
CREATE TABLE `nv_vi_searchkeys` (
  `id` varchar(32) NOT NULL DEFAULT '',
  `keys` varchar(255) NOT NULL,
  `total` int(11) NOT NULL DEFAULT '0',
  `search_engine` varchar(50) NOT NULL,
  KEY `id` (`id`),
  KEY `keys` (`keys`),
  KEY `search_engine` (`search_engine`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv_vi_voting`
--

DROP TABLE IF EXISTS `nv_vi_voting`;
CREATE TABLE `nv_vi_voting` (
  `vid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `question` varchar(255) NOT NULL,
  `acceptcm` int(2) NOT NULL DEFAULT '1',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `who_view` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `groups_view` varchar(255) NOT NULL,
  `publ_time` int(11) unsigned NOT NULL DEFAULT '0',
  `exp_time` int(11) unsigned NOT NULL DEFAULT '0',
  `act` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`vid`),
  UNIQUE KEY `question` (`question`)
) ENGINE=MyISAM  AUTO_INCREMENT=4  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv_vi_voting`
--

INSERT INTO `nv_vi_voting` VALUES
(2, 'Bạn biết gì về NukeViet 3?', 1, 1, 0, '0', 1275318563, 0, 1), 
(3, 'Bạn quan tâm gì nhất ở mã nguồn mở?', 1, 1, 0, '0', 1275318589, 0, 1);


-- ---------------------------------------


--
-- Table structure for table `nv_vi_voting_rows`
--

DROP TABLE IF EXISTS `nv_vi_voting_rows`;
CREATE TABLE `nv_vi_voting_rows` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `vid` int(11) unsigned NOT NULL,
  `title` varchar(255) NOT NULL DEFAULT '',
  `hitstotal` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `vid` (`vid`,`title`)
) ENGINE=MyISAM  AUTO_INCREMENT=14  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv_vi_voting_rows`
--

INSERT INTO `nv_vi_voting_rows` VALUES
(5, 2, 'Một bộ sourcecode cho web hoàn toàn mới.', 0), 
(6, 2, 'Mã nguồn mở, sử dụng miễn phí.', 0), 
(7, 2, 'Sử dụng xHTML, CSS và hỗ trợ Ajax', 0), 
(8, 2, 'Tất cả các ý kiến trên', 0), 
(9, 3, 'Liên tục được cải tiến, sửa đổi bởi cả thế giới.', 0), 
(10, 3, 'Được sử dụng miễn phí không mất tiền.', 0), 
(11, 3, 'Được tự do khám phá, sửa đổi theo ý thích.', 0), 
(12, 3, 'Phù hợp để học tập, nghiên cứu vì được tự do sửa đổi theo ý thích.', 0), 
(13, 3, 'Tất cả các ý kiến trên', 0);


-- ---------------------------------------


--
-- Table structure for table `nv_vi_weblinks_cat`
--

DROP TABLE IF EXISTS `nv_vi_weblinks_cat`;
CREATE TABLE `nv_vi_weblinks_cat` (
  `catid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `parentid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `title` varchar(100) NOT NULL,
  `catimage` varchar(100) NOT NULL,
  `alias` varchar(100) NOT NULL,
  `description` text,
  `weight` smallint(4) NOT NULL DEFAULT '0',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `numlinks` tinyint(2) unsigned NOT NULL DEFAULT '3',
  `keywords` text NOT NULL,
  `add_time` int(11) unsigned NOT NULL,
  `edit_time` int(11) unsigned NOT NULL,
  PRIMARY KEY (`catid`),
  UNIQUE KEY `parentid` (`parentid`,`title`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv_vi_weblinks_config`
--

DROP TABLE IF EXISTS `nv_vi_weblinks_config`;
CREATE TABLE `nv_vi_weblinks_config` (
  `name` varchar(20) NOT NULL DEFAULT '',
  `value` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv_vi_weblinks_config`
--

INSERT INTO `nv_vi_weblinks_config` VALUES
('intro', ''), 
('numcat', '2'), 
('showsub', '1'), 
('numsub', '2'), 
('numinsub', '1'), 
('showcatimage', '0'), 
('per_page', '20'), 
('numsubcat', '2'), 
('shownumsubcat', '1'), 
('sort', 'asc'), 
('showlinkimage', '1'), 
('showdes', '1'), 
('sortoption', 'byid'), 
('imgwidth', '100'), 
('imgheight', '74'), 
('timeout', '1');


-- ---------------------------------------


--
-- Table structure for table `nv_vi_weblinks_report`
--

DROP TABLE IF EXISTS `nv_vi_weblinks_report`;
CREATE TABLE `nv_vi_weblinks_report` (
  `id` int(11) DEFAULT NULL,
  `type` int(1) DEFAULT NULL,
  `report_time` int(11) NOT NULL,
  `report_userid` int(11) NOT NULL,
  `report_ip` varchar(16) NOT NULL,
  `report_browse_key` varchar(100) NOT NULL,
  `report_browse_name` varchar(100) NOT NULL,
  `report_os_key` varchar(100) NOT NULL,
  `report_os_name` varchar(100) NOT NULL,
  `report_note` varchar(255) NOT NULL,
  KEY `id` (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv_vi_weblinks_rows`
--

DROP TABLE IF EXISTS `nv_vi_weblinks_rows`;
CREATE TABLE `nv_vi_weblinks_rows` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `catid` mediumint(9) NOT NULL,
  `author` varchar(100) NOT NULL DEFAULT '1|1',
  `title` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `urlimg` varchar(255) NOT NULL,
  `admin_phone` varchar(255) NOT NULL,
  `admin_email` varchar(255) NOT NULL,
  `note` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `add_time` int(11) unsigned NOT NULL DEFAULT '0',
  `edit_time` int(11) unsigned NOT NULL DEFAULT '0',
  `hits_total` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `status` (`status`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;